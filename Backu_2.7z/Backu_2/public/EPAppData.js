window.epAppData = {
  API_BASE_URL: 'https://api.ep-dev.tatamotors.com',
  ENV_TYPE: 'TEST',
  AUTH_ENDPOINT: 'https://auth.ep-dev.tatamotors.com/auth',
  LOGGING_ENDPOINT_USERNAME: 'production-planning',
  LOGGING_ENDPOINT_PASSWORD: '123456',
  HOME_UI_BASE_URL: 'https://home.ep-dev.tatamotors.com',
  PPC_UI_BASE_URL: 'https://planning.ep-dev.tatamotors.com',
  PRODUCTION_UI_BASE_URL: 'https://planning.ep-dev.tatamotors.com',
  QUALITY_UI_BASE_URL: 'https://quality.ep-dev.tatamotors.com',
  SUPPLY_CHAIN_UI_BASE_URL: 'https://supply-chain.ep-dev.tatamotors.com',
};
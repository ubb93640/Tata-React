/* eslint-disable arrow-body-style */
import React from 'react';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import ReactSelect from 'react-select';
import styles from './Select.module.css';

const Select = ({
  label,
  options,
  selectClassName,
  labelClassName,
  selectName,
  maxMenuHeight = 160,
  fontColor = '#707070',
  onChange,
  isLoading,
  borderStyle,
  spaceAfterLabel = '1em',
  value,
  ...props
}) => {
  return (
    <div {...props}>
      {label && (
        <span
          style={{
            marginRight: spaceAfterLabel,
          }}
          className={labelClassName}
        >
          {label}
        </span>
      )}
      <ReactSelect
        value={value}
        isLoading={isLoading}
        options={options}
        className={clsx(
          styles.select,
          label && styles.selectWithLabel,
          selectClassName,
        )}
        classNamePrefix={`select-${selectName}`}
        maxMenuHeight={maxMenuHeight}
        styles={{
          menuList: provided => ({
            ...provided,
            '&::-webkit-scrollbar': {
              width: '4px !important',
              height: '6px',
              display: 'block !important',
              background: 'none',
            },
            '&::-webkit-scrollbar-track': {
              background: 'none',
            },
            '&::-webkit-scrollbar-thumb': {
              background: '#f17c7c',
            },
            '&::-webkit-scrollbar-thumb:hover': {
              background: '#da6363',
            },
          }),
          singleValue: provided => ({
            ...provided,
            color: fontColor,
          }),
          control: provided => ({
            ...provided,
            minHeight: 0,
            height: '100%',
            padding: 0,
            border:
              borderStyle === undefined ? 'solid 1px #707070' : borderStyle,
          }),
          dropdownIndicator: provided => ({
            ...provided,
            width: '30px',
            padding: '5px',
          }),
          indicatorSeparator: () => ({ display: 'none' }),
        }}
        onChange={onChange}
        {...props}
      />
    </div>
  );
};

Select.propTypes = {
  label: PropTypes.string,
  value: PropTypes.shape({
    label: PropTypes.string.isRequired,
    value: PropTypes.string.isRequired,
  }),
  fontColor: PropTypes.string,
  options: PropTypes.arrayOf(
    PropTypes.shape({
      label: PropTypes.string.isRequired,
      value: PropTypes.string.isRequired,
    }),
  ),
  spaceAfterLabel: PropTypes.string,
  borderStyle: PropTypes.string,
  labelClassName: PropTypes.string,
  selectClassName: PropTypes.string,
  selectName: PropTypes.string.isRequired,
  maxMenuHeight: PropTypes.number,
  onChange: PropTypes.func,
  isLoading: PropTypes.bool,
};

export default Select;

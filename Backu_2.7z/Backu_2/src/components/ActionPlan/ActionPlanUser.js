import React from "react";
// import { Link } from "react-router-dom";
// import { Button } from 'react-bootstrap';
// import Moment from 'moment';
// import Modal from 'react-bootstrap/Modal';
import '../../App.css';
import './ActionPlan.css';
// import dumyData from  './MSAReport.json';


export default function ActionPlanUser() {

    return (
        <div className="container-fluid">
            <form id="Frm_id1" method="POST">
                <div className="row mt-3">
                    <div className="col text-left justify-content">
                        <h4 className="text-dark py-1" style={{ backgroundColor: "rgb(207,221,230)" }}>Phygital MSA // Action Plan</h4>
                    </div>
                </div>
                {/* {% if request.user|has_group:"tml_lead" or request.user|has_group:"tml_auditors" or request.user|has_group:"TML_USER" %} */}
                <div className="row mt-4 container-fluid" style={{ display: "flex", textAlign: "center" }}>
                    {/* <!-- <div className="col-md-2 rounded bg-success text-light">
        Status tracker
      </div> --> */}
                    <div className="col-md-2">
                        <lable className="text-dark">Select Vendor Code</lable>
                    </div>
                    <div className="col-md-2 rounded text-dark" style={{ maxWidth: "100%" }}>
                        <select id="selected_vendorinfocode" name="selected_vendorinfocode">
                            <option value="All">All</option>
                        </select>
                    </div>
                    <div className="col-md-2">
                        <lable className="text-dark">Select Status</lable>
                    </div>
                    <div className="col-md-2 text-dark" style={{ maxWidth: "100%" }} >
                        <select id="selected_status" name="selected_status">
                            <option value="ALL">All</option>
                        </select>
                    </div>
                    <div className="col-md-3 rounded" style={{ margin: "-5px" }}>
                        {/* <!-- <button type="submit" className="rounded text-light bg-success mt-1" 
         onclick="getmsalead_deatils_filter()">Get Details</button>   --> */}
                        <button type="submit" className="rounded text-light bg-success mt-1"
                        >Get Details</button>
                    </div>


                </div>
                {/* {% elif request.user|has_group:"tml_auditors" and not request.user|has_group:"tml_lead" %}
                
                */}
                {/* <div className="row mt-4 container-fluid" style={{ display: "flex", textAlign: "center" }}>
                    <div className="col-md-2 rounded bg-success text-light">
                        Status tracker
                    </div>
                    <div className="col-md-2">
                        <lable className="text-dark">Select Vendor Code</lable>
                    </div>

                    <div className="col-md-2 rounded text-dark" style={{ maxWidth: "100%" }}>
                        <select id="selected_vendorinfocode" name="selected_vendorinfocode">
                            <option value="All">All</option>
                        </select>
                    </div>
                    <div className="col-md-2">
                        <lable className="text-dark">Select Status</lable>
                    </div>
                    <div className="col-md-2 text-dark" style={{ width: "100%" }}>
                        <select id="selected_status" name="selected_status">

                            <option value="ALL">All</option>

                        </select>
                    </div>
                    <div className="col-md-2 rounded" style={{ margin: "-5px" }}> 
                        <button type="submit" className="rounded text-light bg-success mt-1"
                        >Get Details</button>
                    </div>
                </div> */}
            </form>
            {/* {% elif request.user|has_group:"tml_auditors" and request.user|has_group:"tml_lead" %} */}
            {/* <div className="row mt-4 ml-4">
                <div className="col-md-2 poi px-2 py-3 rounded text-light mx-5" style={{ backgroundColor: "#d17015" }}  >
                    <div className="row text-center justify-content" style={{ fontSize: "17px", marginLeft: "20%" }}>Status Tracker</div>
                    <div className="row"><b style={{ fontSize: "40px" }} className="text-center mx-auto ywa">4637</b></div>
                </div>
                <div className="col-md-6 poi px-2 py-3  text-light mx-5" >
                    <div className="row">
                        <select id="selected_status" name="selected_status">

                            <option value="ALL">All</option>

                        </select>
                    </div>
                </div>

            </div> */}


            <div className="row mt-4">
                <div className="col-md-2 ml-auto">
                    <input type="text" id="search" placeholder="Search..." className="form-control mb-1 border-primary" hidden />
                </div>
            </div>
            <div className="row mb-3" style={{ height: "450px", overflow: "scroll" }}>
                <div className="col-md-12 ">
                    <table className="table table-hover" id="table">
                        <thead className="thead-dark" style={{ fontSize: "18px" }}>
                            <tr>
                                <th className="stickyheader" >Project ID</th>
                                <th className="stickyheader">Vendor Code</th>
                                <th className="stickyheader">Supplier Name</th>
                                <th className="stickyheader">MSA Lead</th>
                                {/* <!-- <th scope="col" className="stickyheader">Issue Submitted Date</th> --> */}
                                <th className="stickyheader">OFI Submitted Date</th>
                                <th className="stickyheader">Date Of Initiation by MSA Lead</th>
                                <th className="stickyheader">Status</th>

                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><a href="{% url 'GetMSALeadDetail' st.msaprid__proid %}"> msaprid__proid </a></td>
                                <td>vendorcode</td>
                                <td>vendorname</td>
                                <td>first_name</td>
                                <td>d-m-Y</td>
                                <td>d-m-Y</td>
                                <td>status</td>
                            </tr>
                        </tbody>
                    </table>
                    <div className="row m-4 " style={{ float: "right" }} >Total Count: 7 </div>
                </div>
            </div>
        </div>

    );
}
import React from "react";
// import { Button } from 'react-bootstrap';
// import { encode } from "base-64";
// import Modal from 'react-bootstrap/Modal';
import '../App.css';

export default function ActionPlanIdAttachedMulti() {
    // const [show, setShow] = useState(false);
    // const handleClose = () => setShow(false);
    // const handleShow = () => setShow(true);
    // const [lastName, setName1] = useState();
    // const [dataArray1, setDataArray1] = useState([]);

    // const [dataArray, setDataArray] = useState([]);
    // function getUdate() {
    //     const username = 'A71720K01';
    //     const password = 'pass@123';
    //     const headerss = new Headers();
    //     headerss.append("authorization", "Basic QTcxNzIwSzAxOnBhc3NAMTIz", encode(username, ":", password));
    //     headerss.append('Content-Type', 'application/json');
    //     fetch('https://vendor360qa.tatamotors.com/api/contactprofilevendorviewdata', {
    //         method: 'POST',
    //         headers: headerss,
    //         body: JSON.stringify({ vendordata: ["A71720"] })
    //     }).then((response) => response.json())
    //         .then((responseJson) => {
    //             const responseArray = [];
    //             const prfilePost = [{ designation: "Chairman", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "Managing Director", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "CEO", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "CFO", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "Plant Head", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "Quality Head", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "Manufacturing Head", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "Key Account Manager", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "Finance Manager", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "Dispatch Manager", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }];
    //             const loda = [];
    //             const apidata = Object.values(responseJson);
    //             for (let i = 0; i < apidata.length; i += 1) {
    //                 for (let j = 0; j < apidata[i].length; j += 1) {
    //                     const data = {
    //                         // post: prfilePost[j],
    //                         user: apidata[i][j][0],
    //                         vandorName: apidata[i][j][1],
    //                         designation: apidata[i][j][2],
    //                         firstName: apidata[i][j][3],
    //                         lastName: apidata[i][j][4],
    //                         emailID: apidata[i][j][5],
    //                         phoneNumber: apidata[i][j][6],
    //                         location: apidata[i][j][7],
    //                         lastUpdated: apidata[i][j][8]
    //                     }
    //                     responseArray.push(data)
    //                     loda.push(prfilePost)
    //                 }

    //                 setDataArray(responseArray)
    //                 setDataArray1(prfilePost)
    //             }

    //             // console.log("sndhgsddgh", responseArray);



    //         })
    //         .catch((error) => {
    //             console.error(error);
    //         });
    // }
    // useEffect(() => {
    //     getUdate(dataArray1);
    // }, []);
    // const vaue = "";
    // console.log(vaue);
    // let edited = true;
    // if (vaue === "") {
    //     edited = true;
    // } else {
    //     edited = false;
    // }
    // let counter = 0
    return (
        <div className="container-fluid">
            <div className="row mt-3">
                <div className="col text-left justify-content">
                    <h4 className="text-dark py-1" style={{ background: "#cfddf2" }} >Phygital MSA // Action Plan// IdNumbor</h4>

                </div>
            </div>
            {/* enctype="multipart/form-data" */}
            <form method="POST" >
                {/* {% csrf_token %}
            {% for i in data %} */}
                <div className="row">

                    <div className="col-md-6">
                        <div className="row">
                            <div className="col-md-12 text-center">
                                <h5 className="text-light py-1 bg-primary rounded m-2 text-center p-1 col-md-12"> Company Management</h5>
                                <textarea cols="86" rows="3"
                                    className="ml-2 rounded form-control pr-4 auditorobservation text1"
                                    placeholder="Observation" disabled>  1.11 What early financial risk warning system does the Organization use?
                                </textarea>
                            </div>
                            <div className="col-md-6 mt-2">
                                {/* {% if request.user|has_group:"tml_lead" or request.user|has_group:"tml_auditors"%} */}

                                <h5 className="text-light py-1 bg-primary rounded m-2 text-center p-1 col-md-12">Remarks*</h5>
                                <textarea disabled
                                    required id="self_observation" cols="70" rows="3"
                                    className="ml-2 rounded form-control text3" placeholder="Remarks"
                                > test 1</textarea>


                                {/* {% elif request.user|has_group:"supplier_kam"%} */}
                                {/* <h5 className="text-light py-1 bg-primary rounded m-2 text-center p-1 col-md-12">Remarks*</h5>
                                <textarea name="remarks" disabled
                                    required id="self_observation" cols="70" rows="3"
                                    className="ml-2 rounded form-control text3" placeholder="Remarks"
                                >test 2</textarea> */}



                            </div>
                            <div className="col-md-6 mt-2">
                                <h5 className="text-light py-1 bg-primary rounded m-2 text-center p-1 col-md-12">Counter Measures*</h5>
                                <textarea disabled
                                    required id="self_observation" cols="70"
                                    rows="3" className="ml-2 rounded form-control text4"
                                    placeholder="Counter Measures"   > test 2</textarea>


                                {/* <h5 className="text-light py-1 bg-primary rounded m-2 text-center p-1 col-md-12">Counter Measures*</h5>
                                <textarea name="counter_measures"
                                    required id="self_observation" cols="70"
                                    rows="3" className="ml-2 rounded form-control text4"
                                    placeholder="Counter Measures" /> */}


                            </div>
                        </div>
                    </div>
                    <div className="col-md-6">
                        <div className="row">
                            <div className="col-md-12 text-center">
                                <h5 className="text-light py-1 bg-primary rounded m-2 text-center p-1 col-md-12">Opportunity for Improvement</h5>
                                <textarea name="" cols="86"
                                    rows="3" className="ml-2 rounded form-control pr-4 auditorobservation text2"
                                    id="Observation"  >
                                    {/* {{i.msaanswer_id__issue_Observed}} */} OFI 1.11
                                </textarea>
                            </div>
                            <br />
                            <br />
                            {/* <!-- <div classname="col-md-6 mt-2">
                            <h5 classname="text-light py-1 bg-primary rounded m-2 text-center p-1">Evidences</h5>
                            <textarea name="self_observation" required id="self_observation" cols="70" rows="3" classname="ml-2 rounded form-control text3" placeholder="Observation"   onchange="checkData('#self_observation')"></textarea>
                        </div>
                        <div classname="col-md-6 mt-2">
                            <h5 classname="text-light py-1 bg-primary rounded m-2 text-center p-1">Attach</h5>
                            <textarea name="self_observation" required id="self_observation" cols="70" rows="3" classname="ml-2 rounded form-control text4" placeholder="Observation"   onchange="checkData('#self_observation')"></textarea>
                        </div> --> */}
                            <div className="col-md-12 mt-3">
                                <table className="table " id="AttachmentTable">

                                    <thead>
                                        <tr>
                                            <th scope="col" className="text-light py-1 bg-primary rounded m-2 text-center p-1">Evidences</th>
                                            <th scope="col" className="text-light py-1 bg-primary rounded m-2 text-center p-1">Attach</th>
                                        </tr>
                                    </thead>
                                    {/* {% if request.user|has_group:"supplier_kam" %} */}
                                    <tbody>
                                        <tr className="py-1 m-4 text-center p-1">
                                            <td >
                                                {/* <label  for='fileload1' >  for='fileload2' */}
                                                Attachment_1
                                            </td>
                                            <td>
                                                {/* <!-- <input type="file" name="fileinput" id="docfile" accept=".doc,.docx, .pdf"/> --> */}
                                                {/* onchange="addfile(1)"  */}
                                                <input type="file" name="fileinput" id="docfile_1" />
                                            </td>
                                        </tr>
                                        <tr className="py-1 m-2 text-center p-1">
                                            <td>
                                                Attachment_2
                                            </td>
                                            {/* onchange="addfile(2)"  */}
                                            {/* <!-- <td><input type="file" name="fileinput" id="docfile" accept=".doc,.docx, .pdf"/></td> --> */}
                                            <td><input type="file" name="fileinput" id="docfile_2" /></td>
                                        </tr>
                                    </tbody>
                                    <tbody id="evidenceData">
                                        <tr>
                                            <td className="text-left ">file-sample_100kB_211017180140.doc</td>
                                            <td className="text-center"><i className="fa fa-file-text green-color" /></td>
                                        </tr>
                                        <tr>
                                            <td className="text-left ">sample_211017180140.pdf</td>
                                            <td className="text-center"><i className="fa fa-file-text green-color" /></td>
                                        </tr>
                                    </tbody>

                                    <tbody>
                                        <tr>
                                            {/* onclick="add_another()" */}
                                            <td><button type="button" className="btn btn-success" >+</button></td>
                                            {/* onclick="SubmitData()" */}
                                            <td><button type="submit" className="btn btn-success">Submit</button></td>
                                        </tr>
                                    </tbody>

                                </table>

                            </div>
                        </div>
                    </div>


                </div>


            </form>
        </div>
    );
}
import React from 'react';
import ReactEcharts from 'echarts-for-react';
// import { encode } from "base-64";


function Chart2() {
  // constructor(props) {
  //   super(props);
  //   this.state = {
  //     // chartData: {
  //     // },

  //   }

  // }

  // componentDidMount() {
  //   // this.getData();
  // }

  // getData() {
  //   var i = [];
  //   // let username = 'A71720K01';
  //   // let password = 'pass@123';
  //   let headerss = new Headers();
  //   const proxyurl = "https://vendor360qa.tatamotors.com";
  //   const url = "/api/prr";
  //   // headerss.append('Authorization', 'Basic ' + encode(username + ":" + password));
  //   headerss.append('Content-Type', 'application/json');
  //   fetch(proxyurl + url, { headers: headerss }).then((resp) => resp.json())
  //     .then((response) => {
  //       var xaxisarr = [];
  //       var yaxisarr = [];
  //       var gaxisarr = [];

  //       var zaxisarr = [];

  //       var apidata = Object.values(response);
  //       for (i = 0; i < apidata.length; i++) {
  //         xaxisarr.push(apidata[i]['month']);
  //         yaxisarr.push(apidata[i]['raised']);
  //         gaxisarr.push(apidata[i]['openprevious']);
  //         zaxisarr.push(apidata[i]['open']);
  //       }
  //       this.setState({
  //         chartData: {
  //           xaxisarr1: xaxisarr,
  //           yaxisarr1: yaxisarr,
  //           gaxisarr1: gaxisarr,
  //           zaxisarr1: zaxisarr,
  //         }
  //       });
  //     })
  //     .catch((error) => {
  //       console.log(error);
  //     });
  // }


  return (

    <ReactEcharts style={{
      width: "100%",
      height: "200px",
    }}
      option={{
        color: ['#3344db', '#7030a0', '#708090'],
        tooltip: {
          trigger: "axis"
        },
        title: {
          text: 'Monthly PRR Trend',
          left: 'center',
          textStyle: {
            fontSize: 15
          },
        },
        legend: {
          top: 160,
          data: ['Raised', 'Carryover', 'Open']
        },
        grid: {
          left: "3%",
          right: "3%"
        },
        xAxis: {
          // data: this.state.chartData.xaxisarr,
          data: ['Sep2021', 'Oct2021', 'Nov2021', 'Dec2021', 'Jan2022', 'Feb2022'],
          type: 'category',
          nameLocation: "end",
          nameTextStyle: {
            fontWeight: "bold",
            fontSize: 16,
            align: "center",
          }

        },
        yAxis: {
          scale: true,
          show: false,
          type: 'value',
          min: 0,
        },

        series: [
          {
            name: 'Raised',
            type: 'bar',
            barGap: 0,
            stack: 'total',
            // data: this.state.chartData.yaxisarr,
            data: [23, 36, 30, 26, 36, 26],
            label: {
              show: true,
              position: 'inside',
              fontWeight: "bold",
              fontSize: 12,
            },
          },
          {
            name: 'Carryover',
            type: 'bar',
            stack: 'total',
            // data: this.state.chartData.gaxisarr,
            data: [23, 15, 20, 30, 16, 25],
            label: {
              show: true,
              position: 'inside',
              fontWeight: "bold",
              fontSize: 12,
            },
          },
          {
            name: 'Open',
            type: 'bar',
            // data: this.state.chartData.zaxisarr,
            data: [15, 20, 30, 16, 25, 27],
            label: {
              show: true,
              position: 'inside',
              fontWeight: "bold",
              fontSize: 12,
            },
          },

        ]

      }}
    />
  );
}
export default Chart2;

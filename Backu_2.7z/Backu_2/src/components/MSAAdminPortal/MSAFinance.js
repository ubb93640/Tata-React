import React from "react";
// import { Link } from "react-router-dom";
// import { Button } from 'react-bootstrap';
// import Moment from 'moment';
// import Modal from 'react-bootstrap/Modal';
import '../../App.css';
import './MSAReport.css';
// import dumyData from  './MSAReport.json';


export default function MSAReport() {
    // const {supplier} = {
    //     "supplier":[
    //         [
    //          {
    //           "id": 1,
    //           "proid": "MSAB0640023032022",
    //           "updated_at": "2022-03-24T05:07:51.651Z",
    //           "startdate": "2022-03-24",
    //           "enddate": "2022-03-25",
    //           "MSAClosure_date": "2022-04-05T07:14:38.121Z"
    //          },
    //          "2025-04-05",
    //          "57",
    //          {
    //           "null": 1
    //          }
    //         ],
    //         [
    //          {
    //           "id": 2,
    //           "proid": "MSAB0640022032022",
    //           "updated_at": "2022-03-24T06:02:46.865Z",
    //           "startdate": "2022-03-24",
    //           "enddate": "2022-03-25",
    //           "MSAClosure_date": "2022-04-05T07:14:38.121Z"
    //          },
    //          "2025-04-05",
    //          "57",
    //          {
    //           "null": 1
    //          }
    //         ],
    //         [
    //          {
    //           "id": 8,
    //           "proid": "MSAB0640028032022",
    //           "updated_at": "2022-03-28T04:46:55.890Z",
    //           "startdate": "2022-03-28",
    //           "enddate": "2022-03-29",
    //           "MSAClosure_date": "2022-04-05T07:14:38.121Z"
    //          },
    //          "2025-04-05",
    //          "91",
    //          {
    //           "null": 1
    //          }
    //         ],
    //         [
    //          {
    //           "id": 9,
    //           "proid": "MSAB0640029032022",
    //           "updated_at": "2022-03-31T12:15:06.738Z",
    //           "startdate": "2022-03-31",
    //           "enddate": "2022-04-04",
    //           "MSAClosure_date": "2022-04-05T07:14:38.121Z"
    //          },
    //          "2025-04-05",
    //          "20",
    //          {
    //           "null": 1
    //          }
    //         ],
    //         [
    //          {
    //           "id": 10,
    //           "proid": "MSAB0640030032022",
    //           "updated_at": "2022-03-31T12:19:11.953Z",
    //           "startdate": "2022-03-31",
    //           "enddate": "2022-04-04",
    //           "MSAClosure_date": "2022-04-05T07:14:38.121Z"
    //          },
    //          "2025-04-05",
    //          "93",
    //          {
    //           "null": 1
    //          }
    //         ],
    //         [
    //          {
    //           "id": 11,
    //           "proid": "MSAB0640031032022",
    //           "updated_at": "2022-03-31T12:26:37.446Z",
    //           "startdate": "2022-03-31",
    //           "enddate": "2022-04-04",
    //           "MSAClosure_date": "2022-04-05T07:14:38.121Z"
    //          },
    //          "2025-04-05",
    //          "90",
    //          {
    //           "null": 1
    //          }
    //         ],
    //         [
    //          {
    //           "id": 12,
    //           "proid": "MSAB0640001042022",
    //           "updated_at": "2022-04-01T03:33:26.018Z",
    //           "startdate": "2022-04-01",
    //           "enddate": "2022-04-04",
    //           "MSAClosure_date": "2022-04-05T07:14:38.121Z"
    //          },
    //          "2025-04-05",
    //          "92",
    //          {
    //           "null": 1
    //          }
    //         ],
    //         [
    //          {
    //           "id": 14,
    //           "proid": "MSAB0640005042022",
    //           "updated_at": "2022-04-05T07:51:49.517Z",
    //           "startdate": "2022-04-05",
    //           "enddate": "2022-04-08",
    //           "MSAClosure_date": "2022-04-05T07:51:49.517Z"
    //          },
    //          "2025-04-05",
    //          "87",
    //          {
    //           "null": 1
    //          }
    //         ],
    //         [
    //          {
    //           "id": 15,
    //           "proid": "MSAB0640003042022",
    //           "updated_at": "2022-04-07T10:25:29.232Z",
    //           "startdate": "2022-04-06",
    //           "enddate": "2022-04-09",
    //           "MSAClosure_date": "2022-04-07T10:25:29.232Z"
    //          },
    //          "2025-04-07",
    //          "86",
    //          {
    //           "null": 1
    //          }
    //         ],
    //         [
    //          {
    //           "id": 16,
    //           "proid": "MSAB0640006042022",
    //           "updated_at": "2022-04-07T10:49:53.446Z",
    //           "startdate": "2022-04-06",
    //           "enddate": "2022-04-09",
    //           "MSAClosure_date": "2022-04-07T10:49:53.446Z"
    //          },
    //          "2025-04-07",
    //          "93",
    //          {
    //           "null": 1
    //          }
    //         ],
    //         [
    //          {
    //           "id": 17,
    //           "proid": "MSAB0640002042022",
    //           "updated_at": "2022-04-14T10:15:32.344Z",
    //           "startdate": "2022-04-07",
    //           "enddate": "2022-04-09",
    //           "MSAClosure_date": "2022-04-14T10:15:32.344Z"
    //          },
    //          "2025-04-14",
    //          "52",
    //          {
    //           "null": 1
    //          }
    //         ],
    //         [
    //          {
    //           "id": 19,
    //           "proid": "MSAB0640007042022",
    //           "updated_at": "2022-04-08T05:35:19.824Z",
    //           "startdate": "2022-04-07",
    //           "enddate": "2022-04-09",
    //           "MSAClosure_date": "2022-04-08T05:35:19.824Z"
    //          },
    //          "2025-04-08",
    //          "86",
    //          {
    //           "null": 1
    //          }
    //         ],
    //         [
    //          {
    //           "id": 20,
    //           "proid": "MSAB0640008042022",
    //           "updated_at": "2022-04-12T10:13:14.820Z",
    //           "startdate": "2022-04-08",
    //           "enddate": "2022-04-13",
    //           "MSAClosure_date": "2022-04-12T10:13:14.820Z"
    //          },
    //          "2025-04-12",
    //          "72",
    //          {
    //           "null": 1
    //          }
    //         ],
    //         [
    //          {
    //           "id": 23,
    //           "proid": "MSAB0640010042022",
    //           "updated_at": "2022-04-13T06:18:07.420Z",
    //           "startdate": "2022-04-13",
    //           "enddate": "2022-04-15",
    //           "MSAClosure_date": "2022-04-13T06:18:07.420Z"
    //          },
    //          "2025-04-13",
    //          "52",
    //          {
    //           "null": 1
    //          }
    //         ],
    //         [
    //          {
    //           "id": 24,
    //           "proid": "MSAB0640013042022",
    //           "updated_at": "2022-04-13T12:53:54.230Z",
    //           "startdate": "2022-04-13",
    //           "enddate": "2022-04-16",
    //           "MSAClosure_date": "2022-04-13T12:53:54.230Z"
    //          },
    //          "2025-04-13",
    //          "52",
    //          {
    //           "null": 1
    //          }
    //         ],
    //         [
    //          {
    //           "id": 25,
    //           "proid": "MSAB0640018042022",
    //           "updated_at": "2022-04-18T06:53:57.768Z",
    //           "startdate": "2022-04-18",
    //           "enddate": "2022-04-19",
    //           "MSAClosure_date": "2022-04-18T06:53:57.768Z"
    //          },
    //          "2025-04-18",
    //          "57",
    //          {
    //           "null": 1
    //          }
    //         ],
    //         [
    //          {
    //           "id": 26,
    //           "proid": "MSAB0640016042022",
    //           "updated_at": "2022-04-19T05:41:30.751Z",
    //           "startdate": "2022-04-19",
    //           "enddate": "2022-04-21",
    //           "MSAClosure_date": "2022-04-19T05:41:30.751Z"
    //          },
    //          "2025-04-19",
    //          "55",
    //          {
    //           "null": 1
    //          }
    //         ],
    //         [
    //          {
    //           "id": 27,
    //           "proid": "MSAB0640019042022",
    //           "updated_at": "2022-04-21T06:10:21.174Z",
    //           "startdate": "2022-04-19",
    //           "enddate": "2022-04-22",
    //           "MSAClosure_date": "2022-04-21T06:10:21.174Z"
    //          },
    //          "2025-04-21",
    //          "55",
    //          {
    //           "null": 1
    //          }
    //         ],
    //         [
    //          {
    //           "id": 32,
    //           "proid": "MSAB0640027042022",
    //           "updated_at": "2022-04-27T04:13:58.255Z",
    //           "startdate": "2022-04-27",
    //           "enddate": "2022-04-30",
    //           "MSAClosure_date": "2022-04-27T04:13:58.255Z"
    //          },
    //          "2025-04-27",
    //          "57",
    //          {
    //           "CV Body": 1,
    //           "CV Chassis": 2,
    //           "CV Defence": 3
    //          }
    //         ],
    //         [
    //          {
    //           "id": 36,
    //           "proid": "MSAB0640001052022",
    //           "updated_at": "2022-05-01T13:55:08.992Z",
    //           "startdate": "2022-05-01",
    //           "enddate": "2022-05-04",
    //           "MSAClosure_date": "2022-05-01T13:55:08.992Z"
    //          },
    //          "2025-05-01",
    //          "40",
    //          {
    //           "CV Body": 1,
    //           "CV Chassis": 2
    //          }
    //         ],
    //         [
    //          {
    //           "id": 38,
    //           "proid": "MSAB0640006052022",
    //           "updated_at": "2022-05-09T07:33:29.226Z",
    //           "startdate": "2022-05-06",
    //           "enddate": "2022-05-09",
    //           "MSAClosure_date": "2022-05-09T07:33:29.226Z"
    //          },
    //          "2025-05-09",
    //          "71",
    //          {
    //           "CV Body": 1,
    //           "CV Chassis": 2
    //          }
    //         ],
    //         [
    //          {
    //           "id": 39,
    //           "proid": "MSAB0640009052022",
    //           "updated_at": "2022-05-17T12:12:35.416Z",
    //           "startdate": "2022-05-09",
    //           "enddate": "2022-05-12",
    //           "MSAClosure_date": "2022-05-17T12:12:35.416Z"
    //          },
    //          "2025-05-17",
    //          "74",
    //          {
    //           "CV Body": 1,
    //           "PV Casting, Forging and Machinery": 2
    //          }
    //         ]
    //        ]
    // }
    return (
        <div className="container-fluid mt-2">
            <div className="row border-bottom border-secondary">
                <div className="col-md-12">
                    <h3 className="text-center text-primary">MSA Admin Portal</h3>
                </div>
            </div>
            <div className="row pb-1 border-bottom border-secondary">
                <div className="col-md-2"> </div>
                <div className="col-md-2">
                    <a href="{% url 'msaadddata'%}" className="submenunav" style={{ color: "#030352" }}>Add/ Upload Data</a>
                </div>
                <div className="col-md-2">
                    <a href="{% url 'msaedit' %}" className="submenunav" style={{ color: "#030352" }}>Edit/ Delete MSA Data</a>
                </div>
                <div className="col-md-2">
                    <a href="{% url 'msafinancetemplate' %}" className="submenunav" style={{ color: "#030352" }}>Finance Template Upload</a>
                </div>
                <div className="col-md-2">
                    <a href="{% url 'msatemplatedownloadredirect' %}" className="submenunav" style={{ color: "#030352" }}>MSA Template Download </a>
                </div>
            </div>
            <div className="row m-4">
                <div className="col-md-10 mt-4">
                    <form method="POST" id="myform">
                        <fieldset className="p-2">
                            <legend>MSA Finance Template</legend>
                            <div className="for-group row">
                                <div className="col-md-3 ml-2 mt-1">
                                    Select MSA Pillar
                                </div>
                                <div className="col-md-4">
                                    <select name="department" id="department" className="form-control">
                                        <option value="00">Select MSA Pillar</option>

                                        <option value="1">Company Management</option>

                                        <option value="2">Technology</option>

                                        <option value="5" selected="">Program Management</option>

                                        <option value="6">Customer Support</option>

                                        <option value="4">Process Control and Analysis</option>

                                        <option value="3">Purchasing and SCM</option>

                                    </select>
                                </div>
                                <input type="hidden" name="csrfmiddlewaretoken" value="kcBawf5ymmrzigiM8LMHRjYBjviZK31oFiNZYGgHSzaRfdCJPQAPWtpPyPMKnAjs" />
                            </div>
                        </fieldset>
                    </form>
                </div>
            </div>
            <div className="row ml-2 tbl1">
                <div className="col-md-12">
                    <div style={{ height: "315px", overflowY: "scroll" }}>
                        <table className="table table-bordered  rounded">
                            <thead className="thead-dark" style={{ zIndex: "3" }}>
                                <tr>
                                    <th scope="col" className="stickyheader" style={{ width: "5%" }}>Question_No.</th>
                                    <th scope="col" className="stickyheader" style={{ width: "30%" }}>Question Text</th>
                                    <th scope="col" className="stickyheader" style={{ width: "15%" }}>Finance Template Name</th>
                                    <th scope="col" className="stickyheader" style={{ width: "20%" }}>New Template</th>
                                    <th scope="col" className="stickyheader" style={{ width: "5%" }}>Upload</th>
                                </tr>
                            </thead>

                            <tbody>

                                <tr>
                                    <td>1.01</td>
                                    <td>How well defined is the Organizations business strategy?</td>
                                    <td> - </td>
                                    <td><input type="file" className="form-control" accept=".xlsx, .xls" id="temfile1031" /></td>
                                    <td>
                                        <button className="btn btn-success m-auto" type="button" id="btn1031" disabled=""  ><i className="fa fa-cloud-upload" aria-hidden="true">  </i> </button>
                                    </td>
                                </tr>

                                <tr>
                                    <td>1.02</td>
                                    <td>How good is the Organization‘s process for attaining the strategic goals?</td>
                                    <td> - </td>
                                    <td><input type="file" className="form-control" accept=".xlsx, .xls" id="temfile921" /></td>
                                    <td>
                                        <button className="btn btn-success m-auto" id="btn921" disabled="" type="button"   ><i className="fa fa-cloud-upload" aria-hidden="true"> </i> </button>
                                    </td>
                                </tr>

                                <tr>
                                    <td>1.03</td>
                                    <td>Does the organization follow EMS standard, environmental statutory and regulatory norms? Does the organization have responsibility defined internally?</td>
                                    <td> - </td>
                                    <td><input type="file" className="form-control" accept=".xlsx, .xls" id="temfile922" /></td>
                                    <td>
                                        <button className="btn btn-success m-auto" id="btn922" disabled="" type="button"  ><i className="fa fa-cloud-upload" aria-hidden="true"> </i> </button>
                                    </td>
                                </tr>

                                <tr>
                                    <td>1.03a</td>
                                    <td>Does the Organization follows statutory and regulatory norms related to IMDS, Conflict of Mineral and Persistent Organic Pollutant (POP) requirements?</td>
                                    <td> - </td>
                                    <td><input type="file" className="form-control" accept=".xlsx, .xls" id="temfile923" /></td>
                                    <td>
                                        <button className="btn btn-success m-auto" id="btn923" type="button" disabled=""><i className="fa fa-cloud-upload" aria-hidden="true"> </i> </button>
                                    </td>
                                </tr>

                                <tr>
                                    <td>1.04</td>
                                    <td>How does the organization demonstrate its HR policy and system?
                                        Does organization have employee motivation, feedback, engagement schemes?</td>
                                    <td> - </td>
                                    <td><input type="file" className="form-control" accept=".xlsx, .xls" id="temfile924" /></td>
                                    <td>
                                        <button className="btn btn-success m-auto" id="btn924" disabled="" type="button"  ><i className="fa fa-cloud-upload" aria-hidden="true"> </i> </button>
                                    </td>
                                </tr>

                                <tr>
                                    <td>1.05</td>
                                    <td>Does the organization follow company laws and regulations  governing to industries of its kind in terms of labor laws, health and leave polices?</td>
                                    <td> - </td>
                                    <td><input type="file" className="form-control" accept=".xlsx, .xls" id="temfile925" /></td>
                                    <td>
                                        <button className="btn btn-success m-auto" id="btn925" disabled="" type="button"  ><i className="fa fa-cloud-upload" aria-hidden="true"> </i> </button>
                                    </td>
                                </tr>

                                <tr>
                                    <td>1.06</td>
                                    <td>Does the organization have a process in place to ensure compliance with Secure Data Management to ensure confidential treatment of TML information and documentation?</td>
                                    <td> - </td>
                                    <td><input type="file" className="form-control" accept=".xlsx, .xls" id="temfile926" /></td>
                                    <td>
                                        <button className="btn btn-success m-auto" id="btn926" disabled="" type="button"  ><i className="fa fa-cloud-upload" aria-hidden="true"> </i> </button>
                                    </td>
                                </tr>

                                <tr>
                                    <td>1.07</td>
                                    <td>Does the organization have safety policy in place and demonstrates safety at work places?</td>
                                    <td> - </td>
                                    <td><input type="file" className="form-control" accept=".xlsx, .xls" id="temfile927" /></td>
                                    <td>
                                        <button className="btn btn-success m-auto" id="btn927" disabled="" type="button"  ><i className="fa fa-cloud-upload" aria-hidden="true"> </i> </button>
                                    </td>
                                </tr>

                                <tr>
                                    <td>1.08</td>
                                    <td>Does the organization promote  and establish a culture of continual improvements in value chain  which leads to cost control?</td>
                                    <td> - </td>
                                    <td><input type="file" className="form-control" accept=".xlsx, .xls" id="temfile928" /></td>
                                    <td>
                                        <button className="btn btn-success m-auto" id="btn928" disabled="" type="button"  ><i className="fa fa-cloud-upload" aria-hidden="true"> </i> </button>
                                    </td>
                                </tr>

                                <tr>
                                    <td>1.09</td>
                                    <td>Do the organization have infrastructure, process equipments and supporting aids in place, and are these capable to deliver desired system requirements?
                                        Is the set up continually upgraded with latest technology and management strives for improvement?</td>
                                    <td> - </td>
                                    <td><input type="file" className="form-control" accept=".xlsx, .xls" id="temfile929" /></td>
                                    <td>
                                        <button className="btn btn-success m-auto" id="btn929" disabled="" type="button" ><i className="fa fa-cloud-upload" aria-hidden="true"> </i> </button>
                                    </td>
                                </tr>

                                <tr>
                                    <td>1.1</td>
                                    <td>Do the financial figures match the Organizations strategy?
                                        (e.g.: sales volume and trend, capital investment in own company, etc.)</td>
                                    <td> - </td>
                                    <td><input type="file" className="form-control" accept=".xlsx, .xls" id="temfile930" /></td>
                                    <td>
                                        <button className="btn btn-success m-auto" id="btn930" disabled="" type="button"  ><i className="fa fa-cloud-upload" aria-hidden="true"> </i> </button>
                                    </td>
                                </tr>

                                <tr>
                                    <td>1.11</td>
                                    <td>What early financial risk warning system does the Organization use?
                                    </td>
                                    <td> - </td>
                                    <td><input type="file" className="form-control" accept=".xlsx, .xls" id="temfile931" /></td>
                                    <td>
                                        <button className="btn btn-success m-auto" id="btn931" disabled="" type="button"  ><i className="fa fa-cloud-upload" aria-hidden="true"> </i> </button>
                                    </td>
                                </tr>

                                <tr>
                                    <td>1.12</td>
                                    <td>Are finances properly tracked to ensure a continuous flow of raw material?</td>
                                    <td> - </td>
                                    <td><input type="file" className="form-control" accept=".xlsx, .xls" id="temfile932" /></td>
                                    <td>
                                        <button className="btn btn-success m-auto" id="btn932" disabled="" type="button"  ><i className="fa fa-cloud-upload" aria-hidden="true"> </i> </button>
                                    </td>
                                </tr>

                                <tr>
                                    <td>1.13</td>
                                    <td>How are the organizations financial ratios?</td>
                                    <td><a href="/downloadfiles/Financial Template.xlsx">Financial Template.xlsx</a></td>
                                    <td><input type="file" className="form-control" accept=".xlsx, .xls" id="temfile933" /></td>
                                    <td>
                                        <button className="btn btn-success m-auto" id="btn933" disabled="" type="button"  ><i className="fa fa-cloud-upload" aria-hidden="true">  </i> </button>
                                    </td>
                                </tr>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    );
}
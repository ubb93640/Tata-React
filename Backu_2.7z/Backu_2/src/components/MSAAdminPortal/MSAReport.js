import React from "react";
import { Link, Route, } from "react-router-dom";
// import { Button } from 'react-bootstrap';
// import Moment from 'moment';
// import Modal from 'react-bootstrap/Modal';
import EditDeleteMSAData from "./EditDeleteMSAData"
import '../../App.css';
import './MSAReport.css';
// import dumyData from  './MSAReport.json';


export default function MSAReport() {

    return (

        <div className="container-fluid mt-2">
            {/* <Button component={Link} to="/https://reacttraining.com/blog/react-router-v6-pre/">
                Click Me
            </Button> */}
            <nav>
                <Link to="me">My Profile</Link>
            </nav>

            <Route path="/" element={<MSAReport />} />
            {/* <Route path=":id" element={<UserProfile />} /> */}
            <Route path="me" element={<EditDeleteMSAData />} />

            <div className="row border-bottom border-secondary">
                <div className="col-md-12">
                    <h3 className="text-center text-primary">MSA Admin Portal</h3>
                </div>
            </div>

            <div className="row pb-1 border-bottom border-secondary">
                <div className="col-md-2"> </div>
                <div className="col-md-2">
                    <a href="{% url 'msaadddata'%}" className="submenunav" style={{ color: "#030352" }}>Add/ Upload Data</a>
                </div>
                <div className="col-md-2">
                    <a href="{% url 'msaedit' %}" className="submenunav" style={{ color: "#030352" }}>Edit/ Delete MSA Data</a>
                </div>
                <div className="col-md-2">
                    <a href="{% url 'msafinancetemplate' %}" className="submenunav" style={{ color: "#030352" }}>Finance Template Upload</a>
                </div>
                <div className="col-md-2">
                    <a href="{% url 'msatemplatedownloadredirect' %}" className="submenunav" style={{ color: "#030352" }}>MSA Template Download </a>
                </div>
            </div>
            <div className="container">
                {/* <div className="row" id="myalertdiv">
        <div className="col-md-10">
            <div className="alert alert-danger" role="alert">
                <i className="fa fa-times" aria-hidden="true"></i>Excel file not uploaded, please check the required column
                names!
            </div>
        </div>
    </div> 

    
    <div className="row" id="myalertdiv">
        <div className="col-md-10">
            <div className="alert alert-success" role="alert">
                <i className="fa fa-check" aria-hidden="true"></i>MSA Questions uploaded successfully
            </div>
        </div>
    </div>  */}
                <div className="row">
                    <div className="col-md-10 mt-4">
                        <form method="POST" >
                            <fieldset className="border p-2">
                                <legend>MSA Upload Data</legend>

                                <div className="for-group row">
                                    <div className="col-md-3 ml-2">
                                        Download Template
                                    </div>
                                    <div className="col-md-3">
                                        <a href="{% url 'msatemplate' %}" className="btn border btn border" id="dwnbtn" style={{ textDecoration: "none", color: "#000" }} download><img src="{% static 'vendor360/images/excelicon.png' %}" className="temdownimg" alt="Common col Template" data-toggle="tooltip" data-placement="right" title="Common Column Template" /> Download Template</a>
                                    </div>
                                </div>

                                <div className="for-group row mt-4">
                                    <div className="col-md-3 ml-2">
                                        Select MSA Pillar
                                    </div>
                                    <div className="col-md-5">
                                        <select name="department" id="department" className="form-control">
                                            <option value="00">Select MSA Pillar</option>
                                            {/* {% for each in departments %} */}
                                            <option value="{{each.id}}"> text</option>
                                            {/* {% endfor %} */}
                                        </select>
                                    </div>
                                </div>

                                <div className="form-group row mt-4">
                                    <div className="col-md-3 ml-2">
                                        Select Excel File
                                    </div>
                                    <div className="col-md-5">
                                        <input type="file" accept=".xls, .xlsx" className="form-control-file border card"
                                            id="msafile" name="fileselect1" required />
                                        <div>
                                            <small id="jsontext" className="d-none" style={{ color: "red" }}>Select Excel File
                                                only</small>
                                        </div>
                                    </div>
                                </div>

                                <div className="form-group row mt-4">
                                    <div className="col-md-4 ml-auto uploadbtnbulk">
                                        {/* {% if err %} */}
                                        <button className="btn btn-md btn-primary uploadbtn" type="button"><i className="fa fa-cloud-upload" aria-hidden="true">   </i> Upload</button>
                                        {/* {% else %}
                            <button className="btn btn-md btn-primary uploadbtn" disabled><i className="fa fa-cloud-upload" aria-hidden="true">  </i> Upload</button>
                            {% endif %} */}
                                    </div>
                                </div>
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
}
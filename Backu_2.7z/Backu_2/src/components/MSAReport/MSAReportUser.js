import React from "react";
// import { Link } from "react-router-dom";
// import { Button } from 'react-bootstrap';
// import Moment from 'moment';
// import Modal from 'react-bootstrap/Modal';
import '../../App.css';
import './MSAReport.css';
// import dumyData from  './MSAReport.json';


export default function MSAReportUser() {

    return (
        <div className="container-fluid">
            <form method="POST">
                <div className="row mb-4 mt-4">
                    <div className="col-md-8">
                        <select className="js-example-basic-multiple form-control vendorsel"  >
                            <option value="data">data</option>
                        </select>
                    </div>
                    <input type="hidden" name="vendorcodes" id="hidt" value="" />
                    <div className="col-md-2">
                        <button className="btn btn-success" type="button" disabled id="showdata">Show Projects</button>
                    </div>
                </div>
            </form>
            <div className="row vendata" style={{ height: " 400px", overflow: "scroll" }}>
                <div className="col-md-12">
                    <div id="table" className="table-editable">
                        <table className="table table-striped table-bordered rounded table-hover">
                            <thead className="thead-dark">
                                <tr>
                                    <th className="text-center stickyheader">Project ID</th>
                                    <th className="text-center stickyheader">Vendor Name</th>
                                    <th className="text-center stickyheader">Vendor Code</th>
                                    <th className="text-center stickyheader">Assignment start Date</th>
                                    <th className="text-center stickyheader">Assignment end Date</th>
                                    <th className="text-center stickyheader">MSA Closure date</th>
                                    <th className="text-center stickyheader">MSA Validity End date</th>
                                    <th className="text-center stickyheader">MSA Score</th>
                                    <th className="text-center stickyheader">Commodity</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr className="tbl{{each.id}}">
                                    <td><a href="{% url 'mleadscorecard' each.id %}">proid</a></td>
                                    <td>vendorname</td>
                                    <td>vendorname</td>
                                    <td>d-m-Y</td>
                                    <td>d-m-Y</td>
                                    <td>d-m-Y</td>
                                    <td>d-m-Y</td>
                                    <td>K</td>
                                    <td>

                                        <ul>
                                            <li>m</li>
                                        </ul>
                                    </td>

                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    );
}
/* eslint-disable jsx-a11y/no-noninteractive-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
import clsx from 'clsx';
import React, { useState } from 'react';
import PropTypes from 'prop-types';
import moment from 'moment';
import styles from './MonthPicker.module.css';
import { getMonthNameWithYear } from '../../utils/utils';

const MonthPicker = ({ handleSelect }) => {
  const today = moment();
  const nextThreeMonthNamesWithYear = [
    'thisMonth',
    'nextMonth',
    'thirdMonth',
  ].map(() => {
    const monthAndYear = getMonthNameWithYear(today);
    today.add(1, 'months');
    return monthAndYear;
  });

  const allMonths = [...nextThreeMonthNamesWithYear];
  const [selectedMonthNameWithYear, setSelectedMonthNameWithYear] = useState(
    nextThreeMonthNamesWithYear[0],
  );

  const handleClick = monthNameWithYear => {
    handleSelect(monthNameWithYear);
    setSelectedMonthNameWithYear(monthNameWithYear);
  };

  return (
    <div className={styles.selectMonth}>
      <span className={styles.monthView}>View</span>

      <ul className={styles.months}>
        {allMonths.map(monthNameWithYear => (
          <li
            className={clsx(
              monthNameWithYear === selectedMonthNameWithYear && styles.active,
            )}
            onClick={() => handleClick(monthNameWithYear)}
            key={monthNameWithYear}
          >
            {monthNameWithYear && monthNameWithYear?.split('-')[0]}
          </li>
        ))}
      </ul>
    </div>
  );
};

MonthPicker.propTypes = {
  handleSelect: PropTypes.func.isRequired,
};

export default MonthPicker;

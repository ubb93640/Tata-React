import React from "react";
// import DOMPurify from "dompurify";
// import { Markup } from 'interweave';
// import '../../App.css';
import './qacknowcontinue.css';
// import dumyData from  './qadeptvreport.json';

export default function QAcknowContinue() {
    // const [deptData, deptInfo] = [{
    //     "auditorobservation": "firsttest",
    //     "auditorscore": 10,
    //     "leadscore": 10,
    //     "leadobservation": "firsttest",
    //     "supplierobservation": "Are the TML requirements fulfilled in terms of product",
    //     "supplierscore": 10,
    //     "auditdept": "Advanced Quality",
    //     "question": "Are the TML requirements fulfilled in terms of product, process and Quality Management System?",
    //     "q_title": "6.1 - ",
    //     "guidelines": [" Organization has  fulfilled TML  specific requirements( mentioned in Supplier Quality manual/ SQ SOR)?\n", " Organization has QMS certification, valid and certified with latest revision.\n", " Regular Process audit for CTQ parameters\n", " Organization  include spare part requirement in production planning over regular production requirement from customer.\n", " Organization fulfills packaging/logistic requirements as per the SCM SOR?\n", " Does the product requalification's are carried out as per the customer's requirement?\n", " Does the product conform to legal/ statutory regulations?"],
    //     "veto": true,
    //     "VirAssessment_flag": true,
    //     "evidences": ["", " PPAP sign-off /TRSO sign-off\n", " Valid QMS certificates\n", " Process audit and statistical controls on CTQ- trend analysis\n", " Part-shipments to provide spares/first fill before start of full production\n", " Storage, scheduling, providing parts, shipping, compliance with customer specific packaging and identification regulation\n", " Quality agreements for PPM and delivery\n", " Product and shipping audit, dock audits\n", " Engineering test , reliability, durability & functional tests\n", " Compliance to packing standards\n", " Qualifications  & Requalification checks"],
    //     "filenames": [["", " PPAP sign-off /TRSO sign-off\n"], ["", " Valid QMS certificates\n"], ["", " Process audit and statistical controls on CTQ- trend analysis\n"], ["", " Part-shipments to provide spares/first fill before start of full production\n"], ["", " Storage, scheduling, providing parts, shipping, compliance with customer specific packaging and identification regulation\n"], ["", " Quality agreements for PPM and delivery\n"], ["", " Product and shipping audit, dock audits\n"], ["", " Engineering test , reliability, durability & functional tests\n"], ["", " Compliance to packing standards\n"], ["", " Qualifications  & Requalification checks"]],
    //     "ansid": 1
    // },
    // {
    //     "deptname": "Process Control and Analysis",
    //     "deptid": "6",
    //     "msapr": "1"
    // }
    // ]
    // const { auditorobservation, auditorscore, leadscore, leadobservation, supplierobservation, supplierscore, auditdept, question, qTitle, guidelines, veto, VirAssessmentFlag, evidences, filenames } = deptData;
    // const { deptname, deptid, msapr } = deptInfo
    // console.log(deptid, msapr)
    // console.log(leadscore, leadobservation, supplierobservation, evidences)

    // let guidelinestext = '';
    // if (guidelines) {
    //     let ab
    //     for (let i = 1; i < guidelines.length; i += 1) {
    //         ab = `-> &nbsp;&nbsp;  ${guidelines[i]}  <br>`;
    //         guidelinestext += ab;
    //     }
    // }
    // let financetem = ''
    // let financefileuploaded = ''
    // if ("auditorscore" in deptData) {
    //     financetem = deptData.financetem
    //     financefileuploaded = deptData.financefileuploaded
    //     console.log(" data is available", financetem)
    // }
    // else {
    //     console.log(" data is not available")
    // }
    // let filesnames = '';
    // if (filenames) {
    //     if (filenames.length === 0) {
    //         filesnames = "No Attachments"
    //     } else {
    //         let a
    //         for (let i = 0; i < filenames.length; i += 1) {
    //             a = `<tr><td> ${i + 1} </td><td>   ${filenames[i][1]} </td><td> <a href="/downloadfiles/${filenames[i][0]}"> ${filenames[i][0]} </a></td></tr>`;
    //             filesnames += a;
    //         }
    //     }
    // }
    // function scoreadp(score) {
    //     let value = score
    //     if (score === 100) {
    //         value = '0'
    //     } else if (score === -2) {
    //         value = 'NR'
    //     }
    //     return value;
    // }
    // const sanitizer = dompurify.sanitize;
    return (
        <div className="container">

            <div className="row mt-4">
                <div className="col-md-5">
                    <div style={{ float: "left", width: "400px" }} >
                        <div className="hex-row">
                            <div className="hex1">
                                <div className="top"> </div>
                                <div className="middle text-light">
                                    100.0%</div>
                                <div className="bottom"> </div>
                            </div>
                            <div className="hex1">
                                <div className="top"> </div>
                                <div className="middle"><a href="/msaworkprogram?dept=6&msaid={{msaprid}}" id="Customer_support"
                                    style={{ textAlign: "center", textDecoration: "none" }}  >Customer Support</a></div>


                                {/* {% endif %}
                        <!-- <div className="middle"><a href="/msaworkprogram?dept=6&msaid={{msaprid}}" id="Customer_support"
                                  style={{ textAlign: "center",  textDecoration: "none" }}  >Customer Support</a></div> -->
                        {% endif %} */}
                                <div className="bottom"> </div>
                            </div>

                        </div>
                        <div className="hex-row even">
                            <div className="hex2">
                                <div className="top"> </div>
                                <div className="middle"><a href="/msaworkprogram?dept=4&msaid={{msaprid}}"
                                    id="process_control_analysis" style={{ textAlign: "center", textDecoration: "none" }}  >Process
                                    Control & Analysis</a></div>



                                {/* <!-- <div className="middle"><a href="/msaworkprogram?dept=4&msaid={{msaprid}}"
                                id="process_control_analysis"   style={{ textAlign: "center",  textDecoration: "none" }}  >Process
                                Control & Analysis</a></div> --> */}
                                <div className="bottom"> </div>
                            </div>
                            <div className="hex2">
                                <div className="top"> </div>
                                <div className="middle text-light">
                                    100.0%</div>
                                <div className="bottom"> </div>
                            </div>
                        </div>
                        <div className="hex-row">
                            <div className="hex3">
                                <div className="top"> </div>
                                <div className="middle text-light">
                                    100.0%</div>
                                <div className="bottom"> </div>
                            </div>
                            <div className="hex3">
                                <div className="top"> </div>

                                <div className="middle"><a href="/msaworkprogram?dept=3&msaid={{msaprid}}" id="purchasing_and_scm"
                                    style={{ textAlign: "center", textDecoration: "none" }}  >Purchasing & SCM</a></div>

                                {/* <div className="middle"><a href="/msaworkprogram?dept=3&msaid={{msaprid}}" id="purchasing_and_scm"
                                    style={{ textAlign: "center", textDecoration: "none" }}  >Purchasing & SCM</a></div>

                                <div className="middle disable-links"><a href="/msaworkprogram?dept=3&msaid={{msaprid}}" id="purchasing_and_scm"
                                    style={{ textAlign: "center", textDecoration: "none" }}  >Purchasing & SCM</a></div> */}

                                {/* <!-- <div className="middle"><a href="/msaworkprogram?dept=3&msaid={{msaprid}}" id="purchasing_and_scm"
                                  style={{ textAlign: "center",  textDecoration: "none" }}  >Purchasing & SCM</a></div> --> */}
                                <div className="bottom"> </div>
                            </div>

                        </div>
                        <div className="hex-row even">
                            <div className="hex4">
                                <div className="top"> </div>
                                <div className="middle"><a href="/msaworkprogram?dept=5&msaid={{msaprid}}" id="program_management"
                                    style={{ textAlign: "center", textDecoration: "none" }}  >Program Management</a></div>
                                {/* 
                                <div className="middle"><a href="/msaworkprogram?dept=5&msaid={{msaprid}}" id="program_management"
                                    style={{ textAlign: "center", textDecoration: "none" }}  >Program Management</a></div>

                                <div className="middle disable-links"><a href="/msaworkprogram?dept=5&msaid={{msaprid}}" id="program_management"
                                    style={{ textAlign: "center", textDecoration: "none" }}  >Program Management</a></div> */}
                                {/* {% endif %}
                        {% endif %}
                        <!-- <div className="middle"><a href="/msaworkprogram?dept=5&msaid={{msaprid}}" id="program_management"
                                  style={{ textAlign: "center",  textDecoration: "none" }}  >Program Management</a></div> --> */}
                                <div className="bottom"> </div>
                            </div>
                            <div className="hex4">
                                <div className="top"> </div>
                                <div className="middle text-light">
                                    100.0% </div>
                                <div className="bottom"> </div>
                            </div>
                        </div>
                        <div className="hex-row">
                            <div className="hex5">
                                <div className="top"> </div>
                                <div className="middle text-light"> 100.0%</div>
                                <div className="bottom"> </div>
                            </div>
                            <div className="hex5">
                                <div className="top"> </div>
                                <div className="middle"><a href="/msaworkprogram?dept=2&msaid={{msaprid}}" id="technology"
                                    style={{ textAlign: "center", textDecoration: "none" }}  >Technology</a></div>



                                {/* <!-- <div className="middle"><a href="/msaworkprogram?dept=2&msaid={{msaprid}}" id="technology"
                                  style={{ textAlign: "center",  textDecoration: "none" }}  >Technology</a></div> --> */}

                                <div className="bottom"> </div>
                            </div>

                        </div>
                        <div className="hex-row even">
                            <div className="hex6">
                                <div className="top"> </div>
                                <div className="middle"><a href="/msaworkprogram?dept=1&msaid={{msaprid}}" id="company_management"
                                    style={{ textAlign: "center", textDecoration: "none" }}  >Company Management</a></div>


                                {/* {% endif %}
                        {% endif %}
                        <!-- <div className="middle"><a href="/msaworkprogram?dept=1&msaid={{msaprid}}" id="company_management"
                                  style={{ textAlign: "center",  textDecoration: "none" }}  >Company Management</a></div> --> */}
                                <div className="bottom"> </div>
                            </div>
                            <div className="hex6">
                                <div className="top"> </div>
                                <div className="middle text-light" id="scorem1">
                                    100.0%
                                    {/* {% if companymanagement|floatformat:2 %}{{companymanagement}}% {%else%}0%{% endif %} */}
                                </div>
                                <div className="bottom"> </div>
                            </div>
                        </div>
                    </div>
                </div>


                <div className="col-md-7">
                    <div className="row">
                        <div className="col-md-12">
                            <div className="card-header bg-info text-light" style={{ textAlign: "center", fontSize: "20px" }}  >
                                Assessment Details
                            </div>
                        </div>
                    </div>
                    {/* <!-- <div className="row my-4">
                <div className="col-md-12">
                    <label>Start date: </label>
                    <input type="date" disabled value="{{startdate|date:'Y-m-d'}}" />
                    <label>End Date: </label>
                    <input type="date" disabled value="{{enddate|date:'Y-m-d'}}" />
                </div>
            </div> --> */}
                    <div className="row my-4">
                        <div className="row col-md-12">
                            <div className=" col-md-6 text-center">Start date:</div>
                            <div className=" col-md-6 text-center">End Date:</div>
                        </div>
                        <div className="row col-md-12">
                            <div className="col-md-6 text-center"><input type="date" disabled value="{{startdate|date:'Y-m-d'}}" /></div>
                            <div className="col-md-6 text-center"><input type="date" disabled value="{{enddate|date:'Y-m-d'}}" /></div>

                        </div>
                    </div>
                    <div className="row">
                        <div className="col-md-12">
                            <div className="bg-info py-2 text-light text-center table-bordered" style={{ fontSize: "18px" }} >Internal Team for Self
                                assessment</div>
                            <table className="table table-striped table-bordered">
                                <thead className="bg-info text-light">
                                    <tr>

                                        <th scope="col" style={{ textAlign: "center", verticalAlign: "middle" }}>Name</th>
                                        <th scope="col" style={{ textAlign: "center", verticalAlign: "middle" }}>Department</th>
                                        <th scope="col" style={{ textAlign: "center", verticalAlign: "middle" }}>Phone No.</th>
                                        <th scope="col" style={{ textAlign: "center", verticalAlign: "middle" }}>Email ID</th>

                                    </tr>
                                </thead>

                                <tbody>
                                    <tr>
                                        <td><input type="text" disabled placeholder="Name" name="name1" value="{{ack.name1}}"
                                            className="form-control name1" /></td>
                                        {/* onchange="checkData('.name1')" */}
                                        <td><input type="text" disabled placeholder="Department" name="dept1" value="{{ack.dept1}}"
                                            className="form-control dept1" /></td>
                                        {/* onchange="checkData('.dept1')" */}
                                        <td><input type="text" disabled placeholder="Phone No" name="phone1" value="{{ack.phone1}}"
                                            className="form-control phone1" /></td>
                                        {/* onchange="checkDataPhone('.phone1')" */}
                                        <td><input type="text" placeholder="Email ID" name="email1" value="{{ack.email1}}"
                                            disabled className="form-control email1" /></td>
                                        {/* onchange="checkDataemail('.email1')" */}
                                    </tr>
                                    {/* <tr>
                                <td><input type="text" placeholder="Name" name="name2" {% if ack %} disabled {% endif %} onchange="checkData('.name2')"
                                        value="{{ack.name2}}" className="form-control name2" /></td>
                                <td><input type="text" placeholder="Department" name="dept2" value="{{ack.dept2}}" onchange="checkData('.dept2')"
                                        {% if ack %} disabled {% endif %} className="form-control dept2" /></td>
                                <td><input type="text" placeholder="Phone No" name="phone2" value="{{ack.phone2}}" onchange="checkDataPhone('.phone2')"
                                            {% if ack %} disabled {% endif %} className="form-control phone2"></td>
                                <td><input type="text" placeholder="Email ID" name="email2" value="{{ack.email2}}" onchange="checkDataemail('.email2')"
                                               {% if ack %} disabled {% endif %} className="form-control email2"></td>

                            </tr>

                            <input type="hidden" name="msapr" value="{{id}}" className="msaprid" />
                            <tr>
                                <td><input type="text" placeholder="name" name="name3" value="{{ack.name3}}" onchange="checkData('.name3')"
                                        {% if ack %} disabled {% endif %} className="form-control name3" /></td>
                                <td><input type="text" placeholder="department" name="dept3" value="{{ack.dept3}}" onchange="checkData('.dept3')"
                                        {% if ack %} disabled {% endif %} className="form-control dept3" /></td>
                                <td><input type="text" placeholder="Phone No" name="phone3" value="{{ack.phone3}}" onchange="checkDataPhone('.phone3')"
                                            {% if ack %} disabled {% endif %} className="form-control phone3"></td>
                                <td><input type="text" placeholder="Email ID" name="email3" value="{{ack.email3}}" onchange="checkDataemail('.email3')"
                                               {% if ack %} disabled {% endif %} className="form-control email3"></td>


                            </tr>
                            <tr>
                                <td><input type="text" placeholder="name" name="name4" value="{{ack.name4}}" onchange="checkData('.name4')"
                                        {% if ack %} disabled {% endif %} className="form-control name4" /></td>
                                <td><input type="text" placeholder="department" name="dept4" value="{{ack.dept4}}" onchange="checkData('.dept4')"
                                        {% if ack %} disabled {% endif %} className="form-control dept4" /></td>
                                <td><input type="text" placeholder="Phone No" name="phone4" value="{{ack.phone4}}" onchange="checkDataPhone('.phone4')"
                                            {% if ack %} disabled {% endif %} className="form-control phone4"></td>
                                <td><input type="text" placeholder="Email ID" name="email4" value="{{ack.email4}}" onchange="checkDataemail('.email4')"
                                               {% if ack %} disabled {% endif %} className="form-control email4"></td>

                            </tr> */}
                                </tbody>
                            </table>
                            {/* {% if hdctn %} */}
                            <input type="button" value="Continue" className="btn btn-primary float-right cntbtn"
                                style={{ width: "100px", float: "left" }} />
                            {/* onclick="saveack()" */}
                            {/* {% endif %} */}
                        </div>
                    </div>
                </div>
            </div>
        </div>

    )
}
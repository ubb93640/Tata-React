import React from "react";
import ReactEcharts from "echarts-for-react"; 
import Moment from 'moment';
import '../../App.css';
import './Scorecard.css';
// import dumyData from  './Scorecard.json';

const Scorecard = () => {
    const details = [
        {
        "suppliername": "B06400 - BRAKES INDIA PVT LTD",
        "auditorname": "Pritam Solunke sandy sandesh mahesh",
        "startdate": "2022-03-24T05:07:51.651876+00:00",
        "auditeesname": "prit",
        "msaprid": 1,
        "remark": "First attempt",
        "commodityapp": [],
        "reason": "00",
        "part": "test1",
        "finalremarks": "2022-03-24 05:17:47.979498",
        "lastAssesmentScore": "NA",
        "decision": "undefined"},
        {
            "CompanyManagement": [1, 0, 80],
            "Technology": [0, 0, 68],
            "PurchasingAndSCM": [0, 0, 90],
            "ProcessControlAndAnalysis": [0, 0, 88],
            "ProgramManagement": [0, 0, 80],
            "CustomerSupport": [0, 0, 100]
        },
        {"finalscore": 57}];
    const [msaDetails, score, finalScore] = details
    console.log("list data", msaDetails, finalScore, score)
    const {suppliername, auditorname, startdate, auditeesname, msaprid, remark,commodityapp, reason, part, finalremarks, lastAssesmentScore, decision } = msaDetails
    console.log( msaprid, remark)
    const auditType = ""
    const {CompanyManagement, Technology, PurchasingAndSCM, ProcessControlAndAnalysis, ProgramManagement, CustomerSupport} = score
    const {finalscore} = finalScore
    const stack1 = []
    const stack2 = []
    const stack3 = []
    const startDate = Moment(startdate).format("MMMM D, YYYY")
    const pillarnames = Object.keys(score);
    const pillarvalues = Object.values(score);
    for(let i=0; i < pillarvalues.length; i+= 1) {
        stack1.push(pillarvalues[i][0]);
        stack2.push(pillarvalues[i][1]);
        stack3.push(pillarvalues[i][2])
    }
    let dataval = 0.0
    let a2 = 0.0
    for(let i = 0 ; i < stack3.length; i+=1){
        dataval+=parseFloat(stack3[i]);
        a2 = dataval/stack3.length
    }
    function getDecision(fscore) {
        let dcsion = ""
        // $(".finalscore").append(a2.toFixed(2));
        if (fscore>=0 && fscore <=70)
        {
            dcsion ='Not Capable';
        }
        if(fscore >=71 && fscore<=80)
        {
            dcsion = 'Conditional Approved';
        }
        if (fscore >=81)
        {
            dcsion= 'Capable';
        }
        return dcsion
    }

    
    function getgaugedata(d1) {
        const customersupportoption = {
                    series: [{
                        type: 'gauge',
                        style: {height: "5vh", width: "5vw"},
                        axisLine: {
                            lineStyle: {
                                width: 10,
                                color: [
                                    [0.4, '#db4921'],
                                    [0.6, '#d1c81f'],
                                    [1, '#1fd13d']
                                ]
                            }
                        },
                        pointer: {
                            itemStyle: {
                                color: 'auto'
                            }
                        },
                        splitNumber: 'Nan',
                        axisTick: {
                            distance: -20,
                            length: 4,
                            lineStyle: {
                                color: '#fff',
                                width: 3
                            }
                        },
                        splitLine: {
                            distance: -20,
                            length: 20,
                            lineStyle: {
                                color: '#fff',
                                width: 3
                            }
                        },
                        axisLabel: {
                            color: 'auto',
                            distance: 10,
                            fontSize: 1
                        },
                        detail: {
                            valueAnimation: true,
                            formatter: '{value} %',
                            color: 'auto'
                        },
                        data: [{
                            value: d1
                        }]
                    }]
                };
    return customersupportoption;
    }
    function showpillarchart(stk1, stk2) {
                    const option = {
                            tooltip: {
                                trigger: 'axis',
                                
                            },
                            legend: {
                                data: ["Veto", "Other"],
                                bottom: -5,
                            },
                            grid: {
                                left: '3%',
                                right: '4%',
                                bottom: '3%',
                                containLabel: true
                            },
                            xAxis: {
                                type: 'value'
                            },
                            yAxis: {
                                type: 'category',
                                data: pillarnames
                            },
                            series: [
                                {
                                    name: 'Veto',
                                    type: 'bar',
                                    stack: 'total',
                                    label: {
                                        show: true
                                    },
                                    emphasis: {
                                        focus: 'series'
                                    },
                                    // color: "#1a8fc9",
                                    color: "#d13040",
                                    data: stk1
                                },
                                {
                                    name: 'Other',
                                    type: 'bar',
                                    stack: 'total',
                                    label: {
                                        show: true
                                    },
                                    emphasis: {
                                        focus: 'series'
                                    },
                                    // color: "#d95d1a",
                                    color: "#0000FF",
                                    data: stk2
                                },
                                
                                
                                
                            ]
                        };
                        return option;
    }
console.log("companyManagement ", CompanyManagement)                
    return (
        <div className="container-fluid">
            {/* <div className="container-fluid"> */}
            <div className="row mt-2 mx-1 text-light bg-primary rounded">
                <div className="col mx-auto text-center p-1">
                    <h3>MSA Project Score Summary Page</h3>
                </div>
            </div>
            {/* {details.map((value) => {    
                const [assignmentDetails] = value
                const {suppliername, auditorname, startdate, auditeesname, msaprid, remark,commodityapp, reason, part, finalremarks, lastAssesmentScore, decision } = assignmentDetails
                console.log(msaprid, remark,commodityapp, reason, part, finalremarks)                                
            return (
                <div> */}
            <div className="row mt-2">
                <div className="col-md-4">
                    <b>Supplier Name:</b> {suppliername}
                </div>
                <div className="col-md-5">
                    <b>Auditors Name:</b> {auditorname}
                </div>
                <div className="col-md-3">
                    <b>Date of Assessment:</b> {startDate}
                </div>
            </div>
    <div className="row pb-2 border-bottom border-primary">
        <div className="col-md-4"><b>Supplies to TML Plant:</b></div>
        <div className="col-md-3">
            <b>Auditees Name:</b> {auditeesname}
        </div>
    </div>
    <div className="row mt-4">
        <div className="col-md-4 border-right border-info">
            <div className="row">
                <div className="col-md-12 mx-auto">
                <b>Pillar Wise clauses scored Red</b>
                </div>
            </div>
            <div className="row">
                <ReactEcharts  className="col-md-12" id="myvetochart" style={{width: "450px", height: "550px"}} option={showpillarchart(stack1, stack2)}/>
            </div>
        </div>
        <div className="col-md-5 border-right border-info">
            <div className="row">
                <div className="col-md-12" id="assessmentscore">
                    <div className="row">
                        <div className="col-md-12 text-center">
                            Pillar wise assessment score
                        </div>
                    </div>
                    <div className="row mt-1">
                        <div className="col-md-12 text-center">
                            <b>Supplier Capability</b>
                        </div>
                    </div>
                    <div className="row">
                        <ReactEcharts className="col-md-6 ggchart" option={getgaugedata(CustomerSupport[2])} style={{ height: "20vh", width: "20vw"}} />
                        <ReactEcharts className="col-md-6 ggchart" option={getgaugedata(ProgramManagement[2])} style={{ height: "20vh", width: "20vw" }} />
                    </div>
                    <div className="row">
                        <div className="col-md-4 ml-5">
                            <a href="/msadeptqav?dept=6&msaid={{msaprid}}" style={{textDecoration: "none"}}>Customer Support</a>
                        </div>
                        <div className="col-md-5 ml-5">
                            <a href = "/msadeptqav?dept=5&msaid={{msaprid}}" style={{textDecoration: "none"}}>Program Management</a>
                        </div>
                    </div>
                    <div className="row mt-4">
                        <ReactEcharts className="col-md-6 ggchart" id="processcontrol" option={getgaugedata(ProcessControlAndAnalysis[2])} style={{ height: "20vh", width: "20vw"}}/>
                        <ReactEcharts className="col-md-6 ggchart" id="purchasing" option={getgaugedata(PurchasingAndSCM[2])} style={{ height: "20vh", width: "20vw"}}/>
                    </div>
                    <div className="row">
                        <div className="col-md-5 ml-3">
                            <a href = "/msadeptqav?dept=4&msaid={{msaprid}}" style={{textDecoration: "none"}} >Process Control & Analysis</a>
                        </div>
                        <div className="col-md-5 ml-5">
                            <a href = "/msadeptqav?dept=3&msaid={{msaprid}}" style={{textDecoration: "none"}}>Purchasing and SCM</a>
                        </div>
                    </div>
                    <div className="row mt-4">
                        <ReactEcharts className="col-md-6 ggchart" id="company" option={getgaugedata(CompanyManagement[2])} style={{ height: "20vh", width: "20vw"}}/>
                        <ReactEcharts className="col-md-6 ggchart" id="technology" option={getgaugedata(Technology[2])} style={{ height: "20vh", width: "20vw"}}/>
                    </div>
                    <div className="row">
                        <div className="col-md-5 ml-5">
                            <a href = "/msadeptqav?dept=1&msaid={{msaprid}}" style={{textDecoration: "none"}}>Company Management</a>
                        </div>
                        <div className="col-md-4 ml-5">
                            <a href = "/msadeptqav?dept=2&msaid={{msaprid}}" style={{textDecoration: "none"}}>Technology</a>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
        <div className="col-md-3">
            <div className="row">
                <div className="col-md-12 ml-auto">
                    <b>Project Information</b>
            </div>
            </div>
            <div className="row ml-2">
                MSA Reason: {reason}
            </div>
            <div className="row ml-2">
                Type of Audit: {auditType}
            </div>
            <div className="row ml-2">
                <ul>
                {commodityapp.map(capp => (<li>{capp.commodityname}</li>))}
                </ul>
            </div>
            <div className="row ml-2">
                {/* <!-- <li>Safety related part</li> --> */}
                <li>Details of the part audited : {part}</li>
            </div>
        </div>
    </div>

    <div className="row mt-2 border-top pt-2 border-info">
        <div className="col-md-4 mt-2">
            <div className="row">
                <label htmlFor="overalscore" className="mx-4 p-2 card border border-secondary" style={{backgroundColor: "skyblue"}}>Overall Score: 
                <div  id ="overalscore" className="mt-1 overalscore" style={{fontSize: "24px"}}>{a2.toFixed(2)}</div></label>
            </div>
            <div className="row mt-2">
                <label htmlFor="finalscore" className="mx-4 p-2 card border border-secondary" style={{backgroundColor: "skyblue"}}>Final Score: 
		        <div className="mt-1 finalscore" style={{fontSize: "24px"}}>{finalscore.toFixed(2)}</div></label>
            </div>
            <div className="row mt-2">
                <label htmlFor="lastscore" className="mx-4 p-2 card border border-secondary" style={{backgroundColor: "skyblue"}}>Last Assessment Score:
                <div className="mt-1" style={{fontSize: "24px"}}>{lastAssesmentScore}</div> </label>
            </div>
        </div>
        <div className="col-md-5 mt-2">
            <div className="row">
            <div className="col-md-4">
                  <label htmlFor="decsionscore" className="mx-4 p-2 card border border-secondary" style={{backgroundColor: "skyblue"}}>Decision: 
            
            <div className="col-md-6">
            {decision ?
                <div className="mt-1 card border border-secondary finaldecision" style={{fontSize: "24px", backgroundColor: "skyblue"}}>{getDecision(finalscore)}</div>
            :
            <select name="prdecide" className="form-control" id="prdecide1">
                <option value="0" style={{fontSize: "20px"}}>Select Decision</option>
                <option value="capable" style={{backgroundColor: "#18ba28",fontSize: "20px"}}>Capable</option>
                <option value="conditional_approved" style={{backgroundColor: "#d9ba1e",fontSize: "20px"}}>Conditional Approved</option>
                <option value="not_capable" style={{backgroundColor: "#d1281f", fontSize: "20px"}}>Not Capable</option>
            </select>}
            </div></label>
            </div>
        </div>
        </div>
        <div className="col-md-3 mt-2">
            <div className="row">
            {decision ?     
            <textarea name="remarks" readOnly className="form-control" id="msaleadremark" placeholder="remarks"  cols="35" rows="4">{finalremarks}</textarea>
            : <textarea name="remarks" className="form-control" id="msaleadremark" placeholder="remarks"  cols="35" rows="4">{finalremarks}</textarea>
            }
            </div>
            {/* {sbnnot &&
            <div class="row mt-4">
                <button class="btn btn-success sub"><i class="fa fa-exclamation-circle" aria-hidden="true"></i>&nbsp; Submit MSA</button>
            </div>
            } */}
        </div>
    </div>
    
{/* </div>);})} */}
</div>
);
}

export default Scorecard;
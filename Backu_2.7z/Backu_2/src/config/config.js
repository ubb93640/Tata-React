export default {
  ...window.epAppData,
};

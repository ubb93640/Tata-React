/* eslint-disable import/no-named-as-default-member */
import React, { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import plantStoreActions from '../../redux/features/plantStore/actions';

const savePlantToLocalStorage = data => {
  localStorage.setItem('plantValue', data.value);
  localStorage.setItem('plantLabel', data.label);
};

function useQuery() {
  return new URLSearchParams(useLocation().search);
}

const PlantsHandler = ({
  isAuthenticated,
  children,
  plant,
  initializePlantStore,
}) => {
  const query = useQuery();

  useEffect(() => {
    if (plant?.value && plant?.label) savePlantToLocalStorage(plant);
  }, [isAuthenticated, plant]);

  useEffect(() => {
    // adding query into dependency arr is causing loops
    if (isAuthenticated) initializePlantStore(query.get('plant'));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAuthenticated, initializePlantStore]);

  return <>{children}</>;
};

PlantsHandler.propTypes = {
  children: PropTypes.any,
  isAuthenticated: PropTypes.bool.isRequired,
  plant: PropTypes.shape({
    value: PropTypes.any,
    label: PropTypes.string,
  }),
  initializePlantStore: PropTypes.func.isRequired,
};

export default connect(
  ({ auth, plantStore }) => ({
    isAuthenticated: auth.isAuthenticated,
    plant: plantStore.plant,
  }),
  { initializePlantStore: plantStoreActions.initializePlantStore },
)(PlantsHandler);

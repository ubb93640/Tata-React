/* eslint-disable react/prop-types */
import React, { useState } from 'react';
import { Tabs, Tab } from '@material-ui/core';
import PropTypes from 'prop-types';
import styles from './TabbedWorkspace.module.css';

const Panel = ({ children, value, index }) => {
  if (index !== value) return <div style={{ display: 'none' }} />;
  return <>{children}</>;
};

const TabbedWorkspace = ({ tabs }) => {
  const [tabVal, setTabVal] = useState(0);
  const handleTabChange = (value) => {
    setTabVal(value);
  };

  return (
    <div className={styles.workspace}>
      <div className={styles.tabBar}>
        <Tabs
          value={tabVal}
          onChange={(e, value) => handleTabChange(value)}
          aria-label="workspace type selection tabs"
          TabIndicatorProps={{ style: { background: '#0275a7' } }}
          className={styles.tabs}
        >
          {tabs.map((tab) => (
            <Tab className={styles.tab} label={tab.label} />
          ))}
        </Tabs>
      </div>
      {tabs.map((tab, index) => (
        <Panel value={tabVal} index={index}>
          <tab.component {...tab.props} />
        </Panel>
      ))}
    </div>
  );
};

TabbedWorkspace.propTypes = {
  tabs: PropTypes.arrayOf(
    PropTypes.shape({
      label: PropTypes.string.isRequired,
      component: PropTypes.node.isRequired,
      props: PropTypes.object,
    })
  ).isRequired,
};

Panel.propTypes = {
  children: PropTypes.node.isRequired,
  value: PropTypes.number.isRequired,
  index: PropTypes.number,
};

export default TabbedWorkspace;

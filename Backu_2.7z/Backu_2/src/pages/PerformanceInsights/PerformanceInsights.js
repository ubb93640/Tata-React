import React from 'react';
import PropTypes from 'prop-types';
// import {BrowserRouter as Router, Route } from "react-router-dom";
import { connect } from 'react-redux';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';

// import Home from './Home';
import Contact from '../../components/Contact';
import ActionPlan from '../../components/ActionPlan';

// import Card from '../../components/Card'; 
// import ActionPlanIdAttachment from '../../components/ActionPlanIdAttachment';
import styles from './PerformanceInsights.module.css';
import Home from '../../components/Home';

const PerformanceInsights = () => (
  <div className={styles.container} >
    {/* <Card /> */}
    <Router>
      <Switch>
        <Route path="/" exact>
          <Home />
        </Route>
        <Route path="/actionplan" exact>
          <ActionPlan />
        </Route>
        <Route path="/contact" exact>
          <Contact />
        </Route>
      </Switch>
    </Router>
  </div>
);

PerformanceInsights.propTypes = {
  currentPlant: PropTypes.shape({
    value: PropTypes.any,
    label: PropTypes.string,
  }),
};

export default connect(({ userProfile }) => ({
  currentUserPersona: userProfile.persona,
  userMaterialGroups: userProfile.userMaterialGroups,
}))(PerformanceInsights);

import { API } from '../../../apis/api';
import { buildErrorMessage } from '../../../apis/calls';
import { API_RESOURCE_URLS } from '../../../constants';
import {
  INITIALIZE_USER_PROFILE,
  LOAD_USER_MATERIAL_GROUPS,
} from './actionTypes';

const initializeUserProfile = (plant, userId) => async dispatch => {
  try {
    const response = await API.get(
      API_RESOURCE_URLS.userPersona(plant, userId),
    );
    const { persona } = response.data;
    dispatch({ type: INITIALIZE_USER_PROFILE, payload: { persona, userId } });
  } catch (error) {
    dispatch({
      type: INITIALIZE_USER_PROFILE,
      payload: { persona: null, userId: null },
    });
    console.error('failed to load user persona', error);
  }
};

const loadUserMaterialGroups = (
  plant,
  userId,
  cancelTokenSource,
) => async dispatch => {
  let payload;
  try {
    const response = await API.get(
      API_RESOURCE_URLS.materialGroups(plant, userId),
      { cancelToken: cancelTokenSource?.token },
    );
    payload = response.data;
  } catch (error) {
    console.error(
      `Failed to load Material Groups for plant:${plant} and userId:${userId}`,
      error,
      buildErrorMessage(error),
    );
    payload = [];
  }
  dispatch({
    type: LOAD_USER_MATERIAL_GROUPS,
    payload,
  });
};

export default {
  initializeUserProfile,
  loadUserMaterialGroups,
};

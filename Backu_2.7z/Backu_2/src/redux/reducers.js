import { combineReducers } from 'redux';

import authReducer from './features/auth/authSlice';
import plantStoreReducer from './features/plantStore/plantStoreSlice';
import userProfileReducer from './features/userProfile/userProfileSlice';

const rootReducer = combineReducers({
  auth: authReducer,
  plantStore: plantStoreReducer,
  userProfile: userProfileReducer,
});

export default rootReducer;

import React from 'react';
import PropTypes from 'prop-types';
import { Route } from 'react-router-dom';
import { connect } from 'react-redux';
import { PERSONAS } from '../constants';

const PrivateRoute = ({
  component: Component,
  componentProps,

  ...rest
}) => (
  <Route
    {...rest}
    render={() =>
      <Component {...componentProps} />
    }
  />
);

PrivateRoute.propTypes = {
  component: PropTypes.any.isRequired,
  componentProps: PropTypes.object,
  isAuthenticated: PropTypes.bool.isRequired,
  user: PropTypes.object,
  allowedPersonas: PropTypes.arrayOf(Object.values(PERSONAS)),
  userPersona: PropTypes.oneOf(Object.values(PERSONAS)),
};

PrivateRoute.defaultProps = {
  componentProps: {},
};

export default connect(({ auth, userProfile }) => ({
  isAuthenticated: auth.isAuthenticated,
  user: auth.user,
  userPersona: userProfile.persona,
}))(PrivateRoute);

// jest-dom adds custom jest matchers for asserting on DOM nodes.
// allows you to do things like:
// expect(element).toHaveTextContent(/react/i)
// learn more: https://github.com/testing-library/jest-dom
import '@testing-library/jest-dom';

global.epAppData = {
  API_BASE_URL: 'https://fake.api.domain',
  ENV_TYPE: 'TEST',
};

const mockAxios = jest.genMockFromModule('axios');

jest.mock('./apis/api', () => ({
  API: mockAxios,
  CancelToken: {
    source: () => ({
      token: 'fake_test_token',
      cancel: jest.fn(),
      disconnect: jest.fn(),
    }),
  },
}));

/* Since the Table component uses Virtualized List with Autosizer, in jest
 * dom(during tests) the Autosizer does not get any actual height and width
 * in headless mode (jest dom) and hence collapses. So we need to override
 * the AutoSizer so that it calls its children with arbitrary height and width
 * so that elements can be rendered in tests. */
jest.mock('react-virtualized', () => {
  const ReactVirtualized = jest.requireActual('react-virtualized');
  return {
    ...ReactVirtualized,
    AutoSizer: ({ children }) => children({ height: 1000, width: 1000 }),
  };
});

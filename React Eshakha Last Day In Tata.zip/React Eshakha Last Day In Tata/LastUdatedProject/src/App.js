import React, { useEffect } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { Switch, Route } from 'react-router-dom';
import PrivateRoute from './routing/PrivateRoute';
import { overrideConsole } from './hooks/loggingErrors';
import { PerformanceInsights } from './pages';
import HeaderAndFooter from './layouts/HeaderAndFooter/HeaderAndFooter';
import Contact from './components/Contact';
import ActionPlan from './components/UserActionPlan/ActionPlan';

function App({ isAuthenticated, user }) {
  const addLoggingHooks = () => {
    window.onerror = (message, source, lineno, colno, error) => {
      if (error.stack) {
        const sourceFunction = error.stack.split('\n')[1];
        console.error(new Error(message + sourceFunction));
      } else {
        console.error(error);
      }
    };
    const newConsole = overrideConsole(window.console, user?.userId);
    window.console = newConsole;
  };

  useEffect(() => {
    if (isAuthenticated) {
      addLoggingHooks();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  return (
    <div className="App">
      <Switch>
        <HeaderAndFooter>
          <PrivateRoute exact path="/" component={PerformanceInsights} />
          <Route path="/actionplan" exact>
            <ActionPlan />
          </Route>
          <Route path="/contact" exact>
            <Contact />
          </Route>
        </HeaderAndFooter>
      </Switch>
    </div>
  );
}

App.propTypes = {
  isAuthenticated: PropTypes.bool.isRequired,
  user: PropTypes.object,
};

export default connect(({ auth }) => ({
  isAuthenticated: auth.isAuthenticated,
  user: auth.user,
}))(App);

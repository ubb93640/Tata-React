import React from "react";
import { Link } from "react-router-dom";
// import { Button } from 'react-bootstrap';
import Moment from 'moment';
// import Modal from 'react-bootstrap/Modal';
import '../../App.css';
import './ActionPlan.css';
// import dumyData from  './MSAReport.json';


export default function ActionPlan() {
    const { supplier } = {
        "supplier": [
            [
                {
                    "id": 1,
                    "proid": "MSAB0640023032022",
                    "updated_at": "2022-03-24T05:07:51.651Z",
                    "startdate": "2022-03-24",
                    "enddate": "2022-03-25",
                    "MSAClosure_date": "2022-04-05T07:14:38.121Z"
                },
                "2025-04-05",
                "57",
                {
                    "null": 1
                }
            ],
            [
                {
                    "id": 2,
                    "proid": "MSAB0640022032022",
                    "updated_at": "2022-03-24T06:02:46.865Z",
                    "startdate": "2022-03-24",
                    "enddate": "2022-03-25",
                    "MSAClosure_date": "2022-04-05T07:14:38.121Z"
                },
                "2025-04-05",
                "57",
                {
                    "null": 1
                }
            ],
            [
                {
                    "id": 8,
                    "proid": "MSAB0640028032022",
                    "updated_at": "2022-03-28T04:46:55.890Z",
                    "startdate": "2022-03-28",
                    "enddate": "2022-03-29",
                    "MSAClosure_date": "2022-04-05T07:14:38.121Z"
                },
                "2025-04-05",
                "91",
                {
                    "null": 1
                }
            ],
            [
                {
                    "id": 9,
                    "proid": "MSAB0640029032022",
                    "updated_at": "2022-03-31T12:15:06.738Z",
                    "startdate": "2022-03-31",
                    "enddate": "2022-04-04",
                    "MSAClosure_date": "2022-04-05T07:14:38.121Z"
                },
                "2025-04-05",
                "20",
                {
                    "null": 1
                }
            ],
            [
                {
                    "id": 10,
                    "proid": "MSAB0640030032022",
                    "updated_at": "2022-03-31T12:19:11.953Z",
                    "startdate": "2022-03-31",
                    "enddate": "2022-04-04",
                    "MSAClosure_date": "2022-04-05T07:14:38.121Z"
                },
                "2025-04-05",
                "93",
                {
                    "null": 1
                }
            ],
            [
                {
                    "id": 11,
                    "proid": "MSAB0640031032022",
                    "updated_at": "2022-03-31T12:26:37.446Z",
                    "startdate": "2022-03-31",
                    "enddate": "2022-04-04",
                    "MSAClosure_date": "2022-04-05T07:14:38.121Z"
                },
                "2025-04-05",
                "90",
                {
                    "null": 1
                }
            ],
            [
                {
                    "id": 12,
                    "proid": "MSAB0640001042022",
                    "updated_at": "2022-04-01T03:33:26.018Z",
                    "startdate": "2022-04-01",
                    "enddate": "2022-04-04",
                    "MSAClosure_date": "2022-04-05T07:14:38.121Z"
                },
                "2025-04-05",
                "92",
                {
                    "null": 1
                }
            ],
            [
                {
                    "id": 14,
                    "proid": "MSAB0640005042022",
                    "updated_at": "2022-04-05T07:51:49.517Z",
                    "startdate": "2022-04-05",
                    "enddate": "2022-04-08",
                    "MSAClosure_date": "2022-04-05T07:51:49.517Z"
                },
                "2025-04-05",
                "87",
                {
                    "null": 1
                }
            ],
            [
                {
                    "id": 15,
                    "proid": "MSAB0640003042022",
                    "updated_at": "2022-04-07T10:25:29.232Z",
                    "startdate": "2022-04-06",
                    "enddate": "2022-04-09",
                    "MSAClosure_date": "2022-04-07T10:25:29.232Z"
                },
                "2025-04-07",
                "86",
                {
                    "null": 1
                }
            ],
            [
                {
                    "id": 16,
                    "proid": "MSAB0640006042022",
                    "updated_at": "2022-04-07T10:49:53.446Z",
                    "startdate": "2022-04-06",
                    "enddate": "2022-04-09",
                    "MSAClosure_date": "2022-04-07T10:49:53.446Z"
                },
                "2025-04-07",
                "93",
                {
                    "null": 1
                }
            ],
            [
                {
                    "id": 17,
                    "proid": "MSAB0640002042022",
                    "updated_at": "2022-04-14T10:15:32.344Z",
                    "startdate": "2022-04-07",
                    "enddate": "2022-04-09",
                    "MSAClosure_date": "2022-04-14T10:15:32.344Z"
                },
                "2025-04-14",
                "52",
                {
                    "null": 1
                }
            ],
            [
                {
                    "id": 19,
                    "proid": "MSAB0640007042022",
                    "updated_at": "2022-04-08T05:35:19.824Z",
                    "startdate": "2022-04-07",
                    "enddate": "2022-04-09",
                    "MSAClosure_date": "2022-04-08T05:35:19.824Z"
                },
                "2025-04-08",
                "86",
                {
                    "null": 1
                }
            ],
            [
                {
                    "id": 20,
                    "proid": "MSAB0640008042022",
                    "updated_at": "2022-04-12T10:13:14.820Z",
                    "startdate": "2022-04-08",
                    "enddate": "2022-04-13",
                    "MSAClosure_date": "2022-04-12T10:13:14.820Z"
                },
                "2025-04-12",
                "72",
                {
                    "null": 1
                }
            ],
            [
                {
                    "id": 23,
                    "proid": "MSAB0640010042022",
                    "updated_at": "2022-04-13T06:18:07.420Z",
                    "startdate": "2022-04-13",
                    "enddate": "2022-04-15",
                    "MSAClosure_date": "2022-04-13T06:18:07.420Z"
                },
                "2025-04-13",
                "52",
                {
                    "null": 1
                }
            ],
            [
                {
                    "id": 24,
                    "proid": "MSAB0640013042022",
                    "updated_at": "2022-04-13T12:53:54.230Z",
                    "startdate": "2022-04-13",
                    "enddate": "2022-04-16",
                    "MSAClosure_date": "2022-04-13T12:53:54.230Z"
                },
                "2025-04-13",
                "52",
                {
                    "null": 1
                }
            ],
            [
                {
                    "id": 25,
                    "proid": "MSAB0640018042022",
                    "updated_at": "2022-04-18T06:53:57.768Z",
                    "startdate": "2022-04-18",
                    "enddate": "2022-04-19",
                    "MSAClosure_date": "2022-04-18T06:53:57.768Z"
                },
                "2025-04-18",
                "57",
                {
                    "null": 1
                }
            ],
            [
                {
                    "id": 26,
                    "proid": "MSAB0640016042022",
                    "updated_at": "2022-04-19T05:41:30.751Z",
                    "startdate": "2022-04-19",
                    "enddate": "2022-04-21",
                    "MSAClosure_date": "2022-04-19T05:41:30.751Z"
                },
                "2025-04-19",
                "55",
                {
                    "null": 1
                }
            ],
            [
                {
                    "id": 27,
                    "proid": "MSAB0640019042022",
                    "updated_at": "2022-04-21T06:10:21.174Z",
                    "startdate": "2022-04-19",
                    "enddate": "2022-04-22",
                    "MSAClosure_date": "2022-04-21T06:10:21.174Z"
                },
                "2025-04-21",
                "55",
                {
                    "null": 1
                }
            ],
            [
                {
                    "id": 32,
                    "proid": "MSAB0640027042022",
                    "updated_at": "2022-04-27T04:13:58.255Z",
                    "startdate": "2022-04-27",
                    "enddate": "2022-04-30",
                    "MSAClosure_date": "2022-04-27T04:13:58.255Z"
                },
                "2025-04-27",
                "57",
                {
                    "CV Body": 1,
                    "CV Chassis": 2,
                    "CV Defence": 3
                }
            ],
            [
                {
                    "id": 36,
                    "proid": "MSAB0640001052022",
                    "updated_at": "2022-05-01T13:55:08.992Z",
                    "startdate": "2022-05-01",
                    "enddate": "2022-05-04",
                    "MSAClosure_date": "2022-05-01T13:55:08.992Z"
                },
                "2025-05-01",
                "40",
                {
                    "CV Body": 1,
                    "CV Chassis": 2
                }
            ],
            [
                {
                    "id": 38,
                    "proid": "MSAB0640006052022",
                    "updated_at": "2022-05-09T07:33:29.226Z",
                    "startdate": "2022-05-06",
                    "enddate": "2022-05-09",
                    "MSAClosure_date": "2022-05-09T07:33:29.226Z"
                },
                "2025-05-09",
                "71",
                {
                    "CV Body": 1,
                    "CV Chassis": 2
                }
            ],
            [
                {
                    "id": 39,
                    "proid": "MSAB0640009052022",
                    "updated_at": "2022-05-17T12:12:35.416Z",
                    "startdate": "2022-05-09",
                    "enddate": "2022-05-12",
                    "MSAClosure_date": "2022-05-17T12:12:35.416Z"
                },
                "2025-05-17",
                "74",
                {
                    "CV Body": 1,
                    "PV Casting, Forging and Machinery": 2
                }
            ]
        ]
    }
    return (
        <div className="container-fluid">
            <div className="row rounded">
                <div className="col-md-12">
                    {/* <h3 className="card-header text-center text-light my-4 py-2"
                            // fontFamily: uni_neueregular, 
                            style={{color: '#ffffff', fontFamily: 'uni_neueregular',backgroundColor: '#1976d2'}}>Projects</h3> */}
                    <h3 className="card-header text-center text-light my-4 py-2" style={{ background: "#1976d2" }}
                    >Projects</h3>
                </div>
            </div>
            <div className="row">
                <div className="col-md-2 ml-auto">
                    <input type="text" id="search" placeholder="Search..." className="form-control mb-1 border-primary" />
                </div>
            </div>

            {/* <div className="col-md-12"> */}
            <div className="row mb-3" style={{ height: "460px", overflow: "scroll" }}>
                <div id="table" className="col-md-12">
                    <table className="table table-hover table-bordered" id="mytable">
                        <thead className="" style={{ fontSize: "18px", borderColor: "#000000" }}>
                            <tr>
                                <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }}>Project ID<br /> <small>(Click for report)</small></th>
                                <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }}>Assignment Date</th>
                                <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }}>Assessment Start Date</th>
                                <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }}>Assessment End Date</th>
                                <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }}>MSA Closure date</th>
                                <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }}>MSA Validity End date</th>
                                <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }}>MSA Score</th>
                                <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }}>Commodity</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                supplier.map(item => {
                                    console.log("sup : ", supplier)
                                    const updatedAt = Moment(item[0].updated_at).format("MMMM D, YYYY")
                                    const startDate = Moment(item[0].startdate).format("MMMM D, YYYY")
                                    const endDate = Moment(item[0].enddate).format("MMMM D, YYYY")
                                    const msaValidity = Moment(item[1]).format("MMMM D, YYYY")
                                    const MSAClosureDate = Moment(item[0].MSAClosure_date).format("MMMM D, YYYY")
                                    return (
                                        <tr key={item[0].id} className={`tbl${item[0].id}`}>
                                            {/* <td><a href="{url 'scorecard' id}">{item.proId}</a></td> */}
                                            <td>
                                                {/* <Rourter> */}
                                                <Link to={`/scorecard/${item[0].id}`}>{item[0].proid}</ Link>
                                                {/* <Route path="/scorecard/:id" component={Scorecard} /> */}
                                                {/* </Rourter> */}
                                            </td>
                                            <td>{updatedAt}</td>
                                            <td>{startDate}</td>
                                            <td>{endDate}</td>
                                            <td>{MSAClosureDate}</td>
                                            <td>{msaValidity}</td>
                                            <td>{item[2]}</td>
                                            <td>
                                                {Object.keys(item[3]).map((key) => (<ul>
                                                    {key === 'null' ? <li>None</li> : <li>{key}</li>}
                                                </ul>
                                                )
                                                )}
                                            </td>
                                        </tr>);
                                })
                            }
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
}
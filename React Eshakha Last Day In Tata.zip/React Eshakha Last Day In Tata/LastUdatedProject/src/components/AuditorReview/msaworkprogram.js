import React from "react";
// import DOMPurify from "dompurify";
// import { Markup } from 'interweave';
// import '../../App.css';
import './qadeptvreport.css';
// import dumyData from  './qadeptvreport.json';

export default function AuditorReview() {


    // const sanitizer = dompurify.sanitize;
    return (
        <div className="container-fluid">
            <div className="row">
                <div className="col-md-12 text-center border border-warning rounded  p-2" style={{ backgroundColor: "#f2c830" }}>
                    <h3><b>Program Managent</b></h3>
                </div>
            </div>
            <div className="row">
                <div className="col-md-12 border border-warning rounded  p-2">
                    <b className="subfunctionalarea ml-4"> </b>
                </div>
            </div>
            <div className="row">
                <div className="col-md-4 text-danger m-2 text-center p-1"><h4 className="VirAssessment_flag">This question is virtual Audited question</h4></div>
                {/* <!-- <div className="col-md-4 text-danger ml-auto mb-1"><h4 className="vetq">This question is Veto question</h4></div> --> */}
                <div className="col-md-3 text-danger m-2 text-center p-1 auddepttext" style={{ fontSize: "23px" }}> </div>
                <div className="col-md-4 text-danger m-2 text-center p-1"><h4 className="vetq">This question is Veto question</h4></div>
            </div>
            <div className="row">
                <div className="col-md-7">
                    <div className="row">
                        <div className="col-md-12 text-center">
                            <h3 className="text-light py-2 bg-primary rounded m-2 text-center p-1">Question For Assessment:</h3>
                            <br />
                            <div className="rounded mr-2 py-5 mb-4 ques ml-2"> </div>
                        </div>
                        <div className="col-md-12 mt-4">
                            <h4 className="text-light py-2 bg-success rounded m-2 text-center p-1">Observation and Remarks</h4>
                            <textarea name="self_observation" required id="self_observation" cols="86" rows="6" className="ml-2 rounded form-control pr-4" placeholder="Observation ( Minimum 30 characters required )" > </textarea>
                        </div>
                        <div className="col-md-12 mt-4 fintemplate1">
                            <h4 className="text-light py-2 bg-primary rounded m-2 text-center p-1">Finance Template</h4>
                            <div className="col-md-12">
                                <table className="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th scope="col">Input Table</th>
                                            <th scope="col">Template Upload</th>
                                        </tr>
                                    </thead>
                                    <tr>
                                        <td className="temfilename"> </td>
                                        <td>
                                            <input type="file" accept=".xls, .xlsx" id="templatefileven" style={{ display: "none" }} />
                                            {/* <label htmlFor="templatefileven" aria-controls="templatefileven"><i className="fa fa-file-text-o fa-2x btn-outline-success" aria-hidden="true"> </i></label> */}
                                            <div id="fintemuploaded"> </div>
                                        </td>
                                    </tr>
                                </table>
                                <small className="text-info">Click on file name to download and fill</small>
                            </div>
                        </div>

                    </div>
                </div>

                <div className="col-md-5">
                    <table className="table table-bordered border-secondary">
                        <thead className="text-light bg-primary py-2" style={{ background: "#768de8" }}>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Evidences</th>
                                <th scope="col">Select</th>
                                <th scope="col">Attachment</th>
                            </tr>
                        </thead>
                        <tbody className="tbody"> </tbody>
                    </table>
                </div>
            </div>
            <div className="modal fade" id="showloading" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <div className="modal-sm modal-dialog modal-dialog-centered" role="document">
                    <div className="modal-content">
                        <div className="text-center p-2 rounded">
                            <div className="spinner-grow text-primary" role="status">
                                <span className="sr-only">Loading...</span>
                            </div>
                            <div className="spinner-grow text-secondary" role="status">
                                <span className="sr-only">Loading...</span>
                            </div>
                            <div className="spinner-grow text-success" role="status">
                                <span className="sr-only">Loading...</span>
                            </div>
                            <div className="spinner-grow text-danger" role="status">
                                <span className="sr-only">Loading...</span>
                            </div>
                            <div className="spinner-grow text-warning" role="status">
                                <span className="sr-only">Loading...</span>
                            </div>
                            <div className="spinner-grow text-info" role="status">
                                <span className="sr-only">Loading...</span>
                            </div>
                        </div>

                    </div>

                </div>
            </div>
            <div className="row mt-4 mb-4">
                <div className="col-md-8 mb-4 mx-auto ">
                    <h4 className="text-center bg-info p-1  text-light rounded">What to Look For..</h4>
                    <div className="p-1 ques guidelines rounded" style={{ height: "210px", overflowY: "scroll" }}  > </div>
                </div>

            </div>
            <div className="row">
                <div className="col-md-2 bg-primary ml-4 text-light p-2 rounded scorem" style={{ fontSize: "large" }}>
                    <i className="fa fa-dot-circle-o" aria-hidden="true"> </i> Cumulative score:
                </div>
                <div className="col-md-2"> </div>
                <div className="col-md-4 mt-4 text-danger text-center vetoque1">
                    <h4 className="vetq">This question is Veto question</h4>
                    <h4 className="VirAssessment_flag">This question is virtual Audited question</h4>
                </div>


            </div>
            <div className="row mt-5">
                <div className="col-md-2">
                    <button className="btn btn-primary prev" type="button"><i className="fa fa-arrow-left" aria-hidden="true"> </i> Prev</button>
                </div>

                <div className="col-md-4 mx-auto sam">
                    <input type="range" min="-2" max="10" step="2" value="0" className="form-control auscore " />
                    <output className="bubble text-center ml-auto" style={{ fontSize: "26px" }}> </output>
                </div>

                <div className="col-md-4 center p-1 mx-auto">

                    <ul className="border border-info rounded bg-light d-none mytblinfo" style={{ fontSize: "12px" }}>
                        <li>NR - Not rated</li>
                        <li>0 - Requirement not Satisfied</li>
                        <li>4 - Requirement inadequately Satisfied</li>
                        <li>6 - Requirement partially Satisfied</li>
                        <li>8 - Requirement mainly Satisfied</li>
                        <li>10 - Fully Complaince</li>
                    </ul>
                </div>



                <div className="col-md-2">
                    <button className="btn btn-success float-right nexbtn nextbtn" type="button">Next <i className="fa fa-arrow-right" aria-hidden="true">  </i></button>
                    <button className="btn btn-primary float-right savebtn d-none" type="button">Save <i className="fa fa-arrow-right" aria-hidden="true"> </i></button>
                </div>
            </div>
            <div className="row m-4"> </div>

        </div>

    )
}
import React from "react";
// import DOMPurify from "dompurify";
// import { Markup } from 'interweave';
// import '../../App.css';
import './qadeptvreport.css';
// import dumyData from  './qadeptvreport.json';

export default function AuditorReview() {


    // const sanitizer = dompurify.sanitize;
    return (
        <div className="container-fluid">
            <div className="row">
                <div className="col-md-12 text-center border border-warning rounded  p-2" style={{ backgroundColor: "#f2c830" }}>
                    <h3><b>Customer Managent</b></h3>
                </div>
            </div>
            <div className="row">
                <div className="col-md-12 border border-warning rounded  p-2">
                    {/* <b className="subfunctionalarea ml-4">{qTitle}</b> */}
                </div>
            </div>
            <div className="row">
                <div className="col-md-12 border border-warning rounded  p-2">
                    <b className="subfunctionalarea ml-4"> </b>
                </div>
            </div>
            <div className="row">
                <div className="col-md-4 text-danger m-2 text-center p-1"><h4 className="VirAssessment_flag">This question is virtual Audited question</h4></div>
                <div className="col-md-3 text-danger m-2 text-center p-1 auddepttext" style={{ fontSize: "23px" }}> </div>
                {/* <!-- <div className="col-md-4 text-danger ml-auto mb-1"><h4 className="vetq">This question is Veto question</h4></div> --> */}
                <div className="col-md-4 text-danger m-2 text-center p-1"><h4 className="vetq">This question is Veto question</h4></div>

            </div>
            <div className="row">
                <div className="col-md-7">
                    <div className="row">
                        <div className="col-md-12 text-center">
                            <h3 className="col-md-12 text-light py-2 bg-primary rounded m-2 text-center p-1">Assessment Question:</h3>
                            <br />
                            <div className="col-md-12 rounded mr-2 py-5 mb-4 ques ml-2 quetiontext">  </div>
                        </div>
                        <div className="col-md-12 mt-4">
                            <h4 className="col-md-12 text-light py-2 bg-success rounded m-2 text-center p-1">Supplier Comments (Self Assessment)</h4>
                            <textarea name="self_observation" required id="self_observation" cols="86" rows="6" className="ml-2 rounded form-control pr-4" placeholder="Observation" disabled> </textarea>
                        </div>
                        <div className="col-md-12 mt-4">
                            <h4 className="col-md-12 text-light py-2 bg-info rounded m-2 text-center p-1">What to Look For..</h4>
                            <div className="col-md-12 ml-2 p-1 ques guidelines rounded" style={{ height: "210px", overflowY: "scroll" }}> </div>
                        </div>

                        <div className="col-md-12 mt-4 fintemplate1">
                            <h4 className="text-light py-2 bg-primary rounded m-2 text-center p-1">Finance Template</h4>
                            <div className="col-md-12">
                                <table className="table table-bordered">
                                    <thead className="thead-dark header">
                                        <tr>
                                            <th scope="col">Input Template</th>
                                            <th scope="col">Uploaded Template</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td className="temfilename"> </td>
                                            <td className="uploadfinfile"> </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="col-md-5">
                    <h3 className="text-light py-2 bg-primary rounded m-2 text-center p-1">Auditor Observation & Remarks</h3>
                    <br />
                    <textarea name="" cols="86" rows="6" className="ml-2 rounded form-control pr-4 auditorobservation" placeholder="Observation"  > </textarea>
                    <br />
                    <h4 className="text-light py-2 bg-primary rounded mx-2 text-center p-1">Attachments</h4>
                    <div style={{ height: "225px", overflow: "scroll" }}>
                        <table className="table table-hover table-bordered mx-2 rounded">
                            <thead className="thead-dark header">
                                <tr>
                                    <th scope="col" className="stickyheader">#</th>
                                    <th scope="col" className="stickyheader">Evidence</th>
                                    <th scope="col" className="stickyheader">Attachment</th>
                                </tr>
                            </thead>
                            <tbody className="fileslist">
                                -
                            </tbody>
                        </table>
                    </div>

                    <div className="mt-2">
                        <h4 className="text-center bg-info p-1  text-light rounded">Opportunity for Improvement</h4>
                        <textarea name="issue_Observed" id="issue_Observed" cols="86" rows="5" className=" rounded form-control pr-4 issue_Observed" disabled> </textarea>
                    </div>
                </div>


            </div>
            <div className="row">

                <div className="col-md-2 bg-primary ml-4 text-light p-2 rounded scorem" style={{ fontSize: "large" }} >
                    <i className="fa fa-dot-circle-o" aria-hidden="true"> </i> Cumulative score: <a1 id="cumscore1"> </a1>
                </div>
                <div className="col-md-2">  </div>
                <div className="col-md-4 mt-4 text-danger"><h4 className="vetq">This question is Veto question</h4>
                    <h4 className="VirAssessment_flag">This question is virtual Audited question</h4></div>
            </div>

            <div className="row mt-5">
                <div className="col-md-2">
                    <button className="btn btn-primary prev" type="button"><i className="fa fa-arrow-left" aria-hidden="true"> </i> Prev</button>
                </div>

                <div className="col-md-4 mx-auto sam">

                    <input type="range" id="myRange" min="-2" max="10" step="2" value="0" className="form-control auscore" aria-disabled="true" />
                    <output className="bubble text-center ml-auto" style={{ fontSize: "26px" }} disabled> </output>
                </div>

                <div className="col-md-4 center p-1 mx-auto">

                    <ul className="border border-info rounded bg-light d-none mytblinfo" style={{ fontSize: "12px" }}>
                        <li>NR - Not rated</li>
                        <li>0 - Requirement not Satisfied</li>
                        <li>4 - Requirement inadequately Satisfied</li>
                        <li>6 - Requirement partially Satisfied</li>
                        <li>8 - Requirement mainly Satisfied</li>
                        <li>10 - Fully Complaince</li>
                    </ul>
                </div>
                <div className="col-md-2">
                    <button className="btn btn-success float-right nexbtn nextbtn" type="button">Next <i className="fa fa-arrow-right" aria-hidden="true"> </i></button>
                    <button className="btn btn-primary float-right savebtn d-none" type="button">Continue <i className="fa fa-arrow-right" aria-hidden="true"> </i></button>
                </div>
            </div>
            <div className="row m-4" />
        </div>

    )
}
import React from 'react';
import { useHistory } from 'react-router-dom';

const Contact = () => {
  const history = useHistory();
  return (
    <>
      <h1>Contact Page</h1>
      <br />
      <button onClick={() => history.goBack()} type="button">Go Back</button>
    </>
  );
};

export default Contact;
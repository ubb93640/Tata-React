import React from "react";
// import { Link } from "react-router-dom";
// import { Button } from 'react-bootstrap';
// import Moment from 'moment';
// import Modal from 'react-bootstrap/Modal';
import '../../App.css';
// import './MSAReport.css';
// import dumyData from  './MSAReport.json';


export default function MSAReportUser() {

    return (
        <div className="container-fluid">
            <form method="POST">
                <div className="row mb-4 mt-4">
                    <div className="col-md-8">
                        <select className="js-example-basic-multiple form-control vendorsel"  >
                            <option value=" ">All vendors are selected and data can be downloaded</option>
                        </select>
                    </div>
                    <input type="hidden" name="vendorcodes" id="hidt" value="" />
                    <div className="col-md-2">
                        <button className="btn btn-success" type="button" disabled id="showdata">Show Data</button>
                    </div>
                    <div className="col-md-2">
                        <button className="btn btn-primary" type="button" id="downloaddata"><i className="fa fa-download" aria-hidden="true"> </i> Download Data</button>
                    </div>
                </div>
            </form>
            <div className="row vendata" style={{ height: " 400px", overflow: "scroll" }}>
                <div className="col-md-12">
                    <div id="table" className="table-editable">
                        <table className="table table-striped table-bordered rounded table-hover">
                            <thead className="thead-dark">
                                <tr>
                                    <th className="text-center stickyheader">Vendor Code</th>
                                    <th className="text-center stickyheader">Vendor Name</th>
                                    <th className="text-center stickyheader">Designation</th>
                                    <th className="text-center stickyheader">First Name</th>
                                    <th className="text-center stickyheader">Last Name</th>
                                    <th className="text-center stickyheader">Email ID</th>
                                    <th className="text-center stickyheader">Phone Number</th>
                                    <th className="text-center stickyheader">Location</th>
                                    <th className="text-center stickyheader">Last Updated On</th>

                                </tr>
                            </thead>
                            <tbody>
                                <tr className="tbl{{each.id}}">
                                    <td>A71720</td>
                                    <td>AUTOMOTIVE STAMPINGS AND ASSEMBLIES</td>
                                    <td>Managing Director</td>
                                    <td>testfirstname</td>
                                    <td>testlastname</td>
                                    <td>test1@gmail.com</td>
                                    <td>9098789767</td>
                                    <td>PUNE</td>
                                    <td>
                                        2022-04-26
                                    </td>

                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    );
}
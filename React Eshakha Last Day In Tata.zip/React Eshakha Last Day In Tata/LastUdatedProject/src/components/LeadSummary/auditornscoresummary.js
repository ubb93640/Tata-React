import React from "react";
// import DOMPurify from "dompurify";
// import { Markup } from 'interweave';
// import '../../App.css';
import './qacknowcontinue.css';
// import dumyData from  './qadeptvreport.json';

export default function LeadSummary() {
    // const [deptData, deptInfo] = [{
    //     "auditorobservation": "firsttest",
    //     "auditorscore": 10,
    //     "leadscore": 10,
    //     "leadobservation": "firsttest",
    //     "supplierobservation": "Are the TML requirements fulfilled in terms of product",
    //     "supplierscore": 10,
    //     "auditdept": "Advanced Quality",
    //     "question": "Are the TML requirements fulfilled in terms of product, process and Quality Management System?",
    //     "q_title": "6.1 - ",
    //     "guidelines": [" Organization has  fulfilled TML  specific requirements( mentioned in Supplier Quality manual/ SQ SOR)?\n", " Organization has QMS certification, valid and certified with latest revision.\n", " Regular Process audit for CTQ parameters\n", " Organization  include spare part requirement in production planning over regular production requirement from customer.\n", " Organization fulfills packaging/logistic requirements as per the SCM SOR?\n", " Does the product requalification's are carried out as per the customer's requirement?\n", " Does the product conform to legal/ statutory regulations?"],
    //     "veto": true,
    //     "VirAssessment_flag": true,
    //     "evidences": ["", " PPAP sign-off /TRSO sign-off\n", " Valid QMS certificates\n", " Process audit and statistical controls on CTQ- trend analysis\n", " Part-shipments to provide spares/first fill before start of full production\n", " Storage, scheduling, providing parts, shipping, compliance with customer specific packaging and identification regulation\n", " Quality agreements for PPM and delivery\n", " Product and shipping audit, dock audits\n", " Engineering test , reliability, durability & functional tests\n", " Compliance to packing standards\n", " Qualifications  & Requalification checks"],
    //     "filenames": [["", " PPAP sign-off /TRSO sign-off\n"], ["", " Valid QMS certificates\n"], ["", " Process audit and statistical controls on CTQ- trend analysis\n"], ["", " Part-shipments to provide spares/first fill before start of full production\n"], ["", " Storage, scheduling, providing parts, shipping, compliance with customer specific packaging and identification regulation\n"], ["", " Quality agreements for PPM and delivery\n"], ["", " Product and shipping audit, dock audits\n"], ["", " Engineering test , reliability, durability & functional tests\n"], ["", " Compliance to packing standards\n"], ["", " Qualifications  & Requalification checks"]],
    //     "ansid": 1
    // },
    // {
    //     "deptname": "Process Control and Analysis",
    //     "deptid": "6",
    //     "msapr": "1"
    // }
    // ]
    // const { auditorobservation, auditorscore, leadscore, leadobservation, supplierobservation, supplierscore, auditdept, question, qTitle, guidelines, veto, VirAssessmentFlag, evidences, filenames } = deptData;
    // const { deptname, deptid, msapr } = deptInfo
    // console.log(deptid, msapr)
    // console.log(leadscore, leadobservation, supplierobservation, evidences)

    // let guidelinestext = '';
    // if (guidelines) {
    //     let ab
    //     for (let i = 1; i < guidelines.length; i += 1) {
    //         ab = `-> &nbsp;&nbsp;  ${guidelines[i]}  <br>`;
    //         guidelinestext += ab;
    //     }
    // }
    // let financetem = ''
    // let financefileuploaded = ''
    // if ("auditorscore" in deptData) {
    //     financetem = deptData.financetem
    //     financefileuploaded = deptData.financefileuploaded
    //     console.log(" data is available", financetem)
    // }
    // else {
    //     console.log(" data is not available")
    // }
    // let filesnames = '';
    // if (filenames) {
    //     if (filenames.length === 0) {
    //         filesnames = "No Attachments"
    //     } else {
    //         let a
    //         for (let i = 0; i < filenames.length; i += 1) {
    //             a = `<tr><td> ${i + 1} </td><td>   ${filenames[i][1]} </td><td> <a href="/downloadfiles/${filenames[i][0]}"> ${filenames[i][0]} </a></td></tr>`;
    //             filesnames += a;
    //         }
    //     }
    // }
    // function scoreadp(score) {
    //     let value = score
    //     if (score === 100) {
    //         value = '0'
    //     } else if (score === -2) {
    //         value = 'NR'
    //     }
    //     return value;
    // }
    // const sanitizer = dompurify.sanitize;
    return (
        <div className="container-fluid">
            <div className="row mt-3 mx-4 text-light  rounded" style={{ backgroundColor: "#224dae" }}>
                <div className="col mx-auto text-center p-1">
                    <h3>MSA Lead   Score Summary Page</h3>

                </div>
            </div>
            <div className="row mt-2" style={{ marginLeft: "55px" }}>
                <div className="col-md-6 ml-4">
                    <div className="row ml-2">
                        <b>MSA Pillars</b> &nbsp; Vendor Score / Auditor Score
                    </div>
                    <div className="row ml-2">
                        <h6>Assessment to be done for Program Management, Purchasing and SCM, Technology.
                        </h6>
                    </div>
                    <div className="row" style={{ marginLeft: "70px" }}>
                        <div style={{ float: "left", width: "400px" }}>
                            <div className="hex-row">
                                <div className="hex1">
                                    <div className="top"> </div>
                                    <div className="middle text-light">Text6</div>
                                    <div className="bottom"> </div>
                                </div>
                                <div className="hex1">
                                    <div className="top"> </div>
                                    <div className="middle"><a href="/auditor_review?dept=6&msaid={{msapr}}" id="Customer_support" style={{ textAlign: "center", textDecoration: "none" }} >Customer Support</a></div>

                                    <div className="bottom"> </div>
                                </div>

                            </div>
                            <div className="hex-row even">
                                <div className="hex2">
                                    <div className="top"> </div>
                                    <div className="middle"><a href="/auditor_review?dept=4&msaid={{msapr}}" id="process_control_analysis" style={{ textAlign: "center", textDecoration: "none" }} >Process Control & Analysis</a></div>


                                    {/* <!-- <div className="middle"><a href="/auditor_review?dept=4&msaid={{msapr}}" id="process_control_analysis" style={{textAlign:"center",textDecoration:"none"}} >Process Control & Analysis</a></div> --> */}
                                    <div className="bottom"> </div>
                                </div>
                                <div className="hex2">
                                    <div className="top"> </div>
                                    <div className="middle text-light">Text5</div>
                                    <div className="bottom"> </div>
                                </div>
                            </div>
                            <div className="hex-row">
                                <div className="hex3">
                                    <div className="top"> </div>
                                    <div className="middle text-light">Text4</div>
                                    <div className="bottom"> </div>
                                </div>
                                <div className="hex3">
                                    <div className="top"> </div>
                                    <div className="middle"><a href="/auditor_review?dept=3&msaid={{msapr}}" id="purchasing_and_scm" style={{ textAlign: "center", textDecoration: "none" }} >Purchasing & SCM</a></div>


                                    {/* <!-- <div className="middle"><a href="/auditor_review?dept=3&msaid={{msapr}}" id="purchasing_and_scm" style={{textAlign:"center",textDecoration:"none"}} >Purchasing & SCM</a></div> --> */}
                                    <div className="bottom"> </div>
                                </div>

                            </div>
                            <div className="hex-row even">
                                <div className="hex4">
                                    <div className="top"> </div>
                                    <div className="middle"><a href="/auditor_review?dept=5&msaid={{msapr}}" id="program_management" style={{ textAlign: "center", textDecoration: "none" }} >Program Management</a></div>

                                    {/* <!-- <div className="middle"><a href="/auditor_review?dept=5&msaid={{msapr}}"  id="program_management" style={{textAlign:"center",textDecoration:"none"}} >Program Management</a></div> --> */}
                                    <div className="bottom"> </div>
                                </div>
                                <div className="hex4">
                                    <div className="top"> </div>
                                    <div className="middle text-light">Text3</div>
                                    <div className="bottom"> </div>
                                </div>
                            </div>
                            <div className="hex-row">
                                <div className="hex5">
                                    <div className="top"> </div>
                                    <div className="middle text-light">Text2</div>
                                    <div className="bottom"> </div>
                                </div>
                                <div className="hex5">
                                    <div className="top"> </div>
                                    <div className="middle"><a href="/auditor_review?dept=2&msaid={{msapr}}" id="technology" style={{ textAlign: "center", textDecoration: "none" }} >Technology</a></div>


                                    {/* <!-- <div className="middle"><a href="/auditor_review?dept=2&msaid={{msapr}}" id="technology"  style={{textAlign:"center",textDecoration:"none"}} >Technology</a></div> --> */}

                                    <div className="bottom"> </div>
                                </div>

                            </div>
                            <div className="hex-row even">
                                <div className="hex6">
                                    <div className="top"> </div>
                                    <div className="middle"><a href="/auditor_review?dept=1&msaid={{msapr}}" id="company_management" style={{ textAlign: "center", textDecoration: "none" }} >Company Management</a></div>


                                    {/* <!-- <div className="middle"><a href="/auditor_review?dept=1&msaid={{msapr}}"  id="company_management"  style="text-align:center; text-decoration:none" >Company Management</a></div> --> */}
                                    <div className="bottom"> </div>
                                </div>
                                <div className="hex6">
                                    <div className="top"> </div>
                                    <div className="middle text-light" id="scorem1">text</div>
                                    <div className="bottom"> </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <div className="col-md-4">
                    <div className="row mt-4">
                        <div className="col-md-9 mb-2 border border-primary bg-primary text-light p-2 rounded text-center" style={{ fontSize: " 21px" }}    >
                            Overall Score: 123
                        </div>
                    </div>
                    <div className="row mt-4">
                        <div className="col-md-9 border mb-4 border-info p-2 text-center text-danger rounded" style={{ backgroundColor: "lightgray", fontSize: " 21px" }}  >
                            Total number of Veto questions in Red: <b> 222</b>
                        </div>
                    </div>
                    <div className="row mt-4">
                        <button className="btn btn-md btn-success auditorsumit" id="auditorsumit" type="button"><i className="fa fa-check" aria-hidden="true"> </i> Submit</button>

                    </div>
                </div>

            </div>
            <div className="row m-4"> </div>
        </div>

    )
}
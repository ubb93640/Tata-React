import React from "react";
// import { Link } from "react-router-dom";
// import { Button } from 'react-bootstrap';
// import Moment from 'moment';
// import Modal from 'react-bootstrap/Modal';
import '../../App.css';
import './MSAReport.css';
// import dumyData from  './MSAReport.json';


export default function MSAReport() {
    // const {supplier} = {
    //     "supplier":[
    //         [
    //          {
    //           "id": 1,
    //           "proid": "MSAB0640023032022",
    //           "updated_at": "2022-03-24T05:07:51.651Z",
    //           "startdate": "2022-03-24",
    //           "enddate": "2022-03-25",
    //           "MSAClosure_date": "2022-04-05T07:14:38.121Z"
    //          },
    //          "2025-04-05",
    //          "57",
    //          {
    //           "null": 1
    //          }
    //         ],
    //         [
    //          {
    //           "id": 2,
    //           "proid": "MSAB0640022032022",
    //           "updated_at": "2022-03-24T06:02:46.865Z",
    //           "startdate": "2022-03-24",
    //           "enddate": "2022-03-25",
    //           "MSAClosure_date": "2022-04-05T07:14:38.121Z"
    //          },
    //          "2025-04-05",
    //          "57",
    //          {
    //           "null": 1
    //          }
    //         ],
    //         [
    //          {
    //           "id": 8,
    //           "proid": "MSAB0640028032022",
    //           "updated_at": "2022-03-28T04:46:55.890Z",
    //           "startdate": "2022-03-28",
    //           "enddate": "2022-03-29",
    //           "MSAClosure_date": "2022-04-05T07:14:38.121Z"
    //          },
    //          "2025-04-05",
    //          "91",
    //          {
    //           "null": 1
    //          }
    //         ],
    //         [
    //          {
    //           "id": 9,
    //           "proid": "MSAB0640029032022",
    //           "updated_at": "2022-03-31T12:15:06.738Z",
    //           "startdate": "2022-03-31",
    //           "enddate": "2022-04-04",
    //           "MSAClosure_date": "2022-04-05T07:14:38.121Z"
    //          },
    //          "2025-04-05",
    //          "20",
    //          {
    //           "null": 1
    //          }
    //         ],
    //         [
    //          {
    //           "id": 10,
    //           "proid": "MSAB0640030032022",
    //           "updated_at": "2022-03-31T12:19:11.953Z",
    //           "startdate": "2022-03-31",
    //           "enddate": "2022-04-04",
    //           "MSAClosure_date": "2022-04-05T07:14:38.121Z"
    //          },
    //          "2025-04-05",
    //          "93",
    //          {
    //           "null": 1
    //          }
    //         ],
    //         [
    //          {
    //           "id": 11,
    //           "proid": "MSAB0640031032022",
    //           "updated_at": "2022-03-31T12:26:37.446Z",
    //           "startdate": "2022-03-31",
    //           "enddate": "2022-04-04",
    //           "MSAClosure_date": "2022-04-05T07:14:38.121Z"
    //          },
    //          "2025-04-05",
    //          "90",
    //          {
    //           "null": 1
    //          }
    //         ],
    //         [
    //          {
    //           "id": 12,
    //           "proid": "MSAB0640001042022",
    //           "updated_at": "2022-04-01T03:33:26.018Z",
    //           "startdate": "2022-04-01",
    //           "enddate": "2022-04-04",
    //           "MSAClosure_date": "2022-04-05T07:14:38.121Z"
    //          },
    //          "2025-04-05",
    //          "92",
    //          {
    //           "null": 1
    //          }
    //         ],
    //         [
    //          {
    //           "id": 14,
    //           "proid": "MSAB0640005042022",
    //           "updated_at": "2022-04-05T07:51:49.517Z",
    //           "startdate": "2022-04-05",
    //           "enddate": "2022-04-08",
    //           "MSAClosure_date": "2022-04-05T07:51:49.517Z"
    //          },
    //          "2025-04-05",
    //          "87",
    //          {
    //           "null": 1
    //          }
    //         ],
    //         [
    //          {
    //           "id": 15,
    //           "proid": "MSAB0640003042022",
    //           "updated_at": "2022-04-07T10:25:29.232Z",
    //           "startdate": "2022-04-06",
    //           "enddate": "2022-04-09",
    //           "MSAClosure_date": "2022-04-07T10:25:29.232Z"
    //          },
    //          "2025-04-07",
    //          "86",
    //          {
    //           "null": 1
    //          }
    //         ],
    //         [
    //          {
    //           "id": 16,
    //           "proid": "MSAB0640006042022",
    //           "updated_at": "2022-04-07T10:49:53.446Z",
    //           "startdate": "2022-04-06",
    //           "enddate": "2022-04-09",
    //           "MSAClosure_date": "2022-04-07T10:49:53.446Z"
    //          },
    //          "2025-04-07",
    //          "93",
    //          {
    //           "null": 1
    //          }
    //         ],
    //         [
    //          {
    //           "id": 17,
    //           "proid": "MSAB0640002042022",
    //           "updated_at": "2022-04-14T10:15:32.344Z",
    //           "startdate": "2022-04-07",
    //           "enddate": "2022-04-09",
    //           "MSAClosure_date": "2022-04-14T10:15:32.344Z"
    //          },
    //          "2025-04-14",
    //          "52",
    //          {
    //           "null": 1
    //          }
    //         ],
    //         [
    //          {
    //           "id": 19,
    //           "proid": "MSAB0640007042022",
    //           "updated_at": "2022-04-08T05:35:19.824Z",
    //           "startdate": "2022-04-07",
    //           "enddate": "2022-04-09",
    //           "MSAClosure_date": "2022-04-08T05:35:19.824Z"
    //          },
    //          "2025-04-08",
    //          "86",
    //          {
    //           "null": 1
    //          }
    //         ],
    //         [
    //          {
    //           "id": 20,
    //           "proid": "MSAB0640008042022",
    //           "updated_at": "2022-04-12T10:13:14.820Z",
    //           "startdate": "2022-04-08",
    //           "enddate": "2022-04-13",
    //           "MSAClosure_date": "2022-04-12T10:13:14.820Z"
    //          },
    //          "2025-04-12",
    //          "72",
    //          {
    //           "null": 1
    //          }
    //         ],
    //         [
    //          {
    //           "id": 23,
    //           "proid": "MSAB0640010042022",
    //           "updated_at": "2022-04-13T06:18:07.420Z",
    //           "startdate": "2022-04-13",
    //           "enddate": "2022-04-15",
    //           "MSAClosure_date": "2022-04-13T06:18:07.420Z"
    //          },
    //          "2025-04-13",
    //          "52",
    //          {
    //           "null": 1
    //          }
    //         ],
    //         [
    //          {
    //           "id": 24,
    //           "proid": "MSAB0640013042022",
    //           "updated_at": "2022-04-13T12:53:54.230Z",
    //           "startdate": "2022-04-13",
    //           "enddate": "2022-04-16",
    //           "MSAClosure_date": "2022-04-13T12:53:54.230Z"
    //          },
    //          "2025-04-13",
    //          "52",
    //          {
    //           "null": 1
    //          }
    //         ],
    //         [
    //          {
    //           "id": 25,
    //           "proid": "MSAB0640018042022",
    //           "updated_at": "2022-04-18T06:53:57.768Z",
    //           "startdate": "2022-04-18",
    //           "enddate": "2022-04-19",
    //           "MSAClosure_date": "2022-04-18T06:53:57.768Z"
    //          },
    //          "2025-04-18",
    //          "57",
    //          {
    //           "null": 1
    //          }
    //         ],
    //         [
    //          {
    //           "id": 26,
    //           "proid": "MSAB0640016042022",
    //           "updated_at": "2022-04-19T05:41:30.751Z",
    //           "startdate": "2022-04-19",
    //           "enddate": "2022-04-21",
    //           "MSAClosure_date": "2022-04-19T05:41:30.751Z"
    //          },
    //          "2025-04-19",
    //          "55",
    //          {
    //           "null": 1
    //          }
    //         ],
    //         [
    //          {
    //           "id": 27,
    //           "proid": "MSAB0640019042022",
    //           "updated_at": "2022-04-21T06:10:21.174Z",
    //           "startdate": "2022-04-19",
    //           "enddate": "2022-04-22",
    //           "MSAClosure_date": "2022-04-21T06:10:21.174Z"
    //          },
    //          "2025-04-21",
    //          "55",
    //          {
    //           "null": 1
    //          }
    //         ],
    //         [
    //          {
    //           "id": 32,
    //           "proid": "MSAB0640027042022",
    //           "updated_at": "2022-04-27T04:13:58.255Z",
    //           "startdate": "2022-04-27",
    //           "enddate": "2022-04-30",
    //           "MSAClosure_date": "2022-04-27T04:13:58.255Z"
    //          },
    //          "2025-04-27",
    //          "57",
    //          {
    //           "CV Body": 1,
    //           "CV Chassis": 2,
    //           "CV Defence": 3
    //          }
    //         ],
    //         [
    //          {
    //           "id": 36,
    //           "proid": "MSAB0640001052022",
    //           "updated_at": "2022-05-01T13:55:08.992Z",
    //           "startdate": "2022-05-01",
    //           "enddate": "2022-05-04",
    //           "MSAClosure_date": "2022-05-01T13:55:08.992Z"
    //          },
    //          "2025-05-01",
    //          "40",
    //          {
    //           "CV Body": 1,
    //           "CV Chassis": 2
    //          }
    //         ],
    //         [
    //          {
    //           "id": 38,
    //           "proid": "MSAB0640006052022",
    //           "updated_at": "2022-05-09T07:33:29.226Z",
    //           "startdate": "2022-05-06",
    //           "enddate": "2022-05-09",
    //           "MSAClosure_date": "2022-05-09T07:33:29.226Z"
    //          },
    //          "2025-05-09",
    //          "71",
    //          {
    //           "CV Body": 1,
    //           "CV Chassis": 2
    //          }
    //         ],
    //         [
    //          {
    //           "id": 39,
    //           "proid": "MSAB0640009052022",
    //           "updated_at": "2022-05-17T12:12:35.416Z",
    //           "startdate": "2022-05-09",
    //           "enddate": "2022-05-12",
    //           "MSAClosure_date": "2022-05-17T12:12:35.416Z"
    //          },
    //          "2025-05-17",
    //          "74",
    //          {
    //           "CV Body": 1,
    //           "PV Casting, Forging and Machinery": 2
    //          }
    //         ]
    //        ]
    // }
    return (
        <div className="container-fluid mt-2">
            <div className="row border-bottom border-secondary">
                <div className="col-md-12">
                    <h3 className="text-center text-primary">MSA Admin Portal</h3>
                </div>
            </div>
            <div className="row pb-1 border-bottom border-secondary">
                <div className="col-md-2"> </div>
                <div className="col-md-2">
                    <a href="{% url 'msaadddata'%}" className="submenunav" style={{ color: "#030352" }}>Add/ Upload Data</a>
                </div>
                <div className="col-md-2">
                    <a href="{% url 'msaedit' %}" className="submenunav" style={{ color: "#030352" }}>Edit/ Delete MSA Data</a>
                </div>
                <div className="col-md-2">
                    <a href="{% url 'msafinancetemplate' %}" className="submenunav" style={{ color: "#030352" }}>Finance Template Upload</a>
                </div>
                <div className="col-md-2">
                    <a href="{% url 'msatemplatedownloadredirect' %}" className="submenunav" style={{ color: "#030352" }}>MSA Template Download </a>
                </div>
            </div>
            <div className="row mt-2">
                {/* <!-- <a href="../media/msa_template_Deleted_100_210902163600.xls" style="margin-left: 17px" download>Download Template </a> --> */}
                <div className="col-md-2 ml-auto">
                    <button className="btn btn-outline-danger delbtn1" type="button"> <i className="fa fa-trash fa-1x" aria-hidden="true"> </i> Delete All Questions</button>
                </div>
            </div>
            <div className="row mb-3" style={{ height: " 450px", overflow: "auto" }} >
                <div className="col-md-12">
                    <table className="table table-hover table-bordered " id="mytable">
                        {/* style="font-size: 18px;" */}
                        <thead className="actionPlan" style={{ fontSize: "18px" }} >
                            <tr>
                                <th scope="col" className="stickyheader text-center"><button className="btn btn-outline-light  allqdel" type="button">Mark All for delete</button></th>
                                {/* style="text-align: center;vertical-align: middle;" */}
                                <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }}>S No. </th>

                                <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }}>Question</th>

                                <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }}>Veto</th>

                                <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }}>Virtual Audited</th>
                                {/* <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }}>Auditor Name</th> */}

                                <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }}>Auditor Department</th>

                                <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }}>MSA Pillar</th>

                                <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }} >Sub functional Area</th>
                                <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }} >Guidelines</th>

                                <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }} >Evidence</th>

                                <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }} >Edit</th>
                                <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }} >Delete</th>

                            </tr>
                        </thead>

                        <tbody>
                            <tr className="tbl{{each.id}}">
                                <td> <input type="checkbox" className="input" /></td>
                                <td> 1.01</td>
                                <td> How well defined is the Organizations business strategy </td>
                                <td> <input type="checkbox" className="input" /></td>
                                <td> <input type="checkbox" className="input" /></td>

                                <td><select>
                                    <option value="" key="default">Parches</option>
                                </select></td>
                                <td>
                                    <select>
                                        <option value="" key="default">Company Mangement</option>
                                    </select>
                                </td>
                                <td>A. Company Management and Governance</td>
                                <td><p>• How does organization develop and deploy the action plans?<br />• Are the resources appropriately defined and allocated to support for attaining strategy?<br />• KPI and KRA deployment <br />• Management review systems<br />• Budget and capex review meeting<br />• Department level review meeting<br />• Action plan along with implementation targets</p></td>
                                <td><p>•Business Score Card (BSC) data<br />• BSC cascading<br />• Organization structure (special focus on Quality Organization)<br />• KPI and KRA data<br />• Quality Review Meetings (QRM)<br />• Management Review Meetings (MRM)Performance monitoring systems<br />• Visual management systems<br />• Operation and business matrices indicator<br />• Action plans for achievements </p></td>
                                <td><i className="fa fa-floppy-o fa-2x text-primary btns edit1031" id="edit1031" aria-hidden="true"> </i></td>
                                <td><i className="fa fa-thumb-tack" id="edit1031" aria-hidden="true"> </i> </td>

                            </tr>
                            <tr className="tbl{{each.id}}">
                                <td> <input type="checkbox" className="input" /></td>
                                <td> 1.01</td>
                                <td> How well defined is the Organizations business strategy </td>
                                <td> <input type="checkbox" className="input" /></td>
                                <td> <input type="checkbox" className="input" /></td>

                                <td><select>
                                    <option value="" key="default">Parches</option>
                                </select></td>
                                <td>
                                    <select>
                                        <option value="" key="default">Company Mangement</option>
                                    </select>
                                </td>
                                <td>A. Company Management and Governance</td>
                                <td><p>• How does organization develop and deploy the action plans?<br />• Are the resources appropriately defined and allocated to support for attaining strategy?<br />• KPI and KRA deployment <br />• Management review systems<br />• Budget and capex review meeting<br />• Department level review meeting<br />• Action plan along with implementation targets</p></td>
                                <td><p>•Business Score Card (BSC) data<br />• BSC cascading<br />• Organization structure (special focus on Quality Organization)<br />• KPI and KRA data<br />• Quality Review Meetings (QRM)<br />• Management Review Meetings (MRM)Performance monitoring systems<br />• Visual management systems<br />• Operation and business matrices indicator<br />• Action plans for achievements </p></td>
                                <td><i className="fa fa-floppy-o fa-2x text-primary btns edit1031" id="edit1031" aria-hidden="true"> </i></td>
                                <td><i className="fa fa-floppy-o fa-2x text-primary btns edit1031" id="edit1031" aria-hidden="true"> </i> </td>

                            </tr>
                            <tr className="tbl{{each.id}}">
                                <td> <input type="checkbox" className="input" /></td>
                                <td> 1.01</td>
                                <td> How well defined is the Organizations business strategy </td>
                                <td> <input type="checkbox" className="input" /></td>
                                <td> <input type="checkbox" className="input" /></td>

                                <td><select>
                                    <option value="" key="default">Parches</option>
                                </select></td>
                                <td>
                                    <select>
                                        <option value="" key="default">Company Mangement</option>
                                    </select>
                                </td>
                                <td>A. Company Management and Governance</td>
                                <td><p>• How does organization develop and deploy the action plans?<br />• Are the resources appropriately defined and allocated to support for attaining strategy?<br />• KPI and KRA deployment <br />• Management review systems<br />• Budget and capex review meeting<br />• Department level review meeting<br />• Action plan along with implementation targets</p></td>
                                <td><p>•Business Score Card (BSC) data<br />• BSC cascading<br />• Organization structure (special focus on Quality Organization)<br />• KPI and KRA data<br />• Quality Review Meetings (QRM)<br />• Management Review Meetings (MRM)Performance monitoring systems<br />• Visual management systems<br />• Operation and business matrices indicator<br />• Action plans for achievements </p></td>
                                <td><i className="fa fa-floppy-o fa-2x text-primary btns edit1031" id="edit1031" aria-hidden="true"> </i></td>
                                <td><i className="fa fa-floppy-o fa-2x text-primary btns edit1031" id="edit1031" aria-hidden="true"> </i> </td>

                            </tr>
                            <tr className="tbl{{each.id}}">
                                <td> <input type="checkbox" className="input" /></td>
                                <td> 1.01</td>
                                <td> How well defined is the Organizations business strategy </td>
                                <td> <input type="checkbox" className="input" /></td>
                                <td> <input type="checkbox" className="input" /></td>

                                <td><select>
                                    <option value="" key="default">Parches</option>
                                </select></td>
                                <td>
                                    <select>
                                        <option value="" key="default">Company Mangement</option>
                                    </select>
                                </td>
                                <td>A. Company Management and Governance</td>
                                <td><p>• How does organization develop and deploy the action plans?<br />• Are the resources appropriately defined and allocated to support for attaining strategy?<br />• KPI and KRA deployment <br />• Management review systems<br />• Budget and capex review meeting<br />• Department level review meeting<br />• Action plan along with implementation targets</p></td>
                                <td><p>•Business Score Card (BSC) data<br />• BSC cascading<br />• Organization structure (special focus on Quality Organization)<br />• KPI and KRA data<br />• Quality Review Meetings (QRM)<br />• Management Review Meetings (MRM)Performance monitoring systems<br />• Visual management systems<br />• Operation and business matrices indicator<br />• Action plans for achievements </p></td>
                                <td><i className="fa fa-floppy-o fa-2x text-primary btns edit1031" id="edit1031" aria-hidden="true"> </i></td>
                                <td><i className="fa fa-thumb-tack" id="edit1031" aria-hidden="true"> </i> </td>

                            </tr>
                            <tr className="tbl{{each.id}}">
                                <td> <input type="checkbox" className="input" /></td>
                                <td> 1.01</td>
                                <td> How well defined is the Organizations business strategy </td>
                                <td> <input type="checkbox" className="input" /></td>
                                <td> <input type="checkbox" className="input" /></td>

                                <td><select>
                                    <option value="" key="default">Parches</option>
                                </select></td>
                                <td>
                                    <select>
                                        <option value="" key="default">Company Mangement</option>
                                    </select>
                                </td>
                                <td>A. Company Management and Governance</td>
                                <td><p>• How does organization develop and deploy the action plans?<br />• Are the resources appropriately defined and allocated to support for attaining strategy?<br />• KPI and KRA deployment <br />• Management review systems<br />• Budget and capex review meeting<br />• Department level review meeting<br />• Action plan along with implementation targets</p></td>
                                <td><p>•Business Score Card (BSC) data<br />• BSC cascading<br />• Organization structure (special focus on Quality Organization)<br />• KPI and KRA data<br />• Quality Review Meetings (QRM)<br />• Management Review Meetings (MRM)Performance monitoring systems<br />• Visual management systems<br />• Operation and business matrices indicator<br />• Action plans for achievements </p></td>
                                <td><i className="fa fa-floppy-o fa-2x text-primary btns edit1031" id="edit1031" aria-hidden="true"> </i></td>
                                <td><i className="fa fa-floppy-o fa-2x text-primary btns edit1031" id="edit1031" aria-hidden="true"> </i> </td>

                            </tr>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
}
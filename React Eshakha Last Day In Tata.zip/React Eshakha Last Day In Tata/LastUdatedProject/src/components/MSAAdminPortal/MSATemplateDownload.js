import React from "react";
// import { Link } from "react-router-dom";
// import { Button } from 'react-bootstrap';
// import Moment from 'moment';
// import Modal from 'react-bootstrap/Modal';
import '../../App.css';
import './MSAReport.css';
// import dumyData from  './MSAReport.json';


export default function MSATemplateDownload() {

    return (
        <div className="container-fluid mt-2">
            <div className="row border-bottom border-secondary">
                <div className="col-md-12">
                    <h3 className="text-center text-primary">MSA Admin Portal</h3>
                </div>
            </div>
            <div className="row pb-1 border-bottom border-secondary">
                <div className="col-md-2"> </div>
                <div className="col-md-2">
                    <a href="{% url 'msaadddata'%}" className="submenunav" style={{ color: "#030352" }}>Add/ Upload Data</a>
                </div>
                <div className="col-md-2">
                    <a href="{% url 'msaedit' %}" className="submenunav" style={{ color: "#030352" }}>Edit/ Delete MSA Data</a>
                </div>
                <div className="col-md-2">
                    <a href="{% url 'msafinancetemplate' %}" className="submenunav" style={{ color: "#030352" }}>Finance Template Upload</a>
                </div>
                <div className="col-md-2">
                    <a href="{% url 'msatemplatedownloadredirect' %}" className="submenunav" style={{ color: "#030352" }}>MSA Template Download </a>
                </div>
            </div>
            <div className="row mt-4" style={{ height: "450px", overflow: "scroll" }}>
                <div className="col-md-12 mr-4">
                    <div id="table" className="table table-hover table-bordered  border-dark">
                        <table className="table table-hover">
                            <thead className="thead-dark" style={{ fontSize: "18px" }}>
                                <tr>
                                    {/* <!-- <th className="stickyheader text-center"><button className="btn btn-outline-light  allqdel">Mark All for delete</button></th> -->
                    <!-- <th className="stickyheader text-center">Sr No</th> --> */}
                                    <th className="stickyheader text-center" name="ques" id="ques">Template Name</th>
                                    <th className="stickyheader text-center">Updated On</th>
                                    <th className="stickyheader text-center">Download</th>
                                </tr>

                                <tr>
                                    <td className="stickyheader text-center">msa_template_Edited_1031_220209175537.xls</td>
                                    <td className="stickyheader text-center">09-02-2022 05:55</td>
                                    <td>
                                        <a href="downloadfiles/msa_template_Edited_1031_220209175537.xls"> Download </a>

                                    </td></tr><tr>
                                    <td className="stickyheader text-center">msa_template_Edited_869_220207095539.xls</td>
                                    <td className="stickyheader text-center">07-02-2022 09:55</td>
                                    <td>
                                        <a href="downloadfiles/msa_template_Edited_869_220207095539.xls"> Download </a>

                                    </td></tr><tr>
                                    <td className="stickyheader text-center">msa_template_Edited_868_211119125711.xls</td>
                                    <td className="stickyheader text-center">19-11-2021 12:57</td>
                                    <td>
                                        <a href="downloadfiles/msa_template_Edited_868_211119125711.xls"> Download </a>

                                    </td></tr><tr>
                                    <td className="stickyheader text-center">msa_template_Edited_867_211119124327.xls</td>
                                    <td className="stickyheader text-center">19-11-2021 12:43</td>
                                    <td>
                                        <a href="downloadfiles/msa_template_Edited_867_211119124327.xls"> Download </a>

                                    </td></tr><tr>
                                    <td className="stickyheader text-center">msa_template_Edited_866_211027112809.xls</td>
                                    <td className="stickyheader text-center">27-10-2021 11:28</td>
                                    <td>
                                        <a href="downloadfiles/msa_template_Edited_866_211027112809.xls"> Download </a>

                                    </td></tr><tr>
                                    <td className="stickyheader text-center">msa_template_Edited_865_211027112719.xls</td>
                                    <td className="stickyheader text-center">27-10-2021 11:27</td>
                                    <td>
                                        <a href="downloadfiles/msa_template_Edited_865_211027112719.xls"> Download </a>

                                    </td>
                                    {/* <!-- <td href="../media/msa_template_Edited_1031_220209175537.xls" download> Download </td> --> */}
                                </tr>
                            </thead>

                        </table>
                    </div>
                </div>
            </div>
        </div>
    );
}
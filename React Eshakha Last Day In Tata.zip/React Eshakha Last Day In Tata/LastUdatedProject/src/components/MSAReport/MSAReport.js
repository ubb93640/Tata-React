import React from "react";
import { Link } from "react-router-dom";
// import { Button } from 'react-bootstrap';
import Moment from 'moment';
// import Modal from 'react-bootstrap/Modal';
import '../../App.css';
import './MSAReport.css';
// import dumyData from  './MSAReport.json';


export default function MSAReport() {

    return (
        <div className="container-fluid">
            <div className="row rounded">
                <div className="col-md-12">
                    <h3 className="card-header text-center text-light my-4 py-2" style={{ background: "#1976d2" }}
                    >Projects</h3>
                </div>
            </div>
            <div className="row">
                <div className="col-md-2 ml-auto">
                    <input type="text" id="search" placeholder="Search..." className="form-control mb-1 border-primary" />
                </div>
            </div>

            {/* <div className="col-md-12"> */}
            <div className="row mb-3" style={{ height: "460px", overflow: "scroll" }}>
                <div id="table" className="col-md-12">
                    <table className="table table-hover table-bordered" id="mytable">
                        <thead className="" style={{ fontSize: "18px", borderColor: "#000000" }}>
                            <tr>
                                <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }}>Project ID<br /> <small>(Click for report)</small></th>
                                <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }}>Assignment Date</th>
                                <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }}>Assessment Start Date</th>
                                <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }}>Assessment End Date</th>
                                <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }}>MSA Closure date</th>
                                <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }}>MSA Validity End date</th>
                                <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }}>MSA Score</th>
                                <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }}>Commodity</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                supplier.map(item => {
                                    console.log("sup : ", supplier)
                                    const updatedAt = Moment(item[0].updated_at).format("MMMM D, YYYY")
                                    const startDate = Moment(item[0].startdate).format("MMMM D, YYYY")
                                    const endDate = Moment(item[0].enddate).format("MMMM D, YYYY")
                                    const msaValidity = Moment(item[1]).format("MMMM D, YYYY")
                                    const MSAClosureDate = Moment(item[0].MSAClosure_date).format("MMMM D, YYYY")
                                    return (
                                        <tr key={item[0].id} className={`tbl${item[0].id}`}>
                                            {/* <td><a href="{url 'scorecard' id}">{item.proId}</a></td> */}
                                            <td>
                                                {/* <Rourter> */}
                                                <Link to={`/scorecard/${item[0].id}`}>{item[0].proid}</ Link>
                                                {/* <Route path="/scorecard/:id" component={Scorecard} /> */}
                                                {/* </Rourter> */}
                                            </td>
                                            <td>{updatedAt}</td>
                                            <td>{startDate}</td>
                                            <td>{endDate}</td>
                                            <td>{MSAClosureDate}</td>
                                            <td>{msaValidity}</td>
                                            <td>{item[2]}</td>
                                            <td>
                                                {Object.keys(item[3]).map((key) => (<ul>
                                                    {key === 'null' ? <li>None</li> : <li>{key}</li>}
                                                </ul>
                                                )
                                                )}
                                            </td>
                                        </tr>);
                                })
                            }
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
}
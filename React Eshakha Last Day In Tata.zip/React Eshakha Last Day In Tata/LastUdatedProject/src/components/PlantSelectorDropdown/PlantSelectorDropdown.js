/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';
import clsx from 'clsx';
import { connect } from 'react-redux';
import plantStoreActions from '../../redux/features/plantStore/actions';
import styles from './PlantSelectorDropdown.module.css';
import { Select } from '../../atomicComponents';

const PlantSelectorDropdown = ({
  isDarkStyle,
  plant,
  plantOptions,
  setPlant,
}) => {
  const handlePlantChange = valueObject => {
    setPlant(valueObject);
  };

  return (
    <Select
      value={plant}
      selectName="plants"
      borderStyle="solid 1px #608FC9"
      fontColor="#0275A7"
      selectClassName={clsx(
        styles.dropdown,
        styles.select,
        isDarkStyle && styles.dropdownDark,
      )}
      onChange={handlePlantChange}
      options={plantOptions}
    />
  );
};

PlantSelectorDropdown.propTypes = {
  isDarkStyle: PropTypes.bool,
  plant: PropTypes.shape({
    value: PropTypes.any.isRequired,
    label: PropTypes.string.isRequired,
  }),
  plantOptions: PropTypes.arrayOf(
    PropTypes.shape({
      value: PropTypes.any.isRequired,
      label: PropTypes.string.isRequired,
    }),
  ),
  setPlant: PropTypes.func.isRequired,
};

export default connect(
  ({ plantStore }) => ({
    plant: plantStore.plant,
    plantOptions: plantStore.options,
  }),
  { setPlant: plantStoreActions.setPlant },
)(PlantSelectorDropdown);

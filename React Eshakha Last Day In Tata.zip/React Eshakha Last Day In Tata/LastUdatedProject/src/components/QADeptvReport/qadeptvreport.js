import React from "react";
// import DOMPurify from "dompurify";
// import { Markup } from 'interweave';
// import '../../App.css';
import './qadeptvreport.css';
// import dumyData from  './qadeptvreport.json';

export default function QADeptvReport() {
    const [deptData, deptInfo] = [{
        "auditorobservation":"firsttest",
        "auditorscore":10,
        "leadscore":10,
        "leadobservation":"firsttest",
        "supplierobservation":"Are the TML requirements fulfilled in terms of product",
        "supplierscore":10,
        "auditdept":"Advanced Quality",
        "question":"Are the TML requirements fulfilled in terms of product, process and Quality Management System?",
        "q_title":"6.1 - ",
        "guidelines":[" Organization has  fulfilled TML  specific requirements( mentioned in Supplier Quality manual/ SQ SOR)?\n"," Organization has QMS certification, valid and certified with latest revision.\n"," Regular Process audit for CTQ parameters\n"," Organization  include spare part requirement in production planning over regular production requirement from customer.\n"," Organization fulfills packaging/logistic requirements as per the SCM SOR?\n"," Does the product requalification's are carried out as per the customer's requirement?\n"," Does the product conform to legal/ statutory regulations?"],
        "veto":true,
        "VirAssessment_flag":true,
        "evidences":[""," PPAP sign-off /TRSO sign-off\n"," Valid QMS certificates\n"," Process audit and statistical controls on CTQ- trend analysis\n"," Part-shipments to provide spares/first fill before start of full production\n"," Storage, scheduling, providing parts, shipping, compliance with customer specific packaging and identification regulation\n"," Quality agreements for PPM and delivery\n"," Product and shipping audit, dock audits\n"," Engineering test , reliability, durability & functional tests\n"," Compliance to packing standards\n"," Qualifications  & Requalification checks"],
        "filenames":[[""," PPAP sign-off /TRSO sign-off\n"],[""," Valid QMS certificates\n"],[""," Process audit and statistical controls on CTQ- trend analysis\n"],[""," Part-shipments to provide spares/first fill before start of full production\n"],[""," Storage, scheduling, providing parts, shipping, compliance with customer specific packaging and identification regulation\n"],[""," Quality agreements for PPM and delivery\n"],[""," Product and shipping audit, dock audits\n"],[""," Engineering test , reliability, durability & functional tests\n"],[""," Compliance to packing standards\n"],[""," Qualifications  & Requalification checks"]],
        "ansid":1
    },
    {
        "deptname": "Customer Support", 
        "deptid": "6", 
        "msapr": "1"}
    ]
    const {auditorobservation, auditorscore, leadscore, leadobservation, supplierobservation, supplierscore,auditdept, question, qTitle, guidelines, veto, VirAssessmentFlag, evidences, filenames} = deptData;
    const {deptname, deptid, msapr} = deptInfo
    console.log(deptid, msapr)
    console.log(leadscore, leadobservation, supplierobservation, evidences)

    let guidelinestext = '';
    if (guidelines) {
        let ab
        for(let i=1; i< guidelines.length; i+= 1) {
            ab = `-> &nbsp;&nbsp;  ${guidelines[i]}  <br>`;
            guidelinestext+=ab;
        }
    }
    let financetem = ''
    let financefileuploaded = ''
    if ("auditorscore" in deptData) {
        financetem = deptData.financetem
        financefileuploaded = deptData.financefileuploaded
        console.log(" data is available", financetem)
    }
    else{
        console.log(" data is not available")
    }
    let filesnames = '';
    if (filenames) {
        if (filenames.length === 0) {
          filesnames = "No Attachments"
        } else {
            let a
            for(let i =0; i < filenames.length; i+=1) {
            a = `<tr><td> ${i+1} </td><td>   ${filenames[i][1]} </td><td> <a href="/downloadfiles/${filenames[i][0]}"> ${filenames[i][0]} </a></td></tr>`;
            filesnames += a;
            }
        }
    }
    function scoreadp(score) {
        let value = score
        if (score === 100) {
            value = '0'
        } else if (score === -2) {
            value = 'NR'
        }            
        return value;
    }
    // const sanitizer = dompurify.sanitize;
    return(
    <div className="container-fluid">
    <div className="row">
        <div className="col-md-12 text-center border border-warning rounded  p-2" style={{backgroundColor: "#f2c830"}}>
            <h3><b>{deptname}</b></h3>
        </div>
    </div>
    <div className="row">
      <div className="col-md-12 border border-warning rounded  p-2">
          <b className="subfunctionalarea ml-4">{qTitle}</b>
      </div>
  </div>
    <div className="row">
      <div className="col-md-4 text-danger m-2 text-center p-1">
          { VirAssessmentFlag ? 
          <h4 className="VirAssessment_flag">This question is virtual Audited question</h4>
          : <h4 className="VirAssessment_flag d-none">This question is virtual Audited question</h4>}</div>
        {/* <!-- <div className="col-md-3 text-danger ml-auto mb-1"><h4 className="vetq">This is Veto Question</h4></div> --> */}
        <div className="col-md-3 text-danger m-2 text-center p-1 auddepttext" style={{fontSize: "23px"}}>{auditdept}</div>  
      <div className="col-md-4 text-danger m-2 text-center p-1">
          {veto ?
              <h4 className="vetq">This question is Veto question</h4>
              :
              <h4 className="vetq d-none">This question is Veto question</h4>
          }</div>
    </div>
    <div className="row">
        <div className="col-md-7">
            <div className="row">
                <div className="col-md-12 text-center">
                    <h3 className="text-light py-2 bg-primary rounded m-2 text-center p-1">Assessment Question:</h3>
                    <br />
                    <div className="rounded mr-2 py-5 mb-4 ques ml-2 quetiontext">{question}
                    </div>
                </div>
                <div className="col-md-12 mt-4">
                    <h4 className="text-light py-2 bg-success supplierobs rounded m-2 text-center p-1">Supplier Comments (Self Assessment)</h4>
                    <span className="self_observation border border-success card p-4 m-1">Supplier {supplierobservation}</span>
                </div>
                {financetem in deptData ?
                <div className="col-md-12 mt-4 fintemplate1 ">
                  <h4 className="text-light py-2 bg-primary rounded m-2 text-center p-1">Finance Template</h4>
                    <div className="col-md-12">
                    <table className="table table-bordered">
                        <thead className="thead-dark header">
                        <tr>
                            <th scope="col">Input Template</th>
                            <th scope="col">Uploaded Template</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                        <td className="temfilename" /> <a href={`/fintemdwn/${financetem}`}>{financetem}</a>
                        <td className="uploadfinfile" /><a href={`/fintemdwn/${financefileuploaded}`}>{financefileuploaded}</a>
                        </tr>
                        </tbody>
                    </table>
                    </div>
                </div> :
                <div className="col-md-12 mt-4 fintemplate1 d-none">
                <h4 className="text-light py-2 bg-primary rounded m-2 text-center p-1">Finance Template</h4>
                  <div className="col-md-12">
                  <table className="table table-bordered">
                      <thead className="thead-dark header">
                      <tr>
                          <th scope="col">Input Template</th>
                          <th scope="col">Uploaded Template</th>
                      </tr>
                      </thead>
                      <tbody>
                      <tr>
                      <td className="temfilename" />
                      <td className="uploadfinfile" />
                      </tr>
                      </tbody>
                  </table>
                  </div>
              </div>
            }
            </div>
        </div>

        <div className="col-md-5">
            <h3 className="text-light auditorscore py-2 bg-info rounded m-2 text-center p-1">Auditor Observation & Remarks</h3>    
            <br />
            <span className="auditorobservation border border-info card p-4 m-1">{auditorobservation}</span>
            <br />
            <div className="m-5"/>
            {/* <!-- <h3 className="text-light msaleadobs bg-primary rounded m-2 text-center p-1">MSA Lead Observation & Remarks</h3> --> */}
            
            {/* <!-- <span className="leadobservation border border-primary card p-4 mx-1">Hello</span> --> */}
            <br />
            <h4 className="text-light py-2 bg-primary rounded m-2 text-center p-1">Attachments</h4>
            <div style={{height: "225px", overflow: "scroll"}}>
            <table className="table table-hover table-bordered mx-2 rounded">
              <thead className="thead-dark header">
                <tr>
                  <th scope="col" className="stickyheader">#</th>
                  <th scope="col" className="stickyheader">Evidence</th>
                  <th scope="col" className="stickyheader">Attachment</th>
                </tr>
              </thead>
              <tbody className="fileslist" dangerouslySetInnerHTML={{__html: filesnames}} >
                    {/* <Markup content= {filesnames}/> */}
              </tbody>
            </table>
            </div>
        </div>

    </div>

    <div className="row">
        <div className="col-md-3 text-center bg-info rounded text-light m-5 p-4 score"><i className="fa fa-thumb-tack" aria-hidden="true"/> Supplier Score: <span id="supplierscore">{scoreadp(supplierscore) }</span></div>
        <div className="col-md-3 text-center bg-primary rounded text-light  m-5 p-4 score"><i className="fa fa-thumb-tack" aria-hidden="true" /> Auditor Score: <span id="auditorscore">{scoreadp(auditorscore)}</span> </div>
        {/* <!-- <div className="col-md-3 text-center bg-success rounded m-5 p-4 text-light score"><i className="fa fa-thumb-tack" aria-hidden="true"></i> Lead Score: <span id="leadscore">{scoreadp(leadscore)}</span> </div> --> */}
    </div>
    <div className="row mt-4 mb-4">
        <div className="col-md-2 mt-5 ml-4">
            <button type="button" className="btn btn-primary prev d-none"><i className="fa fa-arrow-left" aria-hidden="true" />Prev</button>
        </div>
        <div className="col-md-7 mb-4 ">
            <h4 className="text-center bg-info p-1  text-light rounded">What to Look For..</h4>
            <div className="p-1 ques guidelines rounded" style={{height: "210px", overflowY: "scroll"}} dangerouslySetInnerHTML={{__html: guidelinestext}} />
            
            {/* <Markup content={guidelinestext}/></div> */}
        </div>

        <div className="col-md-2 mt-5">
            <button type='button' className="btn btn-success float-right nexbtn nextbtn">Next <i className="fa fa-arrow-right" aria-hidden="true" /></button>
            <button type='button' className="btn btn-primary float-right savebtn d-none">Continue <i className="fa fa-arrow-right" aria-hidden="true" /></button>
        </div>
    </div>
    <div className="row m-4" />
</div>

)
}
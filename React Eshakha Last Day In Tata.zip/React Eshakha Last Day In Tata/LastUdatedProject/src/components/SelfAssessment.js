import React, { useState } from "react";
import { Button } from 'react-bootstrap';
// import { encode } from "base-64";
import Modal from 'react-bootstrap/Modal';
import '../App.css';

export default function SelfAssessment() {
    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    // const [lastName, setName1] = useState();
    // const [dataArray1, setDataArray1] = useState([]);

    // const [dataArray, setDataArray] = useState([]);
    // function getUdate() {
    //     const username = 'A71720K01';
    //     const password = 'pass@123';
    //     const headerss = new Headers();
    //     headerss.append("authorization", "Basic QTcxNzIwSzAxOnBhc3NAMTIz", encode(username, ":", password));
    //     headerss.append('Content-Type', 'application/json');
    //     fetch('https://vendor360qa.tatamotors.com/api/contactprofilevendorviewdata', {
    //         method: 'POST',
    //         headers: headerss,
    //         body: JSON.stringify({ vendordata: ["A71720"] })
    //     }).then((response) => response.json())
    //         .then((responseJson) => {
    //             const responseArray = [];
    //             const prfilePost = [{ designation: "Chairman", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "Managing Director", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "CEO", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "CFO", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "Plant Head", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "Quality Head", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "Manufacturing Head", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "Key Account Manager", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "Finance Manager", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "Dispatch Manager", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }];
    //             const loda = [];
    //             const apidata = Object.values(responseJson);
    //             for (let i = 0; i < apidata.length; i += 1) {
    //                 for (let j = 0; j < apidata[i].length; j += 1) {
    //                     const data = {
    //                         // post: prfilePost[j],
    //                         user: apidata[i][j][0],
    //                         vandorName: apidata[i][j][1],
    //                         designation: apidata[i][j][2],
    //                         firstName: apidata[i][j][3],
    //                         lastName: apidata[i][j][4],
    //                         emailID: apidata[i][j][5],
    //                         phoneNumber: apidata[i][j][6],
    //                         location: apidata[i][j][7],
    //                         lastUpdated: apidata[i][j][8]
    //                     }
    //                     responseArray.push(data)
    //                     loda.push(prfilePost)
    //                 }

    //                 setDataArray(responseArray)
    //                 setDataArray1(prfilePost)
    //             }

    //             // console.log("sndhgsddgh", responseArray);



    //         })
    //         .catch((error) => {
    //             console.error(error);
    //         });
    // }
    // useEffect(() => {
    //     getUdate(dataArray1);
    // }, []);
    // const vaue = "";
    // console.log(vaue);
    // let edited = true;
    // if (vaue === "") {
    //     edited = true;
    // } else {
    //     edited = false;
    // }
    // let counter = 0
    return (


        <div className="container-fluid">
            <Modal show={show}
                onHide={handleClose}
                backdrop="static"
                keyboard={false}
            >
                <Modal.Body style={{ textAlign: "center" }}>
                    <div className="swal-icon swal-icon--warning">
                        <span className="swal-icon--warning__body">
                            <span className="swal-icon--warning__dot"> </span>
                        </span>
                    </div>
                    <h3>warning</h3>
                    <p>Assesment End Date is over. Please contact the MSA Lead</p>
                </Modal.Body>
                <Modal.Footer>
                    <Button className="swal-button swal-button--confirm" onClick={handleClose}>Ok</Button>
                </Modal.Footer>
            </Modal>
            <div className="row rounded">
                <div className="col-md-12">
                    {/* style="font-family: uni_neueregular;background-color: #1976d2;" */}
                    <h3 className="card-header text-center text-light my-4 py-2" style={{ background: "#1976d2" }}
                    >Projects for Self Assessment</h3>
                </div>
            </div>

            <div className="row">
                <div className="col-md-2 ml-auto">
                    <input type="text" id="search" placeholder="Search..." className="form-control mb-1 border-primary" />
                </div>
            </div>
            {/* style="height: 450px;overflow: scroll;" */}
            <div className="row mb-3" style={{ height: " 450px", overflow: "scroll" }} >
                <div className="col-md-12">
                    <table className="table table-hover table-bordered " id="mytable">
                        {/* style="font-size: 18px;" */}
                        <thead className="self" style={{ fontSize: "18px" }} >
                            <tr>

                                {/* style="text-align: center;vertical-align: middle;" */}
                                <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }}>Project ID<br /> <small>(Click to Start)</small></th>
                                <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }} >Assignment Date</th>
                                <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }} >Assessment Start Date</th>
                                <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }}>Assessment End Date</th>
                                <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }}>Status</th>
                            </tr>
                        </thead>

                        <tbody>
                            <tr className="tbl{{each.id}}">
                                {/* {% if each.enddate|date:'Y-m-d' < currentDate and each.prstatus == "Awaiting Self Assessment from Supplier"%} */}
                                {/* onclick="showAlert()" */}
                                {/* <td><a href="#"> gtext</a></td> */}
                                {/* <!-- <td>{{each.proid}}</td> --> */}
                                {/* {% else %} */}
                                <td><a href="{% url 'msareviewpr' each.id %}">MSAA7172026112021</a></td>
                                {/* {% endif %} */}
                                {/* {{ each.updated_at | date }} */}
                                <td>Nov. 26, 2021</td>
                                {/* {{ each.startdate }} */}
                                <td>Nov. 26, 2021</td>
                                {/* {{ each.enddate }} */}
                                {/* {{each.enddate}} */}
                                <td><input hidden id="userdate" value="texy" />Dec. 15, 2021</td>
                                {/* {{ each.prstatus }} */}
                                <td>Completed</td>
                            </tr>
                            <tr className="tbl{{each.id}}">
                                {/* {% if each.enddate|date:'Y-m-d' < currentDate and each.prstatus == "Awaiting Self Assessment from Supplier"%} */}
                                {/* onclick="showAlert()" */}
                                {/* <td><a href="#"> gtext</a></td> */}
                                {/* <!-- <td>{{each.proid}}</td> --> */}
                                {/* {% else %} */}
                                <td><a href="{% url 'msareviewpr' each.id %}">MSAA7172026112021</a></td>
                                {/* {% endif %} */}
                                {/* {{ each.updated_at | date }} */}
                                <td>Nov. 26, 2021</td>
                                {/* {{ each.startdate }} */}
                                <td>Nov. 26, 2021</td>
                                {/* {{ each.enddate }} */}
                                {/* {{each.enddate}} */}
                                <td><input hidden id="userdate" value="texy" />Dec. 15, 2021</td>
                                {/* {{ each.prstatus }} */}
                                <td>Completed</td>
                            </tr>
                            <tr className="tbl{{each.id}}">
                                {/* {% if each.enddate|date:'Y-m-d' < currentDate and each.prstatus == "Awaiting Self Assessment from Supplier"%} */}
                                {/* onclick="showAlert()" */}
                                {/* <td><a href="#"> gtext</a></td> */}
                                {/* <!-- <td>{{each.proid}}</td> --> */}
                                {/* {% else %} */}
                                <td><a href="{% url 'msareviewpr' each.id %}">MSAA7172026112021</a></td>
                                {/* {% endif %} */}
                                {/* {{ each.updated_at | date }} */}
                                <td>Nov. 26, 2021</td>
                                {/* {{ each.startdate }} */}
                                <td>Nov. 26, 2021</td>
                                {/* {{ each.enddate }} */}
                                {/* {{each.enddate}} */}
                                <td><input hidden id="userdate" value="texy" />Dec. 15, 2021</td>
                                {/* {{ each.prstatus }} */}
                                <td>Completed</td>
                            </tr>
                            <tr className="tbl{{each.id}}">
                                {/* {% if each.enddate|date:'Y-m-d' < currentDate and each.prstatus == "Awaiting Self Assessment from Supplier"%} */}
                                {/* onclick="showAlert()" */}
                                {/* <td><a href="#"> gtext</a></td> */}
                                {/* <!-- <td>{{each.proid}}</td> --> */}
                                {/* {% else %} */}
                                <td><a href="{% url 'msareviewpr' each.id %}">MSAA7172026112021</a></td>
                                {/* {% endif %} */}
                                {/* {{ each.updated_at | date }} */}
                                <td>Nov. 26, 2021</td>
                                {/* {{ each.startdate }} */}
                                <td>Nov. 26, 2021</td>
                                {/* {{ each.enddate }} */}
                                {/* {{each.enddate}} */}
                                <td><input hidden id="userdate" value="texy" />Dec. 15, 2021</td>
                                {/* {{ each.prstatus }} */}
                                <td>Completed</td>
                            </tr>
                            <tr className="tbl{{each.id}}">
                                {/* {% if each.enddate|date:'Y-m-d' < currentDate and each.prstatus == "Awaiting Self Assessment from Supplier"%} */}
                                {/* onclick="showAlert()" */}
                                {/* <td><a href="#"> gtext</a></td> */}
                                {/* <!-- <td>{{each.proid}}</td> --> */}
                                {/* {% else %} */}
                                <td><Button onClick={handleShow}>MSAA7172026112021</Button></td>
                                {/* {% endif %} */}
                                {/* {{ each.updated_at | date }} */}
                                <td>Nov. 26, 2021</td>
                                {/* {{ each.startdate }} */}
                                <td>Nov. 26, 2021</td>
                                {/* {{ each.enddate }} */}
                                {/* {{each.enddate}} */}
                                <td><input hidden id="userdate" value="texy" />Dec. 15, 2021</td>
                                {/* {{ each.prstatus }} */}
                                <td>Completed</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

        </div >
    );
}
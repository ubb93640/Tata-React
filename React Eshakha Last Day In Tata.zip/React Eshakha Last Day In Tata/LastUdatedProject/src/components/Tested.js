import React, { useState, useEffect } from "react";
import { Button } from 'react-bootstrap';
import { encode } from "base-64";
import Modal from 'react-bootstrap/Modal';
import '../App.css';

export default function Tested() {
    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    const [lastName, setName1] = useState();
    // const [dataArray1, setDataArray1] = useState([]);

    const [dataArray, setDataArray] = useState([]);
    function getUdate() {
        const username = 'A71720K01';
        const password = 'pass@123';
        const headerss = new Headers();
        headerss.append("authorization", "Basic QTcxNzIwSzAxOnBhc3NAMTIz", encode(username, ":", password));
        headerss.append('Content-Type', 'application/json');
        fetch('https://vendor360qa.tatamotors.com/api/contactprofilevendorviewdata', {
            method: 'POST',
            headers: headerss,
            body: JSON.stringify({ vendordata: ["A71720"] })
        }).then((response) => response.json())
            .then((responseJson) => {
                const responseArray = [];
                const prfilePost = [{ designation: "Chairman", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "Managing Director", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "CEO", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "CFO", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "Plant Head", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "Quality Head", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "Manufacturing Head", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "Key Account Manager", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "Finance Manager", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "Dispatch Manager", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }];
                const loda = [];
                const apidata = Object.values(responseJson);
                for (let i = 0; i < apidata.length; i += 1) {
                    for (let j = 0; j < apidata[i].length; j += 1) {
                        const data = {
                            // post: prfilePost[j],
                            user: apidata[i][j][0],
                            vandorName: apidata[i][j][1],
                            designation: apidata[i][j][2],
                            firstName: apidata[i][j][3],
                            lastName: apidata[i][j][4],
                            emailID: apidata[i][j][5],
                            phoneNumber: apidata[i][j][6],
                            location: apidata[i][j][7],
                            lastUpdated: apidata[i][j][8]
                        }
                        responseArray.push(data)
                        loda.push(prfilePost)
                    }

                    setDataArray(responseArray)
                    // setDataArray1(prfilePost)
                }

                // console.log("sndhgsddgh", responseArray);



            })
            .catch((error) => {
                console.error(error);
            });
    }
    useEffect(() => {
        getUdate();
    }, []);
    const vaue = "";
    console.log(vaue);
    let edited = true;
    if (vaue === "") {
        edited = true;
    } else {
        edited = false;
    }
    // let counter = 0
    return (


        <div className="container-fluid">

            <Modal show={show}
                onHide={handleClose}
                backdrop="static"
                keyboard={false}
            >
                <Modal.Body style={{ textAlign: "center" }}>
                    <div className="swal-icon swal-icon--success">
                        <span className="swal-icon--success__line swal-icon--success__line--long"> </span>
                        <span className="swal-icon--success__line swal-icon--success__line--tip"> </span>

                        <div className="swal-icon--success__ring"> </div>
                        <div className="swal-icon--success__hide-corners"> </div>
                    </div>
                    <h3>Thank You</h3>
                    <p>Kyc Details Upadted Successfully</p>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="primary" onClick={handleClose}>Ok</Button>
                </Modal.Footer>
            </Modal>
            <div className="row">
                <div className="col-md-12">
                    <h3 className="card-header text-center text-light mx-2 my-4 font-weight-bold rounded py-2 contacthead"
                    >Contact Profile for Automotive Stampings And Assemblies</h3>
                </div>
            </div>

            <div className="row">
                <div className="col-md-12">
                    <div id="table" className="table-editable">
                        <table className="table table-striped table-bordered rounded table-hover contactstable">
                            <thead className="thead-dark">
                                <tr className="tableheader">
                                    <th className="text-center stickyheader">Designation</th>
                                    <th className="text-center stickyheader">First Name</th>
                                    <th className="text-center stickyheader">Last Name</th>
                                    <th className="text-center stickyheader">Phone Number</th>
                                    <th className="text-center stickyheader">Email ID</th>
                                    <th className="text-center stickyheader">Action</th>
                                    <th className="text-center stickyheader">Last Updated On</th>
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    dataArray.map(item => <tr key={item.id} className="tbrownum{{forloop.counter}}">
                                        <td className="pt-3-half text-light bg-secondary font-weight-bold"> {item.designation}</td>
                                        <td className="pt-3-half" contentEditable="true" value={vaue} >{item.firstName}</td>
                                        <td className="pt-3-half" contentEditable="true" ><input className="inputText" value={vaue} onChange={(e) => setName1(e.target.value)} /> </td>
                                        <td className="pt-3-half" contentEditable="true" >{item.phoneNumber}</td>
                                        <td className="pt-3-half" contentEditable="true" >{item.emailID} </td>
                                        <td className="pt-3-half text-success" id="updatedate{{forloop.counter}}"   >
                                            {edited ? (<button type="button" className="btn btn-success btn-rounded btn-sm my-0" id="updatebtn1" disabled={!lastName} onClick={handleShow} isLoggedIn={false} >  Update</button>) :
                                                (<button type="button" className="btn btn-danger btn-rounded btn-sm my-0" id="updatebtn1" disabled={!lastName} onClick={handleShow} >  Create</button>)}
                                        </td>
                                        <td className="pt-3-half text-success" id="updatedate{{forloop.counter}}" > {item.lastUpdated}</td>
                                    </tr>)
                                }
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    );
}
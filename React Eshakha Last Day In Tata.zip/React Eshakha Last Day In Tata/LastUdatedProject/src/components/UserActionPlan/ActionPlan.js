import React from "react";
// import { Button } from 'react-bootstrap';
// import { encode } from "base-64";
// import Modal from 'react-bootstrap/Modal';
// import '../App.css';
import { useHistory } from 'react-router-dom';

const ActionPlan = () => {
    const history = useHistory();
    // const [show, setShow] = useState(false);
    // const handleClose = () => setShow(false);
    // const handleShow = () => setShow(true);
    // const [lastName, setName1] = useState();
    // const [dataArray1, setDataArray1] = useState([]);

    // const [dataArray, setDataArray] = useState([]);
    // function getUdate() {
    //     const username = 'A71720K01';
    //     const password = 'pass@123';
    //     const headerss = new Headers();
    //     headerss.append("authorization", "Basic QTcxNzIwSzAxOnBhc3NAMTIz", encode(username, ":", password));
    //     headerss.append('Content-Type', 'application/json');
    //     fetch('https://vendor360qa.tatamotors.com/api/contactprofilevendorviewdata', {
    //         method: 'POST',
    //         headers: headerss,
    //         body: JSON.stringify({ vendordata: ["A71720"] })
    //     }).then((response) => response.json())
    //         .then((responseJson) => {
    //             const responseArray = [];
    //             const prfilePost = [{ designation: "Chairman", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "Managing Director", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "CEO", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "CFO", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "Plant Head", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "Quality Head", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "Manufacturing Head", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "Key Account Manager", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "Finance Manager", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "Dispatch Manager", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }];
    //             const loda = [];
    //             const apidata = Object.values(responseJson);
    //             for (let i = 0; i < apidata.length; i += 1) {
    //                 for (let j = 0; j < apidata[i].length; j += 1) {
    //                     const data = {
    //                         // post: prfilePost[j],
    //                         user: apidata[i][j][0],
    //                         vandorName: apidata[i][j][1],
    //                         designation: apidata[i][j][2],
    //                         firstName: apidata[i][j][3],
    //                         lastName: apidata[i][j][4],
    //                         emailID: apidata[i][j][5],
    //                         phoneNumber: apidata[i][j][6],
    //                         location: apidata[i][j][7],
    //                         lastUpdated: apidata[i][j][8]
    //                     }
    //                     responseArray.push(data)
    //                     loda.push(prfilePost)
    //                 }

    //                 setDataArray(responseArray)
    //                 setDataArray1(prfilePost)
    //             }

    //             // console.log("sndhgsddgh", responseArray);



    //         })
    //         .catch((error) => {
    //             console.error(error);
    //         });
    // }
    // useEffect(() => {
    //     getUdate(dataArray1);
    // }, []);
    // const vaue = "";
    // console.log(vaue);
    // let edited = true;
    // if (vaue === "") {
    //     edited = true;
    // } else {
    //     edited = false;
    // }
    // let counter = 0
    return (
        <div className="container-fluid">
            <button onClick={() => history.goBack()} type="button">Go Back</button>
            <form id="Frm_id1" method="POST">

                <div className="row mt-3">
                    <div className="col text-left justify-content">
                        {/* style="background-color: rgb(207,221,230);" */}
                        <h4 className="text-dark py-1" style={{ background: "#cfddf2" }} >Phygital MSA / Action Plan</h4>

                    </div>
                </div>
                <div className="row mb-3" style={{ height: " 450px", overflow: "auto" }} >
                    <div className="col-md-12">
                        <table className="table table-hover table-bordered " id="mytable">
                            {/* style="font-size: 18px;" */}
                            <thead className="actionPlan" style={{ fontSize: "18px" }} >
                                <tr>

                                    {/* style="text-align: center;vertical-align: middle;" */}
                                    <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }}>Project ID </th>
                                    <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }} >Action Plan Initiated Date</th>
                                    <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }}>Status</th>
                                </tr>
                            </thead>

                            <tbody>
                                <tr className="tbl{{each.id}}">

                                    <td><a href="{% url 'msareviewpr' each.id %}">MSAA7172026112021</a></td>

                                    <td>Nov. 26, 2021</td>

                                    <td>Completed</td>
                                </tr>
                                <tr className="tbl{{each.id}}">

                                    <td><a href="{% url 'msareviewpr' each.id %}">MSAA7172026112021</a></td>

                                    <td>Nov. 26, 2021</td>

                                    <td>Completed</td>
                                </tr>
                                <tr className="tbl{{each.id}}">

                                    <td><a href="{% url 'msareviewpr' each.id %}">MSAA7172026112021</a></td>

                                    <td>Nov. 26, 2021</td>

                                    <td>Completed</td>
                                </tr>
                                <tr className="tbl{{each.id}}">

                                    <td><a href="{% url 'msareviewpr' each.id %}">MSAA7172026112021</a></td>

                                    <td>Nov. 26, 2021</td>

                                    <td>Completed</td>
                                </tr>
                                <tr className="tbl{{each.id}}">

                                    <td><a href="{% url 'msareviewpr' each.id %}">MSAA7172026112021</a></td>

                                    <td>Nov. 26, 2021</td>

                                    <td>Completed</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

            </form>
        </div>
    );
}
export default ActionPlan;
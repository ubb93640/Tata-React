import React from "react";
// import { Button } from 'react-bootstrap';
// import { encode } from "base-64";
// import Modal from 'react-bootstrap/Modal';
// import '../App.css';

export default function ActionPlanId() {
    // const [show, setShow] = useState(false);
    // const handleClose = () => setShow(false);
    // const handleShow = () => setShow(true);
    // const [lastName, setName1] = useState();
    // const [dataArray1, setDataArray1] = useState([]);

    // const [dataArray, setDataArray] = useState([]);
    // function getUdate() {
    //     const username = 'A71720K01';
    //     const password = 'pass@123';
    //     const headerss = new Headers();
    //     headerss.append("authorization", "Basic QTcxNzIwSzAxOnBhc3NAMTIz", encode(username, ":", password));
    //     headerss.append('Content-Type', 'application/json');
    //     fetch('https://vendor360qa.tatamotors.com/api/contactprofilevendorviewdata', {
    //         method: 'POST',
    //         headers: headerss,
    //         body: JSON.stringify({ vendordata: ["A71720"] })
    //     }).then((response) => response.json())
    //         .then((responseJson) => {
    //             const responseArray = [];
    //             const prfilePost = [{ designation: "Chairman", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "Managing Director", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "CEO", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "CFO", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "Plant Head", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "Quality Head", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "Manufacturing Head", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "Key Account Manager", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "Finance Manager", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "Dispatch Manager", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }];
    //             const loda = [];
    //             const apidata = Object.values(responseJson);
    //             for (let i = 0; i < apidata.length; i += 1) {
    //                 for (let j = 0; j < apidata[i].length; j += 1) {
    //                     const data = {
    //                         // post: prfilePost[j],
    //                         user: apidata[i][j][0],
    //                         vandorName: apidata[i][j][1],
    //                         designation: apidata[i][j][2],
    //                         firstName: apidata[i][j][3],
    //                         lastName: apidata[i][j][4],
    //                         emailID: apidata[i][j][5],
    //                         phoneNumber: apidata[i][j][6],
    //                         location: apidata[i][j][7],
    //                         lastUpdated: apidata[i][j][8]
    //                     }
    //                     responseArray.push(data)
    //                     loda.push(prfilePost)
    //                 }

    //                 setDataArray(responseArray)
    //                 setDataArray1(prfilePost)
    //             }

    //             // console.log("sndhgsddgh", responseArray);



    //         })
    //         .catch((error) => {
    //             console.error(error);
    //         });
    // }
    // useEffect(() => {
    //     getUdate(dataArray1);
    // }, []);
    // const vaue = "";
    // console.log(vaue);
    // let edited = true;
    // if (vaue === "") {
    //     edited = true;
    // } else {
    //     edited = false;
    // }
    // let counter = 0
    return (
        <div className="container-fluid">
            <div className="container">
                <div className="row mt-4 ml-5">
                    {/* onclick="filterdata('Auditors Assessment Completed')" */}

                    <div className="col-md-4 poi px-2 py-3 rounded text-light mx-5" style={{ background: "#d17015", }} >

                        <div className="row text-center justify-content" style={{ fontSize: "17px", marginLeft: "42%", color: "#000000" }}>Pending</div>

                        <div className="row"><b style={{ fontSize: "40px", color: "#000000" }} className="text-center mx-auto ywa">9</b></div>

                    </div>
                    {/* onclick="filterdata('Lead auditing')" */}
                    <div className="col-md-4 poi px-2 py-3 rounded text-light mx-5" style={{ background: "#65ab57", }} >

                        <div className="row text-center justify-content" style={{ fontSize: "17px", marginLeft: "42%", color: "#000000" }}>Closed</div>

                        <div className="row">

                            <b style={{ fontSize: "40px", color: "#000000" }} className="text-center mx-auto aac">1</b></div>

                    </div>

                </div>
            </div>

            <form id="Frm_id1" method="POST">

                <div className="row mt-3">
                    <div className="col text-left justify-content">
                        {/* style="background-color: rgb(207,221,230);" */}
                        <h4 className="text-dark py-1" style={{ background: "#cfddf2" }} >Phygital MSA / Action Plan / MSAA7172026112021</h4>

                    </div>
                </div>
                <div className="row mb-3" style={{ height: " 450px", overflow: "auto" }} >
                    <div className="col-md-12">
                        <table className="table table-hover table-bordered " id="mytable">
                            {/* style="font-size: 18px;" */}
                            <thead className="actionPlan" style={{ fontSize: "18px" }} >
                                <tr>

                                    {/* style="text-align: center;vertical-align: middle;" */}
                                    <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }}>S No. </th>

                                    <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }}>MSA Pillar</th>

                                    <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }}>Question No</th>

                                    <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }}>Opportunity for Improvement </th>
                                    <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }}>Auditor Name</th>

                                    <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }}>Target Closure Date</th>

                                    <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }}>Supplier Commitment date for closure	</th>

                                    <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }} >Issue Status</th>
                                </tr>
                            </thead>

                            <tbody>
                                <tr className="tbl{{each.id}}">
                                    <td> 1</td>
                                    <td> Company Management</td>
                                    <td> 1.11</td>
                                    <td><a href="{% url 'msareviewpr' each.id %}">	OFI 1.11</a></td>
                                    <td> AuditorFin</td>
                                    <td>10-05-2022</td>
                                    <td> 09-05-2022</td>
                                    <td>Submitted by Supplier</td>
                                </tr>
                                <tr className="tbl{{each.id}}">
                                    <td><input type="checkbox" /> 2</td>
                                    <td> Company Management</td>
                                    <td> 1.11</td>
                                    <td><a href="{% url 'msareviewpr' each.id %}">	OFI 1.11</a></td>
                                    <td> AuditorFin</td>
                                    <td>10-05-2022</td>
                                    <td><input type="date" placeholder="dd/mm/yyyy" disabled /></td>
                                    <td> </td>
                                </tr>
                                <tr className="tbl{{each.id}}">
                                    <td> 3</td>
                                    <td> Company Management</td>
                                    <td> 1.11</td>
                                    <td><a href="{% url 'msareviewpr' each.id %}">	OFI 1.11</a></td>
                                    <td> AuditorFin</td>
                                    <td>10-05-2022</td>
                                    <td> 09-05-2022</td>
                                    <td>Submitted by Supplier</td>
                                </tr>
                                <tr className="tbl{{each.id}}">
                                    <td> 4</td>
                                    <td> Company Management</td>
                                    <td> 1.11</td>
                                    <td><a href="{% url 'msareviewpr' each.id %}">	OFI 1.11</a></td>
                                    <td> AuditorFin</td>
                                    <td>10-05-2022</td>
                                    <td> 09-05-2022</td>
                                    <td>Submitted by Supplier</td>
                                </tr>
                                <tr className="tbl{{each.id}}">
                                    <td> 5</td>
                                    <td> Company Management</td>
                                    <td> 1.11</td>
                                    <td><a href="{% url 'msareviewpr' each.id %}">	OFI 1.11</a></td>
                                    <td> AuditorFin</td>
                                    <td>10-05-2022</td>
                                    <td> 09-05-2022</td>
                                    <td>Submitted by Supplier</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

            </form>
        </div>
    );
}
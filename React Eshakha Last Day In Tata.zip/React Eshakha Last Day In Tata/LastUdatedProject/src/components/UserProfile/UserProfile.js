import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import PowerSettingsNewIcon from '@material-ui/icons/PowerSettingsNew';
import PersonOutlineOutlinedIcon from '@material-ui/icons/PersonOutlineOutlined';

import authActions from '../../redux/features/auth/actions';
import styles from './UserProfile.module.css';
import { Button, PopoverPaper } from '../../atomicComponents';

const UserProfile = ({ open, handleClose, anchorEl, user, logoutUser }) => (
  <PopoverPaper
    open={open}
    handleClose={handleClose}
    anchorEl={anchorEl}
    anchorOrigin={{
      vertical: 'bottom',
      horizontal: 'right',
    }}
  >
    <div className={styles.display}>
      <div className={styles.iconContainer}>
        <PersonOutlineOutlinedIcon className={styles.personIcon} />
      </div>
      <div className={styles.details}>
        <span className={styles.name}>{user?.name}</span>
        <span className={styles.email}>{user?.email}</span>
        <Button
          ignoreExistingClassNames
          className={styles.logoutButton}
          startIcon={<PowerSettingsNewIcon />}
          onClick={logoutUser}
        >
          Logout
        </Button>
      </div>
    </div>
  </PopoverPaper>
);

UserProfile.propTypes = {
  open: PropTypes.bool.isRequired,
  handleClose: PropTypes.func.isRequired,
  anchorEl: PropTypes.instanceOf(Element),
  user: PropTypes.object,
  logoutUser: PropTypes.func.isRequired,
};

export default connect(({ auth }) => ({ user: auth.user }), {
  logoutUser: authActions.logoutUser,
})(UserProfile);

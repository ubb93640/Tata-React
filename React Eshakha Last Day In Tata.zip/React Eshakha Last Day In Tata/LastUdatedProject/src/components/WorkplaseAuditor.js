import React from "react";
// import { Button } from 'react-bootstrap';
// import { encode } from "base-64";
// import Modal from 'react-bootstrap/Modal';
import '../App.css';

export default function WorkplaseAuditor() {
    // const [rowsData, setRowsData] = useState([]);

    // const addTableRows = () => {
    //     const rowsInput = {
    //         fullName: '',
    //         emailAddress: '',
    //         salary: ''
    //     }
    //     setRowsData([...rowsData, rowsInput])

    // }
    // const [show, setShow] = useState(false);
    // const handleClose = () => setShow(false);
    // const handleShow = () => setShow(true);
    // const [lastName, setName1] = useState();
    // const [dataArray1, setDataArray1] = useState([]);

    // const [dataArray, setDataArray] = useState([]);
    // function getUdate() {
    //     const username = 'A71720K01';
    //     const password = 'pass@123';
    //     const headerss = new Headers();
    //     headerss.append("authorization", "Basic QTcxNzIwSzAxOnBhc3NAMTIz", encode(username, ":", password));
    //     headerss.append('Content-Type', 'application/json');
    //     fetch('https://vendor360qa.tatamotors.com/api/contactprofilevendorviewdata', {
    //         method: 'POST',
    //         headers: headerss,
    //         body: JSON.stringify({ vendordata: ["A71720"] })
    //     }).then((response) => response.json())
    //         .then((responseJson) => {
    //             const responseArray = [];
    //             const prfilePost = [{ designation: "Chairman", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "Managing Director", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "CEO", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "CFO", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "Plant Head", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "Quality Head", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "Manufacturing Head", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "Key Account Manager", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "Finance Manager", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }, { designation: "Dispatch Manager", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: "", lastUpdated: "" }];
    //             const loda = [];
    //             const apidata = Object.values(responseJson);
    //             for (let i = 0; i < apidata.length; i += 1) {
    //                 for (let j = 0; j < apidata[i].length; j += 1) {
    //                     const data = {
    //                         // post: prfilePost[j],
    //                         user: apidata[i][j][0],
    //                         vandorName: apidata[i][j][1],
    //                         designation: apidata[i][j][2],
    //                         firstName: apidata[i][j][3],
    //                         lastName: apidata[i][j][4],
    //                         emailID: apidata[i][j][5],
    //                         phoneNumber: apidata[i][j][6],
    //                         location: apidata[i][j][7],
    //                         lastUpdated: apidata[i][j][8]
    //                     }
    //                     responseArray.push(data)
    //                     loda.push(prfilePost)
    //                 }

    //                 setDataArray(responseArray)
    //                 setDataArray1(prfilePost)
    //             }

    //             // console.log("sndhgsddgh", responseArray);



    //         })
    //         .catch((error) => {
    //             console.error(error);
    //         });
    // }
    // useEffect(() => {
    //     getUdate(dataArray1);
    // }, []);
    // const vaue = "";
    // console.log(vaue);
    // let edited = true;
    // if (vaue === "") {
    //     edited = true;
    // } else {
    //     edited = false;
    // }
    // let counter = 0
    return (

        <div className="container-fluid">
            <div className="container-fluid">
                <div className="row mt-4 ml-4">
                    {/* onclick="filterdata('Auditors Assessment Completed')" */}
                    <div className="col-md-3 poi px-2 py-3 rounded text-light mx-5" style={{ backgroundColor: "#d17015" }} >
                        <div className="row text-center justify-content" style={{ color: "black", fontSize: "17px", marginLeft: "31%" }}>Awaiting Receipt</div>
                        <div className="row"><b style={{ color: "black", fontSize: "40px" }} className="text-center mx-auto ywa">0</b></div>
                        {/* </div>onclick="filterdata('Lead auditing')" */}
                    </div>
                    <div className="col-md-3 poi px-2 py-3 rounded text-light mx-5" style={{ backgroundColor: "#e8e180" }} >
                        <div className="row text-center justify-content" style={{ color: "black", fontSize: "17px", marginLeft: "45%" }} >WIP</div>
                        <div className="row">
                            <b style={{ color: "black", fontSize: "40px" }} className="text-center mx-auto aac">3</b></div>
                        {/* </div>onclick="filterdata('completed')" */}
                    </div>
                    <div className="col-md-3 poi px-2 py-3 rounded text-light ml-4" style={{ backgroundColor: "#65ab57" }} >
                        <div className="text-center justify-content" style={{ color: "black", fontSize: "17px" }} >
                            Completed </div>
                        <div className="row">
                            <b style={{ color: "black", fontSize: "40px" }} className="mx-auto text-center justify-content com">2</b></div>
                    </div>
                </div>
            </div>
            <br />
            <form id="Frm_id1" method="POST">

                <div className="row">
                    <div className="col-md-2 ml-auto">
                        <input type="text" id="search" placeholder="Search..." className="form-control mb-1 border-primary" />
                    </div>
                </div>
                <div className="row mb-3" style={{ height: " 450px", overflow: "auto" }} >
                    <div className="col-md-12">
                        <table className="table table-hover table-bordered " id="mytable">
                            {/* style="font-size: 18px;" */}
                            <thead className="actionPlan" style={{ fontSize: "18px" }} >
                                <tr>

                                    {/* style="text-align: center;vertical-align: middle;" */}
                                    <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }}>Project ID</th>

                                    <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }}>Vendor Code</th>

                                    <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }}>Supplier Name</th>

                                    <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }}>Assessment Reason </th>
                                    <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }}>Assignment Date</th>

                                    <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }}>Assessment Start Date</th>

                                    <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }}>Assessment End Date</th>

                                    <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }} >MSA Lead</th>
                                    <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }} >Received Date</th>

                                    <th scope="col" className="stickyheader" style={{ textAlign: "center", verticalAlign: "middle" }} >Target Completion date</th>



                                </tr>
                            </thead>

                            <tbody>
                                <tr className="tbl{{each.id}}">
                                    <td><a href="{% url 'msareviewpr' each.id %}">MSAA7172023022022</a></td>
                                    <td>A71720</td>
                                    <td>AUTOMOTIVE STAMPINGS AND ASSEMBLIES</td>
                                    <td>re-audit</td>
                                    <td>Feb. 23, 2022</td>
                                    <td>Feb. 23, 2022</td>
                                    <td>Feb. 27, 2022</td>
                                    <td>pritam solunke</td>
                                    <td>Feb. 23, 2022</td>
                                    <td>Feb. 27, 2022</td>



                                </tr>
                                <tr className="tbl{{each.id}}">
                                    <td><a href="{% url 'msareviewpr' each.id %}">MSAA7172023022022</a></td>
                                    <td>A71720</td>
                                    <td>AUTOMOTIVE STAMPINGS AND ASSEMBLIES</td>
                                    <td>re-audit</td>
                                    <td>Feb. 23, 2022</td>
                                    <td>Feb. 23, 2022</td>
                                    <td>Feb. 27, 2022</td>
                                    <td>pritam solunke</td>
                                    <td>Feb. 23, 2022</td>
                                    <td>Feb. 27, 2022</td>



                                </tr>
                                <tr className="tbl{{each.id}}">
                                    <td><a href="{% url 'msareviewpr' each.id %}">MSAA7172023022022</a></td>
                                    <td>A71720</td>
                                    <td>AUTOMOTIVE STAMPINGS AND ASSEMBLIES</td>
                                    <td>re-audit</td>
                                    <td>Feb. 23, 2022</td>
                                    <td>Feb. 23, 2022</td>
                                    <td>Feb. 27, 2022</td>
                                    <td>pritam solunke</td>
                                    <td>Feb. 23, 2022</td>
                                    <td>Feb. 27, 2022</td>

                                </tr>
                                <tr className="tbl{{each.id}}">
                                    <td><a href="{% url 'msareviewpr' each.id %}">MSAA7172023022022</a></td>
                                    <td>A71720</td>
                                    <td>AUTOMOTIVE STAMPINGS AND ASSEMBLIES</td>
                                    <td>re-audit</td>
                                    <td>Feb. 23, 2022</td>
                                    <td>Feb. 23, 2022</td>
                                    <td>Feb. 27, 2022</td>
                                    <td>pritam solunke</td>
                                    <td>Feb. 23, 2022</td>
                                    <td>Feb. 27, 2022</td>

                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

            </form>
        </div>
    );
}
export const BASE_URL = process.env.API_URL 
                        ? process.env.API_URL : "http://127.0.0.1:8000" 

// eslint-disable-next-line import/prefer-default-export
export const ENV_TYPES = {
  TEST: 'TEST',
  PRODUCTION: 'PRODUCTION',
};

export const LOG_LEVEL = {
  INFO: { name: 'INFO', value: 1 },
  WARN: { name: 'WARN', value: 2 },
  ERROR: { name: 'ERROR', value: 3 },
};

export const API_RESOURCE_URLS = {
  LOG_ERROR: 'logs',
  PLANTS: 'plant-master/plants',
};
export const APPLICATION_NAME = 'EP Performance Insights';

export const DATE_FORMAT = {
  ISO: 'YYYY-MM-DD',
  ISO_DATE_FNS: 'yyyy-MM-dd',
  DAY_MONTH_YEAR: 'DD-MM-YYYY',
};

export const PERSONAS = {
  BUYER: 'BUYER',
  VENDOR: 'VENDOR',
  FBV_VENDOR: 'VENDOR_WITH_FBV',
  FBV: 'FBV',
};

export const SORT_STATE = {
  ASCENDING: 'ascending',
  DESCENDING: 'descending',
  UNSORTED: 'unsorted',
};

export const PUNE_PLANT_VALUE = '1001';

export const MESSAGE_TYPE = {
  SUCCESS: 'Success',
  FAILURE: 'Fail',
  INFORMATION: 'Information',
  INTERNAL_ERROR: 'Internal Error',
  LOADING: 'Loading',
};

export const VENDOR_OPERATIONS = {
  DROP_MATERIAL: 'drop-material',
  DISPATCH_MATERIAL: 'dispatch-material',
};

export const BUYER_OPERATIONS = {
  DISPATCH_MATERIAL: 'dispatch-material',
};

export const ASN_STATUS = {
  READY_FOR_DROP: 'READY_FOR_DROP',
  LINE_OUT: 'LINE_OUT',
  PLANNED: 'PLANNED',
  LINE_ON: 'LINE_ON',
  DROPPED: 'DROPPED',
  ROLLED: 'ROLLED',
  WTCL: 'WTCL',
  SFLT: 'SFLT',
};

export const ASN_STATUS_SORT_ORDER = {
  [ASN_STATUS.DROPPED]: 0,
  [ASN_STATUS.ROLLED]: 1,
  [ASN_STATUS.WTCL]: 2,
};

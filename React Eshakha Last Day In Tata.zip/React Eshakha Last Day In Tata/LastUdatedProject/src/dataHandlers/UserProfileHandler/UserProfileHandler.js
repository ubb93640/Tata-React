import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import userProfileActions from '../../redux/features/userProfile/actions';
import { CancelToken } from '../../apis/api';
import { usePopupManager } from '../../providers/PopupManager/PopupManager';

const UserProfileHandler = ({
  isAuthenticated,
  children,
  initializeUserProfile,
  plantValue,
  preferredUserName,
  loadUserMaterialGroups,
  currentUserId,
}) => {
  const { showLoading } = usePopupManager();

  useEffect(() => {
    // note: currently considering preffered_username in keycloak as userID
    if (isAuthenticated && plantValue && preferredUserName)
      initializeUserProfile(plantValue, preferredUserName);
  }, [isAuthenticated, initializeUserProfile, plantValue, preferredUserName]);

  useEffect(() => {
    if (isAuthenticated && plantValue && currentUserId) {
      const cancelTokenSource = CancelToken.source();
      const closeLoading = showLoading();
      loadUserMaterialGroups(plantValue, currentUserId, cancelTokenSource).then(
        closeLoading,
      );
      return () => cancelTokenSource.cancel();
    }
    return null;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAuthenticated, plantValue, currentUserId, loadUserMaterialGroups]);

  return <>{children}</>;
};

UserProfileHandler.propTypes = {
  children: PropTypes.any,
  isAuthenticated: PropTypes.bool.isRequired,
  initializeUserProfile: PropTypes.func.isRequired,
  plantValue: PropTypes.any,
  preferredUserName: PropTypes.string,
  currentUserId: PropTypes.string,
  loadUserMaterialGroups: PropTypes.func.isRequired,
};

export default connect(
  ({ auth, plantStore, userProfile }) => ({
    isAuthenticated: auth.isAuthenticated,
    plantValue: plantStore?.plant?.value,
    preferredUserName: auth?.keycloak?.tokenParsed?.preferred_username,
    currentUserId: userProfile.userId,
  }),
  {
    initializeUserProfile: userProfileActions.initializeUserProfile,
    loadUserMaterialGroups: userProfileActions.loadUserMaterialGroups,
  },
)(UserProfileHandler);

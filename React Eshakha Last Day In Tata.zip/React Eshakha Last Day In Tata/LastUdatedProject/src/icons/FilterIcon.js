import React from 'react';
import { SvgIcon } from '@material-ui/core';

const FilterIcon = props => (
  <SvgIcon {...props}>
    <path d="M17.094 0H.842a.845.845 0 00-.595 1.44l6.478 6.5v7.244a.845.845 0 00.359.691l2.8 1.968a.841.841 0 001.323-.691V7.943l6.479-6.5A.845.845 0 0017.094 0z" />
  </SvgIcon>
);

export default FilterIcon;

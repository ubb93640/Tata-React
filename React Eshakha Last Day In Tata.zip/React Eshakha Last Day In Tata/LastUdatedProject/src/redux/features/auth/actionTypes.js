export const CLEAR_AUTH_DATA = 'clear_auth_data';
export const SET_KEYCLOAK_INSTANCE = 'set_keycloak_instance';
export const LOAD_AUTH_DATA = 'load_auth_data';
export const SET_AUTH_TOKEN = 'set_auth_token';

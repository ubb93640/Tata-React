import { INITIALIZE_PLANT_STORE, SET_PLANT } from './actionTypes';
import { API } from '../../../apis/api';
import { API_RESOURCE_URLS } from '../../../constants';
import { buildErrorMessage } from '../../../apis/calls';

const fetchPlants = async () => {
  const response = await API.get(API_RESOURCE_URLS.PLANTS);
  return response;
};

const getPlantFromLocalStorage = () => {
  const value = localStorage.getItem('plantValue');
  const label = localStorage.getItem('plantLabel');

  if (value && label) return { value, label };
  return null;
};

const initializePlantStore = plantValueFromUrl => async dispatch => {
  try {
    const response = await fetchPlants();
    const plantOptions = response.data.map(record => ({
      value: record.id,
      label: record.name,
    }));
    const plantFromUrl = plantOptions.filter(
      plant => plantValueFromUrl && String(plant.value) === plantValueFromUrl,
    )[0];
    const defaultPlantOption =
      plantFromUrl || getPlantFromLocalStorage() || plantOptions[0];

    dispatch({
      type: INITIALIZE_PLANT_STORE,
      options: plantOptions,
      plant: defaultPlantOption,
    });
  } catch (error) {
    console.error(buildErrorMessage(error));
  }
};

const setPlant = plant => ({
  type: SET_PLANT,
  payload: { ...plant },
});

export default {
  initializePlantStore,
  setPlant,
};

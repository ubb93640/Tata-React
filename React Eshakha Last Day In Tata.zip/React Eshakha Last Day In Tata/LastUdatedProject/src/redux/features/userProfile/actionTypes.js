export const INITIALIZE_USER_PROFILE = 'initialize_user_profile';
export const LOAD_USER_MATERIAL_GROUPS = 'load_user_material_groups';

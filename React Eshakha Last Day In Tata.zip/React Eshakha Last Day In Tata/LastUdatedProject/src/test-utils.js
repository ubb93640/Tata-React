import React from 'react';
import PropTypes from 'prop-types';
import { BrowserRouter as Router } from 'react-router-dom';
import { render, fireEvent, within } from '@testing-library/react';
import { Provider } from 'react-redux';
import { PERSONAS, PUNE_PLANT_VALUE } from './constants';
import configureStore from './redux/configureStore';
import { initialPlantStoreState } from './redux/features/plantStore/plantStoreSlice';
import { PlantsHandler, UserProfileHandler } from './dataHandlers';
import PopupManager from './providers/PopupManager/PopupManager';
import { initialUserProfileState } from './redux/features/userProfile/userProfileSlice';

export const testPlant = {
  label: 'Pune',
  value: PUNE_PLANT_VALUE,
};

export const testVendorUser = {
  userId: 'vendor_user',
  persona: PERSONAS.VENDOR,
};

export const testFbvVendorUser = {
  userId: 'fbv_vendor_user',
  persona: PERSONAS.FBV_VENDOR,
};

const getTestUser = persona => {
  if (persona === PERSONAS.VENDOR) return testVendorUser;
  if (persona === PERSONAS.FBV_VENDOR) return testFbvVendorUser;
  return null;
};

const AllTheProviders = ({
  children,
  personaToLoad = PERSONAS.BUYER,
  testUserMaterialGroups = [
    { materialGroup: 'NS2071', description: 'Load Body' },
  ],
}) => (
  <Provider
    store={configureStore({
      plantStore: {
        ...initialPlantStoreState,
        options: [testPlant],
        plant: testPlant,
      },
      userProfile: {
        ...initialUserProfileState,
        ...getTestUser(personaToLoad),
        userMaterialGroups: testUserMaterialGroups,
      },
    })}
  >
    <PopupManager>
      <Router>
        <PlantsHandler>
          <UserProfileHandler>{children}</UserProfileHandler>
        </PlantsHandler>
      </Router>
    </PopupManager>
  </Provider>
);

export const clickOptionForReactSelect = async ({
  selectName,
  option,
  debug,
}) => {
  const input = document.querySelector(`.select-${selectName}__control input`);
  const controlComp = document.querySelector(`.select-${selectName}__control`);
  fireEvent.focus(input);
  fireEvent.mouseDown(controlComp);
  const menu = document.querySelector(`.select-${selectName}__menu`);
  if (debug) debug(menu);
  const { findByText } = within(menu);
  fireEvent.click(await findByText(option));
};

AllTheProviders.propTypes = {
  personaToLoad: PropTypes.oneOf(Object.values(PERSONAS)),
  children: PropTypes.node.isRequired,
  testUserMaterialGroups: PropTypes.arrayOf(
    PropTypes.shape({
      materialGroup: PropTypes.string.isRequired,
      description: PropTypes.string.isRequired,
    }),
  ),
};

const customRender = (ui, options) =>
  render(ui, {
    wrapper: props => <AllTheProviders {...props} {...options?.wrapperProps} />,
    ...options,
  });

// re-export everything
export * from '@testing-library/react';

// override render method
export { customRender as render };

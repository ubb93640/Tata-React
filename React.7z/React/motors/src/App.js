import logo from './logo.svg'; 
import './App.css';
import axios from 'axios';
import { encode } from "base-64";
import Header from './components/Header'
import Footer from './components/Footer'
import Charte from './components/Charte'
import Card from './components/Card'
import  React, { useEffect, useState } from 'react';
import NewChart from './components/NewChart';
  
function App() { 
let username = 'A71720K01'; 
let password = 'pass@123'; 
let headerss = new Headers();  
const proxyurl = "https://vendor360qa.tatamotors.com";
const url = "/api/sales";
const url2 = "/api/msa";
const url3 = "/api/prr";
const url4 = "/api/newppmapi";
const url5 = "/api/newppmapi1";
headerss.append('Authorization', 'Basic ' + encode(username + ":" + password));
headerss.append('Content-Type', 'application/json');
  fetch(proxyurl + url, {headers :headerss}).then((resp) => resp.json())
  .then(function(data) {
    console.log(data);
  })
  .catch(function(error) {
    console.log(error);
  });
  fetch(proxyurl + url2, {headers :headerss}).then((resp) => resp.json())
  .then(function(data) {
    console.log(data);
  })
  .catch(function(error) {
    console.log(error);
  });
  fetch(proxyurl + url3, {headers :headerss}).then((resp) => resp.json())
  .then(function(data) {
    console.log(data);
  })
  .catch(function(error) {
    console.log(error);
  });
  fetch(proxyurl + url4, {headers :headerss}).then((resp) => resp.json())
  .then(function(data) {
    console.log(data);
  })
  .catch(function(error) {
    console.log(error);
  });
  fetch(proxyurl + url5, {headers :headerss}).then((resp) => resp.json())
  .then(function(data) {
    console.log(data);
  })
  .catch(function(error) {
    console.log(error);
  });
  return (
    <div className="container-fluid p-2">
      <Header /> <br /> 
      <Card />  
      <Footer />
    </div>
  );
}

export default App;

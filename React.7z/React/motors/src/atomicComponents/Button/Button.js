import React, { forwardRef } from 'react';
import clsx from 'clsx';
import { Button as MuiButton } from '@material-ui/core';
import PropTypes from 'prop-types';
import styles from './Button.module.css';

const Button = forwardRef(({ variant, children, className, ...props }, ref) => {
  let modifierClassName;
  if (variant === 'primary') modifierClassName = styles.primaryButton;
  else if (variant === 'secondary') modifierClassName = styles.secondaryButton;
  else modifierClassName = styles.defaultButton;

  return (
    <MuiButton
      className={clsx(styles.button, modifierClassName, className)}
      classes={{ disabled: styles.disabledButton }}
      ref={ref}
      {...props}
    >
      {children}
    </MuiButton>
  );
});

Button.propTypes = {
  children: PropTypes.node.isRequired,
  className: PropTypes.string,
  variant: PropTypes.oneOf(['primary', 'secondary']),
};

export default Button;

import React from 'react';
import Button from './Button';
import './example.css';

export default {
  title: 'Atoms/Button',
  component: Button,
};

const Template = args => <Button {...args} />;

export const Default = Template.bind({});
Default.args = {
  children: <>Click me!</>,
};

export const Primary = Template.bind({});
Primary.args = {
  variant: 'primary',
  children: <>Click me!</>,
};

export const Secondary = Template.bind({});
Secondary.args = {
  variant: 'secondary',
  children: <>Click me!</>,
};

export const Disabled = Template.bind({});
Disabled.args = {
  disabled: true,
  children: <>Click me!</>,
};

export const Custom = Template.bind({});
Custom.args = {
  className: 'customTestButton', // from example
  children: <>Click me!</>,
};

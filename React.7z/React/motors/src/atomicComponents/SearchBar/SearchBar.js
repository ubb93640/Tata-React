import React, { useState } from 'react';
import PropTypes from 'prop-types';
import Select, { components } from 'react-select';
import SearchIcon from '@material-ui/icons/Search';
import styles from './SearchBar.module.css';
import IconButton from '../IconButton/IconButton';

const DropdownIndicator = props => (
  <components.DropdownIndicator {...props}>
    <IconButton className={styles.searchIconButton}>
      <SearchIcon className={styles.searchIcon} />
    </IconButton>
  </components.DropdownIndicator>
);

const SearchBar = ({
  handleSelect,
  placeholderText,
  value,
  name = 'vin',
  className,
  maxMenuHeight = 160,
  onChange,
  ...props
}) => {
  const MIN_NO_CHARACTERS = 3;
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <div>
      <Select
        noOptionsMessage={() => 'VIN not found'}
        placeholder="Enter atleast 3 characters ..."
        value={value}
        className={className}
        classNamePrefix={`select-${name}`}
        maxMenuHeight={maxMenuHeight}
        onInputChange={(val, { action }) => {
          if (action === 'input-change')
            if (val.length >= MIN_NO_CHARACTERS) setIsMenuOpen(true);
            else setIsMenuOpen(false);
          if (action === 'menu-close') setIsMenuOpen(false);
        }}
        onBlur={() => setIsMenuOpen(false)}
        menuIsOpen={isMenuOpen}
        onChange={valueData => handleSelect(valueData.value)}
        styles={{
          menuList: provided => ({
            ...provided,
            '&::-webkit-scrollbar': {
              width: '4px !important',
              height: '6px',
              display: 'block !important',
              background: 'none',
            },
            '&::-webkit-scrollbar-track': {
              background: 'none',
            },
            '&::-webkit-scrollbar-thumb': {
              background: '#f17c7c',
            },
            '&::-webkit-scrollbar-thumb:hover': {
              background: '#da6363',
            },
          }),
        }}
        theme={theme => ({
          ...theme,
          border: 'solid 1px #707070',
        })}
        components={{ DropdownIndicator }}
        {...props}
      />
    </div>
  );
};

SearchBar.propTypes = {
  handleSelect: PropTypes.func.isRequired,
  placeholderText: PropTypes.string,
  value: PropTypes.shape({
    value: PropTypes.string.isRequired,
    label: PropTypes.string.isRequired,
  }),
  name: PropTypes.string,
  className: PropTypes.string,
  maxMenuHeight: PropTypes.number,
  onChange: PropTypes.func.isRequired,
};

export default SearchBar;

import React, { Component } from 'react';
import ReactEcharts from 'echarts-for-react';
import { encode } from "base-64";


class Chart extends Component {
  constructor(props) { 
    super(props);
    this.state = {
      chartData: { 
      },
      
    }

  }

  componentDidMount() { 
    this.getData(); 
  }
 getData(){
  var i = [];
  
    let username = 'A71720K01';
    let password = 'pass@123';
    let headerss = new Headers();
    const proxyurl = "https://vendor360qa.tatamotors.com";
    const url = "/api/msa";
    headerss.append('Authorization', 'Basic ' + encode(username + ":" + password));
    headerss.append('Content-Type', 'application/json');
    fetch(proxyurl + url, { headers: headerss }).then((resp) => resp.json())
      .then((response) => { 
        var xaxisarr = [];
        var yaxisarr = [];
        var clist = [];
        var apidata = Object.values(response);
        for (i = 0; i < apidata.length; i++) { 
          xaxisarr.push(apidata[i]['actual']);
          yaxisarr.push(apidata[i]['threshold']);
        }
        if (xaxisarr>=70){
          clist=['#3344db','#A20000']
          }else  { 
            clist=['#3344db','#708090']
          } 
        this.setState({
          
          chartData: {
            xaxisarr:xaxisarr,
            yaxisarr:yaxisarr, 
            clist:clist,
          }
        }); 
        
      })
      .catch((error) => {
        console.log(error);
      });
}
  render() {
    return (
    
      <ReactEcharts style={{
        width: "100%",
        height: "200px",
      }}

        option={{ 
          // color: this.state.chartData.clist,
          color: ['#3344db','#708090'],
          tooltip: {
          },
          title: {
            text: 'Score (Manufacturing Site Assessment)',
            left: 'center',
            textStyle: {
              fontSize: 12
            },
          },

          legend: {
            top: 150,
            data: ['Threshold', 'Actual']
            // data:this.state.chartData.xaxisarr,
          },
          xAxis: {
            data: [''],
            type: 'category',
            nameLocation: "end",
            nameTextStyle: {
              fontWeight: "bold",
              fontSize: 16,
              align: "center",
            }

          },
          yAxis: {
            scale: true,
            show: false,
            type: 'value', 
            min: 0,                    
          },

          series: [
            {
              name: 'Threshold',
              type: 'bar',
              data: this.state.chartData.xaxisarr,
              label: {
                show: true,
                position: 'inside',
                fontWeight: "bold",
                fontSize: 12,
              },
            },
            {
              name: 'Actual',
              type: 'bar',
              data: this.state.chartData.yaxisarr,
              label: {
                show: true,
                position: 'inside',
                fontWeight: "bold",
                fontSize: 12,
              },
            },
          ]

        }}
      />
    );
  }
}
export default Chart;

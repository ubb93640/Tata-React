import React, { Component } from 'react';
import ReactEcharts from 'echarts-for-react';  
import { encode } from "base-64";


class Chart1 extends Component {
  constructor(props){ 
    super(props);
    this.state = {
      chartData:{  
      } 
    }
    
  }
  componentDidMount() { 
    this.getData(); 
  }
 getData(){
  var i = [];
    let username = 'A71720K01';
    let password = 'pass@123';
    let headerss = new Headers();
    const proxyurl = "https://vendor360qa.tatamotors.com";
    const url = "/api/newppmapi1";
    headerss.append('Authorization', 'Basic ' + encode(username + ":" + password));
    headerss.append('Content-Type', 'application/json');
    fetch(proxyurl + url, { headers: headerss }).then((resp) => resp.json())
      .then((response) => { 
        var xaxisarr = [];
        var yaxisarr = [];
        var apidata = Object.values(response);
        for (i = 0; i < apidata.length; i++) { 
          xaxisarr.push(apidata[i]['date']);
          yaxisarr.push(apidata[i]['worstM']);
        }
        this.setState({
          chartData: {
            xaxisarr:xaxisarr,
            yaxisarr:yaxisarr,
          }
        });
        // console.log("data" ,this.state.chartData)
      })
      .catch((error) => {
        console.log(error);
      });
}

  render() {
    return (
      
      <ReactEcharts style={{
        width: "100%",
        height: "200px",
      }}
      
        option={{ 
          color: ['#3344db'],
          tooltip: {

          trigger: "axis"
      },
      title: {
          text: 'PPM Trend (6MMA)',
          left: 'center',
          textStyle: {
            fontSize: 15
          },
      },

      grid: {
          left: "3%",
          right: "3%"
        },
      xAxis: {
          data: this.state.chartData.xaxisarr,
          // data: ['Sep2021', 'Oct2021', 'Nov2021', 'Dec2021', 'Jan2022', 'Feb2022'],
          
          type: 'category', 
          axisLabel: {
          show: true,
          textStyle: {
              fontSize: 10
          }
      }
      },
     yAxis: {
          scale: true,
          show: false,
          type: 'value',
          min: 0,
      }, 
      series: [{
        name: 'PPM Trend (6MMA)',
          type: 'bar',
          data: this.state.chartData.yaxisarr,
          // data: [43, 57, 66, 77, 105, 124],
          label: {
          show: true,
          position: 'inside',
          fontWeight: "bold",
          fontSize:12,
      },


      },

  
    ]
        }}
      />
    );
  }
}
export default Chart1;
 
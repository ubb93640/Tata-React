import React, { Component } from 'react';
import ReactEcharts from 'echarts-for-react';  
import { encode } from "base-64";
import { DataSet, PeekdataApi, ReportFilterOperationType, ReportSortDirectionType, IReportRequest } from 'peekdata-datagateway-api-sdk';

class Charte extends Component {
  constructor(props){ 
    super(props);
    this.state = {
      // isLoading: false,
      // error: null, 
      chartData:{  
      } 
    }
    
  }
  componentDidMount() {  
    this.getData();
      }
      getData(){
        var i = [];
          let username = 'A71720K01';
          let password = 'pass@123';
          let headerss = new Headers();
          const proxyurl = "https://vendor360qa.tatamotors.com";
          const url = "/api/sales";
          headerss.append('Authorization', 'Basic ' + encode(username + ":" + password));
          headerss.append('Content-Type', 'application/json');
          fetch(proxyurl + url, { headers: headerss }).then((resp) => resp.json())
            .then((response) => { 
              var xaxisarr = [];
              var yaxisarr = [];
              var apidata = Object.values(response);
              for (i = 0; i < apidata.length; i++) { 
                xaxisarr.push(apidata[i]['year']);
                yaxisarr.push(apidata[i]['sale']);
              }
              this.setState({
                chartData: {
                  xaxisarr:xaxisarr,
                  yaxisarr:yaxisarr,
                }
              });
              // console.log("data" ,this.state.chartData.yaxisarr)
            })
            .catch((error) => {
              console.log(error);
            });
      }
  render() {   
    return (
      <ReactEcharts style={{
        width: "100%",
        height: "200px",
      }}
        option={{ 
          color: ['#3344db'],          
          tooltip: {
                  trigger: "axis"
                   },
          title: {
              text: 'Annual Sales Trend (Crs)',
              left: 'center',
              textStyle: {
                fontSize: 15
              },
          },
                        
          grid: {
              left: "3%",
              right: "3%"
            },
          xAxis: { 
            data:this.state.chartData.xaxisarr,
            type: 'category', 
            nameLocation: "end", 
            axisLabel: {
            show: true,
            textStyle: {
                fontSize: 10,
                align:'center',   
            }} 
        },
          yAxis: {
            scale: true,
            show: false,
            type: 'log',  
        },
          series: [{ 
            name: 'Annual Sales Trend (Crs)', 
            data: this.state.chartData.yaxisarr,
            type: 'bar',
            label: {
              show: true,
              position: 'inside',
      fontWeight: "bold",
              fontSize:12,
          },

          }]
           
        }}
      />
    );
  }
}
export default Charte;
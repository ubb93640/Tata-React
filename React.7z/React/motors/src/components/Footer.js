import React from "react";
import '../App.css';
function Footer() { 
    return (
        <footer className="footerSrt text-lg-start"> 
        <div className="text-center">
        Copyright 2022 <a href="https://tatamotors.com/"> Tata Motors</a> All right reseaved.
        </div> 
      </footer>
 
  )
  }

export default Footer;
import React from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';
import logo from '../../assets/images/tata_motors_logo.png';
import Imps from '../../assets/images/imps.png';
import styles from './Header.module.css';
import config from '../../config/config';
import { ENV_TYPES } from '../../constants';

const Header = ({ title = null, ...props }) => {
  const renderTestWaterMark = () => (
    <span className={styles.testTitle}>
      <strong>TEST ENVIRONMENT</strong>
      Changes made here will not impact/influence actual Production
    </span>
  );
  return (
    <div className={styles.header} {...props}>
      <img className={styles.logo} src={logo} alt="Tata Motors" />
      {config.ENV_TYPE === ENV_TYPES.TEST && renderTestWaterMark()}
      <div className={styles.title}>
        <span className={styles.titlePlan}>{title}</span>
        <Link to="/" className={styles.homeLink}>
          <span className={styles.titleMid}>
            <img src={Imps} className={styles.impsLogo} alt="IMPS 4.0" />
            Production Broadcast
          </span>
        </Link>
      </div>
    </div>
  );
};

Header.propTypes = {
  title: PropTypes.string,
};

export default Header;

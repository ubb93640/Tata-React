import React, { Component } from 'react';
import ReactEcharts from 'echarts-for-react';  
import { encode } from "base-64"; 
class NewChart extends Component {
  constructor(props) { 
    super(props);
    this.state = {
      chartData: { 
      }, 
    }

  }

  componentDidMount() { 
    this.getData(); 
  }
 getData(){
  var i = [];
    let username = 'A71720K01';
    let password = 'pass@123';
    let headerss = new Headers();
    const proxyurl = "https://vendor360qa.tatamotors.com";
    const url = "/api/newppmapi";
    headerss.append('Authorization', 'Basic ' + encode(username + ":" + password));
    headerss.append('Content-Type', 'application/json');
    fetch(proxyurl + url, { headers: headerss }).then((resp) => resp.json())
      .then((response) => { 
        var xaxisarr1 = [];
        var yaxisarr = [];
        var zaxisarr = [];
        var gaxisarr= [];
        var paxisarr = [];
        var apidata = Object.values(response);
        for (i = 0; i < apidata.length; i++) { 
          xaxisarr1.push(apidata[i]['date']);
          yaxisarr.push(apidata[i]['worstM']);
          zaxisarr.push(apidata[i]['plant']);
          gaxisarr.push(apidata[i]['total']);
          paxisarr.push(apidata[i]['date1']); 

        }
        this.setState({
          chartData: {
            xaxisarr1:xaxisarr1,
            yaxisarr:yaxisarr,
            zaxisarr:zaxisarr,
            gaxisarr:gaxisarr,
            paxisarr:paxisarr, 
          }
        });
        console.log("CAse" ,this.state.chartData.xaxisarr1)
      })
      .catch((error) => {
        console.log(error);
      });
}

     
  render() {
    return (
      
      <ReactEcharts style={{
        width: "100%",
        height: "200px",
      }}
      
        option={{   
          color: ['#3344db','#708090'],
          tooltip: { 
          trigger: "axis",
          formatter: (params) => {
            return `Highest PPM @ ${params[1].data.name1} Plant: ${params[1].data.value1}  `;
      },},
      title:{
        text: 'PPM (Absolute & Trend)', 
        left: 'center',
        textStyle: {
          fontSize: 15,
          fontcolor:'#000000',
        },
      },

      legend: { 
       top:40, 
        data: ['Monthly Absolute PPM', 'Highest PPM & Corresponding Plant']
      }, 
      grid: {
          left: "3%",
          right: "3%"
        },
       xAxis: [{
          position: "bottom",
          data: this.state.chartData.xaxisarr1,
          // data: ["FY Cum",],
          // data: ["FY Cum", "Sep2021","Oct2021","Nov2021","Dec2021","Jan2022", "Feb2022"],
          axisLabel: {
          show: true,
          textStyle: {
              fontSize: 10,
              align:'center',   
          }}
        },
        ], 
      yAxis: {
          scale: true,
          show: false,
          type: 'log', 
      },
      
      series: [
      {
        name: 'Monthly Absolute PPM',
          type: 'bar',
          barGap:0, 
          data:[{
          // value: this.state.chartData,
          value: 84,
          itemStyle: {color: '#7030a0'},
          },{
          // value: gaxisarr[1],
          value: 115,
          itemStyle: {color: '#3344db'},
          },
          {
          // value: gaxisarr[2],
          value: 94,
          itemStyle: {color: '#3344db'},
          },{
          // value: gaxisarr[3],
          value: 76.3,
          itemStyle: {color: '#3344db'},
          },
          {
          // value: gaxisarr[4],
          value: 113.3,
          itemStyle: {color: '#3344db'},
          },{
          // value: gaxisarr[5],
          value: 193.37,
          itemStyle: {color: '#3344db'},
          },
          {
          // value: gaxisarr[6],
          value: 135.1,
          itemStyle: {color: '#3344db'},
          }
          ],
          label: {
          show: true, 
          align: 'center', 
          position: 'inside', 
          fontSize:10,
      },


      },
      {
          
        name: 'Highest PPM & Corresponding Plant',
          type: 'bar', 
          data:[{
          // value: yaxisarr[0],
          value:3970,
          // value1:yaxisarr[0],
          value1:3970, 
          // name1:paxisarr[0], 
          name1:"JSR", 
          },{
          // value: yaxisarr[1],
          value:1204.7,
          // value1:yaxisarr[1],
          value1:1204.7,
          // name1:paxisarr[1],
          name1:"CV Pune",
          
          
          },
          {
          // value: yaxisarr[2],
          // value1:yaxisarr[2],
          // name1:paxisarr[2],
          value:729.1,
          value1:729.1,
          name1:"Sanand",
          },{
          // value: yaxisarr[3],
          // value1:yaxisarr[3],
          // name1:paxisarr[3],
          value:390.1,
          value1:390.1,
          name1:"CV Pune",
          
          },
          {
          // value: yaxisarr[4],
          // value1:yaxisarr[4],
          // name1:paxisarr[4],
          value:18367.3,
          value1:18367.3,
          name1:"JSR",
          
          },
          {
          // value: yaxisarr[5],
          // value1:yaxisarr[5],
          // name1:paxisarr[5],
          value:1869.3,
          value1:1869.3,
          name1:"CV Pune",
          
          },
          {
          // value: yaxisarr[6],
          // value1:yaxisarr[6],
          // name1:paxisarr[6],
          value:7334.9,
          value1:7334.9,
          name1:"JSR",
          
          }
          ],
          label: {
          show: true, 
          align: 'center', 
          position: 'inside', 
          fontSize:10,
      },


      },
    ]
           
        }}
      />
    );
  }
}
export default NewChart;
 
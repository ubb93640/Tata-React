export { default as AuthorizationHandler } from './AuthorizationHandler/AuthorizationHandler';
export { default as PopupManager } from './PopupManager/PopupManager';

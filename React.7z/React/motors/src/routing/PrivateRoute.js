import React from 'react';
import PropTypes from 'prop-types';
import { Route } from 'react-router-dom';
import { connect } from 'react-redux';
import { GridLoadingSpinner } from '../components';

const PrivateRoute = ({
  component: Component,
  componentProps,
  isAuthenticated,
  user,
  ...rest
}) => (
  <Route
    {...rest}
    render={() =>
      isAuthenticated && user?.isLoaded ? (
        <Component {...componentProps} />
      ) : (
        <div
          style={{
            margin: '40vh auto',
            height: '20vh',
            width: '20vh',
            textAlign: 'center',
          }}
        >
          <GridLoadingSpinner />
        </div>
      )
    }
  />
);

PrivateRoute.propTypes = {
  component: PropTypes.any.isRequired,
  componentProps: PropTypes.object,
  isAuthenticated: PropTypes.bool.isRequired,
  user: PropTypes.object,
};

PrivateRoute.defaultProps = {
  componentProps: {},
};

export default connect(({ auth }) => ({
  isAuthenticated: auth.isAuthenticated,
  user: auth.user,
}))(PrivateRoute);

// eslint-disable-next-line import/prefer-default-export
export const logoutAndClearData = keycloak =>
  keycloak.logout().then(() => {
    window.keycloak = null;
    window.location.href = '/';
  });

import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { BUYER_OPERATIONS, PERSONAS, VENDOR_OPERATIONS } from '../../constants';

const AuthChecker = ({ operation, children, currentUserPersona }) => {
  const allowedOperations = [];

  // TODO: remove static checks
  if (
    currentUserPersona === PERSONAS.VENDOR ||
    currentUserPersona === PERSONAS.FBV_VENDOR
  ) {
    allowedOperations.push(
      VENDOR_OPERATIONS.DROP_MATERIAL,
      VENDOR_OPERATIONS.DISPATCH_MATERIAL,
    );
  }

  if (currentUserPersona === PERSONAS.BUYER) {
    allowedOperations.push(BUYER_OPERATIONS.DISPATCH_MATERIAL);
  }

  const isAuthorized = allowedOperations.includes(operation);

  return children(isAuthorized);
};

AuthChecker.propTypes = {
  children: PropTypes.func.isRequired,
  operation: PropTypes.string,
  currentUserPersona: PropTypes.string,
};

export default connect(({ userProfile }) => ({
  currentUserPersona: userProfile.persona,
}))(AuthChecker);

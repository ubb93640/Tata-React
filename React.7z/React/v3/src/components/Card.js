import React from "react";
// import '../App.css';
// import MyChart from "./Mychart";
import Charte from './Charte'
import Chart from './Chart'
import Chart2 from './Chart2'
import Chart1 from './Chart1'
import NewChart from "./NewChart";

function Card() {
  return (
    <div>
      <div className="row mt-5">
        <div className="col-3">
          <div className="card">
            <div className="card-body">
              <Charte />
            </div>
          </div>
          <p className="datr2"> <span className="required">*</span>Sales data for Current Fiscal year is from Apr till previous month</p>
        </div>
        <div className="col-3">
          <div className="card">
            <div className="card-body">
              <Chart />
              {/* <MyChart /> */}
            </div>
          </div>
        </div>

        <div className="col-6">
          <div className="card">
            <div className="card-body">
              <NewChart />
            </div>
          </div>
          <p className="datr"> <span className="required">*</span>Purple bar indicates FY Cumulative PPM</p>
        </div>

      </div>
      <div className="row mt-2">
        <div className="col-6">
          <div className="card">
            <div className="card-body">
              <Chart2 />
            </div>
          </div>
          <p className="datr"> <span className="required">*</span>PRR data is for all PRR Types and Open data is for cumulative last 6 months</p>
          {/* <p className="sdate">Last Refresh : 14 Mar 2022</p> */}
        </div>
        <div className="col-6">
          <div className="card">
            <div className="card-body">
              <Chart1 />
            </div>
          </div>
          <p className="datr"> <span className="required">*</span>PPM data for 6 months moving average is of all plants</p>
          {/* <p className="sdate right">Corporate IT Tata Motors Limited</p> */}

        </div>
      </div>
    </div>
  )
}

export default Card;
import React from 'react';
import ReactEcharts from 'echarts-for-react';
// import { encode } from "base-64";

function Chart() {
  // constructor(props) {
  //   super(props);
  //   this.state = {
  //     // chartData: {
  //     // },
  //   }
  // }

  // componentDidMount = () => {
  //   this.getData();
  // }

  // getData = () => {
  //   let i = [];
  //   const username = 'A71720K01';
  //   const password = 'pass@123';
  //   const headerss = new Headers();
  //   const proxyurl = "https://vendor360qa.tatamotors.com";
  //   const url = "/api/msa";
  //   headerss.append('Authorization', 'Basic', encode(`${username}:${password}`));
  //   headerss.append('Content-Type', 'application/json');
  //   fetch(proxyurl + url, { headers: headerss }).then((resp) => resp.json())
  //     .then((response) => {

  //       const xaxisarr = [];
  //       const yaxisarr = [];
  //       // let clist = [];
  //       const apidata = Object.values(response);
  //       // console.log("data", apidata)
  //       for (i = 0; i < apidata.length; i += 1) {
  //         xaxisarr.push(apidata[i].actual);
  //         yaxisarr.push(apidata[i].threshold);
  //       }
  //       // if (xaxisarr >= 70) {
  //       //   clist = ['#3344db', '#A20000']
  //       // } else {
  //       //   clist = ['#3344db', '#708090']
  //       // }
  //       this.setState({
  //         // chartData: {
  //         //   xaxisarr1: xaxisarr,
  //         //   yaxisarr1: yaxisarr,
  //         //   clist1: clist,
  //         // }
  //       });

  //     })
  //     .catch((error) => {
  //       console.log(error);
  //     });
  // }

  // render() {
  // const { chartData } = this.state
  // console.log(chartData);
  return (
    <ReactEcharts style={{
      width: "100%",
      height: "200px",
    }}
      option={{
        // color: this.state.chartData.clist,
        color: ['#3344db', '#A20000'],
        tooltip: {
        },
        title: {
          text: 'Score (Manufacturing Site Assessment)',
          left: 'center',
          textStyle: {
            fontSize: 12
          },
        },

        legend: {
          top: 150,
          data: ['Threshold', 'Actual']
          // data:this.state.chartData.xaxisarr,
        },
        xAxis: {
          data: [''],
          type: 'category',
          nameLocation: "end",
          nameTextStyle: {
            fontWeight: "bold",
            fontSize: 16,
            align: "center",
          }

        },
        yAxis: {
          scale: true,
          show: false,
          type: 'value',
          min: 0,
        },

        series: [
          {
            name: 'Threshold',
            type: 'bar',
            // data: chartData.xaxisarr1,
            data: [70],
            label: {
              show: true,
              position: 'inside',
              fontWeight: "bold",
              fontSize: 12,
            },
          },
          {
            name: 'Actual',
            type: 'bar',
            // data: chartData.yaxisarr1,
            data: [49],
            label: {
              show: true,
              position: 'inside',
              fontWeight: "bold",
              fontSize: 12,
            },
          },
        ]

      }
      }
    />
  );
}

export default Chart;

import React from 'react';
import ReactEcharts from 'echarts-for-react';
// import { encode } from "base-64";

function Charte() {
  // constructor(props) {
  //   super(props);
  //   this.state = {
  //     // isLoading: false,
  //     // error: null, 
  //     // chartData: {
  //     // }
  //   }

  // }

  // componentDidMount() {
  //   // this.getDataS();
  // }

  // getDataS() {
  //   let i = [];
  //   const username = 'A71720K01';
  //   const password = 'pass@123';
  //   const headerss = new Headers();
  //   const proxyurl = "https://vendor360qa.tatamotors.com";
  //   const url = "/api/sales";
  //   headerss.append('Authorization', 'Basic ', encode(`${username}:${password}`));
  //   headerss.append('Content-Type', 'application/json');
  //   fetch(proxyurl + url, { headers: headerss }).then((resp) => resp.json())
  //     .then((response) => {
  //       const xaxisarr = [];
  //       const yaxisarr = [];
  //       const apidata = Object.values(response);
  //       for (i = 0; i < apidata.length; i += 1) {
  //         xaxisarr.push(apidata[i].year);
  //         yaxisarr.push(apidata[i].sale);
  //       }
  //       // this.setState({
  //       //   // chartData: {
  //       //   //   xaxisarr1: xaxisarr,
  //       //   //   yaxisarr1: yaxisarr,
  //       //   // }
  //       // });
  //       // console.log("data" ,this.state.chartData.yaxisarr)
  //     })
  //     .catch((error) => {
  //       console.log(error);
  //     });
  // }

  // render() {
  return (
    <ReactEcharts style={{
      width: "100%",
      height: "200px",
    }}
      option={{
        color: ['#3344db'],
        tooltip: {
          trigger: "axis"
        },
        title: {
          text: 'Annual Sales Trend (Crs)',
          left: 'center',
          textStyle: {
            fontSize: 15
          },
        },

        grid: {
          left: "3%",
          right: "3%"
        },
        xAxis: {
          // data: this.state.chartData.xaxisarr,
          data: ["2018-19", "2019-20", "2020-21", "2021-22"],
          type: 'category',
          nameLocation: "end",
          axisLabel: {
            show: true,
            textStyle: {
              fontSize: 10,
              align: 'center',
            }
          }
        },
        yAxis: {
          scale: true,
          show: false,
          type: 'log',
        },
        series: [{
          name: 'Annual Sales Trend (Crs)',
          // data: this.state.chartData.yaxisarr,
          data: [92, 85, 84, 193],
          type: 'bar',
          label: {
            show: true,
            position: 'inside',
            fontWeight: "bold",
            fontSize: 12,
          },

        }]

      }}
    />
  );
}
// }
export default Charte;
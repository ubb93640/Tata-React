import React, { Component } from "react";
// import { Charts as ChartJS } from 'chart.js/auto'
// import { Charts, Bar, Line, Pie } from 'react-chartjs-2'


export default class MyChart extends Component {
    constructor() {
        super();
        this.state = { email: " " };

    }
    // change(e) {
    //     if ("" != e.target.value) {
    //         this.button.disabled = false;
    //     } else {
    //         this.button.disabled = true;
    //     }
    // }

    // add() {
    //     console.log(this.input.value);
    //     this.input.value = '';
    //     this.button.disabled = true;
    // }
    getInitialState() {
        return { email: '' }
    }

    handleChange(e) {
        this.setState({ email: e.target.value })
    }

    render() {
        const { email } = this.state;

        return (
            <div>
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-md-12">


                            {/* <input name="email" value={this.state.email} onChange={this.handleChange} /> */}
                            {/* <button type="button" disabled={!this.state.email}>Button</button> */}
                            <h3 className="card-header text-center text-light mx-2 my-4 font-weight-bold rounded py-2 contacthead"
                            >Contact Profile for Automotive Stampings And Assemblies</h3>
                            {/* style="font-family: uni_neueregular;border-radius: 10px;" */}
                            {/* <h3 className="card-header text-center text-light mx-2 my-4 font-weight-bold  py-2 contacthead"
        style="font-family: uni_neueregular;border-radius: 10px;">Contact Profile for {{companyprofile.0.0|title}}</h3>
      */}
                        </div>
                    </div>
                    {/* <div className="row mb-4 ml-2">
                    <div className="col-md-2">
                        Select Vendor
                    </div>
                    <div className="col-md-3">
                        <form method="POST">
                            <select name="grpvendor" id="grpvendor" className="form-control"  >
                                <option value="0">Select Vendor</option>
                                <option value="{{each}}">cccc</option>
                            </select>
                        </form>

                    </div>
                </div> */}
                    <div className="row">
                        <div className="col-md-12">
                            <div id="table" className="table-editable">
                                <table className="table table-striped table-bordered rounded table-hover contactstable">
                                    <thead className="thead-dark">
                                        <tr className="tableheader">
                                            <th className="text-center stickyheader">Designation</th>
                                            <th className="text-center stickyheader">First Name</th>
                                            <th className="text-center stickyheader">Last Name</th>
                                            <th className="text-center stickyheader">Phone Number</th>
                                            <th className="text-center stickyheader">Email ID</th>
                                            <th className="text-center stickyheader">Action</th>
                                            <th className="text-center stickyheader">Last Updated On</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr className="tbrownum{{forloop.counter}}">
                                            {/* style="font-size: 18px" */}
                                            <td className="pt-3-half text-light bg-secondary font-weight-bold" >Chairman </td>
                                            <td className="pt-3-half" contentEditable="true" > Managing Director </td>
                                            {/* <td className="pt-3-half" id="one{{forloop.counter}}"  >Managing Director</td> */}
                                            {/* <td className="pt-3-half" id="two{{forloop.counter}}"  >Managing Director</td> */}
                                            {/* <td className="pt-3-half" id="three{{forloop.counter}}"  >Managing Director</td> */}

                                            <td className="pt-3-half" contentEditable="true" >
                                                Managing Director
                                                {/* <span className="table-remove"><button type="button" className="btn btn-danger btn-rounded btn-sm my-0"
                                                id="updatebtn{{forloop.counter}}" onclick="addcontactdata({{forloop.counter}})" disabled><i
                                                    className="fa fa-pencil-square-o" aria-hidden="true"></i> Create</button></span> */}
                                            </td>
                                            <td className="pt-3-half" contentEditable="true"  >
                                                Managing Director
                                                {/* <span className="table-remove"><button type="button" className="btn btn-danger btn-rounded btn-sm my-0"
                                                id="updatebtn{{forloop.counter}}" onclick="mybtn({{forloop.counter}})" disabled><i
                                                    className="fa fa-pencil-square-o" aria-hidden="true"></i> Update</button></span> */}
                                            </td>

                                            <td className="pt-3-half" contentEditable="true" >
                                                Managing Director
                                                {/* <span className="table-remove"><button type="button" className="btn btn-success btn-rounded btn-sm my-0"
                                                disabled id="updatebtn{{forloop.counter}}" onclick="mybtn({{forloop.counter}})"><i
                                                    className="fa fa-pencil-square-o" aria-hidden="true"></i> Update</button></span> */}
                                            </td>
                                            <td className="pt-3-half text-success" id="updatedate{{forloop.counter}}"   >
                                                <button type="button" className="btn btn-success btn-rounded btn-sm my-0" disabled id="updatebtn1"  >  Update</button>
                                            </td>

                                            <td className="pt-3-half text-success" id="updatedate{{forloop.counter}}"   >  07-04-2022</td>
                                        </tr>
                                        <tr className="tbrownum{{forloop.counter}}">
                                            {/* style="font-size: 18px" */}
                                            <td className="pt-3-half text-light bg-secondary font-weight-bold" >Managing Director</td>
                                            <td className="pt-3-half" id="one{{forloop.counter}}" contentEditable="true"  > </td>
                                            {/* <td className="pt-3-half" id="one{{forloop.counter}}"  >Managing Director</td> */}
                                            {/* <td className="pt-3-half" id="two{{forloop.counter}}"  >Managing Director</td> */}
                                            {/* <td className="pt-3-half" id="three{{forloop.counter}}"  >Managing Director</td> */}

                                            <td className="pt-3-half" contentEditable="true">
                                                {/* <span className="table-remove"><button type="button" className="btn btn-danger btn-rounded btn-sm my-0"
                                                id="updatebtn{{forloop.counter}}" onclick="addcontactdata({{forloop.counter}})" disabled><i
                                                    className="fa fa-pencil-square-o" aria-hidden="true"></i> Create</button></span> */}
                                            </td>
                                            <td className="pt-3-half" contentEditable="true" >
                                                {/* <span className="table-remove"><button type="button" className="btn btn-danger btn-rounded btn-sm my-0"
                                                id="updatebtn{{forloop.counter}}" onclick="mybtn({{forloop.counter}})" disabled><i
                                                    className="fa fa-pencil-square-o" aria-hidden="true"></i> Update</button></span> */}
                                            </td>

                                            <td className="pt-3-half" contentEditable="true">
                                                {/* <input className="table-remove" /> */}
                                                {/* <span className="table-remove"><button type="button" className="btn btn-success btn-rounded btn-sm my-0"
                                                disabled id="updatebtn{{forloop.counter}}" onclick="mybtn({{forloop.counter}})"><i
                                                    className="fa fa-pencil-square-o" aria-hidden="true"></i> Update</button></span> */}
                                            </td>
                                            <td className="pt-3-half text-success" id="updatedate{{forloop.counter}}">
                                                <button type="button" disabled
                                                    className="btn btn-danger btn-rounded btn-sm my-0" id="updatebtn1"  >  Update</button>

                                            </td>

                                            <td className="pt-3-half text-danger" id="updatedate{{forloop.counter}}">-
                                            </td>
                                        </tr>
                                        <tr className="tbrownum{{forloop.counter}}">
                                            {/* style="font-size: 18px" */}
                                            <td className="pt-3-half text-light bg-secondary font-weight-bold" >CEO</td>
                                            <td className="pt-3-half" id="one{{forloop.counter}}" contentEditable="true" > </td>
                                            {/* <td className="pt-3-half" id="one{{forloop.counter}}"  >Managing Director</td> */}
                                            {/* <td className="pt-3-half" id="two{{forloop.counter}}"  >Managing Director</td> */}
                                            {/* <td className="pt-3-half" id="three{{forloop.counter}}"  >Managing Director</td> */}

                                            <td className="pt-3-half" contentEditable="true">

                                                {/* <span className="table-remove"><button type="button" className="btn btn-danger btn-rounded btn-sm my-0"
                                                id="updatebtn{{forloop.counter}}" onclick="addcontactdata({{forloop.counter}})" disabled><i
                                                    className="fa fa-pencil-square-o" aria-hidden="true"></i> Create</button></span> */}
                                            </td>
                                            <td className="pt-3-half" contentEditable="true">

                                                {/* <span className="table-remove"><button type="button" className="btn btn-danger btn-rounded btn-sm my-0"
                                                id="updatebtn{{forloop.counter}}" onclick="mybtn({{forloop.counter}})" disabled><i
                                                    className="fa fa-pencil-square-o" aria-hidden="true"></i> Update</button></span> */}
                                            </td>

                                            <td className="pt-3-half" contentEditable="true">

                                                {/* <span className="table-remove"><button type="button" className="btn btn-success btn-rounded btn-sm my-0"
                                                disabled id="updatebtn{{forloop.counter}}" onclick="mybtn({{forloop.counter}})"><i
                                                    className="fa fa-pencil-square-o" aria-hidden="true"></i> Update</button></span> */}
                                            </td>
                                            <td className="pt-3-half text-success" id="updatedate{{forloop.counter}}">
                                                <button type="button" className="btn btn-danger btn-rounded btn-sm my-0" disabled id="updatebtn1"  >  Update</button>

                                            </td>

                                            <td className="pt-3-half text-success" id="updatedate{{forloop.counter}}">-
                                            </td>
                                        </tr>
                                        <tr className="tbrownum{{forloop.counter}}">
                                            {/* style="font-size: 18px" */}
                                            <td className="pt-3-half text-light bg-secondary font-weight-bold" >CFO</td>
                                            <td className="pt-3-half" id="one{{forloop.counter}}" contentEditable="true"> </td>
                                            {/* <td className="pt-3-half" id="one{{forloop.counter}}"  >Managing Director</td> */}
                                            {/* <td className="pt-3-half" id="two{{forloop.counter}}"  >Managing Director</td> */}
                                            {/* <td className="pt-3-half" id="three{{forloop.counter}}"  >Managing Director</td> */}

                                            <td className="pt-3-half" contentEditable="true">

                                                {/* <span className="table-remove"><button type="button" className="btn btn-danger btn-rounded btn-sm my-0"
                                                id="updatebtn{{forloop.counter}}" onclick="addcontactdata({{forloop.counter}})" disabled><i
                                                    className="fa fa-pencil-square-o" aria-hidden="true"></i> Create</button></span> */}
                                            </td>
                                            <td className="pt-3-half" contentEditable="true" >
                                                {/* <span className="table-remove"><button type="button" className="btn btn-danger btn-rounded btn-sm my-0"
                                                id="updatebtn{{forloop.counter}}" onclick="mybtn({{forloop.counter}})" disabled><i
                                                    className="fa fa-pencil-square-o" aria-hidden="true"></i> Update</button></span> */}
                                            </td>

                                            <td className="pt-3-half" contentEditable="true">
                                                {/* <span className="table-remove"><button type="button" className="btn btn-success btn-rounded btn-sm my-0"
                                                disabled id="updatebtn{{forloop.counter}}" onclick="mybtn({{forloop.counter}})"><i
                                                    className="fa fa-pencil-square-o" aria-hidden="true"></i> Update</button></span> */}
                                            </td>
                                            <td className="pt-3-half text-success" id="updatedate{{forloop.counter}}">.
                                                <button type="button" className="btn btn-danger btn-rounded btn-sm my-0" disabled id="updatebtn1"  >  Update</button>
                                            </td>

                                            <td className="pt-3-half text-danger" id="updatedate{{forloop.counter}}">.
                                            </td>
                                        </tr>
                                        <tr className="tbrownum{{forloop.counter}}">
                                            {/* style="font-size: 18px" */}
                                            <td className="pt-3-half text-light bg-secondary font-weight-bold" >Plant Head</td>
                                            <td className="pt-3-half" id="one{{forloop.counter}}" contentEditable="true"> </td>
                                            {/* <td className="pt-3-half" id="one{{forloop.counter}}"  >Managing Director</td> */}
                                            {/* <td className="pt-3-half" id="two{{forloop.counter}}"  >Managing Director</td> */}
                                            {/* <td className="pt-3-half" id="three{{forloop.counter}}"  >Managing Director</td> */}

                                            <td className="pt-3-half" contentEditable="true" >
                                                {/* <span className="table-remove"><button type="button" className="btn btn-danger btn-rounded btn-sm my-0"
                                                id="updatebtn{{forloop.counter}}" onclick="addcontactdata({{forloop.counter}})" disabled><i
                                                    className="fa fa-pencil-square-o" aria-hidden="true"></i> Create</button></span> */}
                                            </td>
                                            <td className="pt-3-half" contentEditable="true" >

                                                {/* <span className="table-remove"><button type="button" className="btn btn-danger btn-rounded btn-sm my-0"
                                                id="updatebtn{{forloop.counter}}" onclick="mybtn({{forloop.counter}})" disabled><i
                                                    className="fa fa-pencil-square-o" aria-hidden="true"></i> Update</button></span> */}
                                            </td>

                                            <td className="pt-3-half" contentEditable="true" >

                                                {/* <span className="table-remove"><button type="button" className="btn btn-success btn-rounded btn-sm my-0"
                                                disabled id="updatebtn{{forloop.counter}}" onclick="mybtn({{forloop.counter}})"><i
                                                    className="fa fa-pencil-square-o" aria-hidden="true"></i> Update</button></span> */}
                                            </td>
                                            <td className="pt-3-half text-success" id="updatedate{{forloop.counter}}">.
                                                <button type="button" className="btn btn-danger btn-rounded btn-sm my-0" disabled id="updatebtn1"  >  Update</button>

                                            </td>

                                            <td className="pt-3-half text-danger" id="updatedate{{forloop.counter}}">.
                                            </td>
                                        </tr>
                                        <tr className="tbrownum{{forloop.counter}}">
                                            {/* style="font-size: 18px" */}
                                            <td className="pt-3-half text-light bg-secondary font-weight-bold" >Quality Head</td>
                                            <td className="pt-3-half" id="one{{forloop.counter}}" contentEditable="true" > </td>
                                            {/* <td className="pt-3-half" id="one{{forloop.counter}}"  >Managing Director</td> */}
                                            {/* <td className="pt-3-half" id="two{{forloop.counter}}"  >Managing Director</td> */}
                                            {/* <td className="pt-3-half" id="three{{forloop.counter}}"  >Managing Director</td> */}

                                            <td className="pt-3-half" contentEditable="true" >

                                                {/* <span className="table-remove"><button type="button" className="btn btn-danger btn-rounded btn-sm my-0"
                                                id="updatebtn{{forloop.counter}}" onclick="addcontactdata({{forloop.counter}})" disabled><i
                                                    className="fa fa-pencil-square-o" aria-hidden="true"></i> Create</button></span> */}
                                            </td>
                                            <td className="pt-3-half" contentEditable="true" >

                                                {/* <span className="table-remove"><button type="button" className="btn btn-danger btn-rounded btn-sm my-0"
                                                id="updatebtn{{forloop.counter}}" onclick="mybtn({{forloop.counter}})" disabled><i
                                                    className="fa fa-pencil-square-o" aria-hidden="true"></i> Update</button></span> */}
                                            </td>

                                            <td className="pt-3-half" contentEditable="true">

                                                {/* <span className="table-remove"><button type="button" className="btn btn-success btn-rounded btn-sm my-0"
                                                disabled id="updatebtn{{forloop.counter}}" onclick="mybtn({{forloop.counter}})"><i
                                                    className="fa fa-pencil-square-o" aria-hidden="true"></i> Update</button></span> */}
                                            </td>
                                            <td className="pt-3-half text-success" id="updatedate{{forloop.counter}}">
                                                <button type="button" className="btn btn-danger btn-rounded btn-sm my-0" disabled id="updatebtn1"  >  Update</button>

                                            </td>

                                            <td className="pt-3-half text-danger" id="updatedate{{forloop.counter}}">.
                                            </td>
                                        </tr>
                                        <tr className="tbrownum{{forloop.counter}}">
                                            {/* style="font-size: 18px" */}
                                            <td className="pt-3-half text-light bg-secondary font-weight-bold" >Manufacturing Head</td>
                                            <td className="pt-3-half" id="one{{forloop.counter}}" contentEditable="true" > </td>
                                            {/* <td className="pt-3-half" id="one{{forloop.counter}}"  >Managing Director</td> */}
                                            {/* <td className="pt-3-half" id="two{{forloop.counter}}"  >Managing Director</td> */}
                                            {/* <td className="pt-3-half" id="three{{forloop.counter}}"  >Managing Director</td> */}

                                            <td className="pt-3-half" contentEditable="true" >

                                                {/* <span className="table-remove"><button type="button" className="btn btn-danger btn-rounded btn-sm my-0"
                                                id="updatebtn{{forloop.counter}}" onclick="addcontactdata({{forloop.counter}})" disabled><i
                                                    className="fa fa-pencil-square-o" aria-hidden="true"></i> Create</button></span> */}
                                            </td>
                                            <td className="pt-3-half" contentEditable="true">

                                                {/* <span className="table-remove"><button type="button" className="btn btn-danger btn-rounded btn-sm my-0"
                                                id="updatebtn{{forloop.counter}}" onclick="mybtn({{forloop.counter}})" disabled><i
                                                    className="fa fa-pencil-square-o" aria-hidden="true"></i> Update</button></span> */}
                                            </td>

                                            <td className="pt-3-half" contentEditable="true">

                                                {/* <span className="table-remove"><button type="button" className="btn btn-success btn-rounded btn-sm my-0"
                                                disabled id="updatebtn{{forloop.counter}}" onclick="mybtn({{forloop.counter}})"><i
                                                    className="fa fa-pencil-square-o" aria-hidden="true"></i> Update</button></span> */}
                                            </td>
                                            <td className="pt-3-half text-success" id="updatedate{{forloop.counter}}">
                                                <button type="button" className="btn btn-danger btn-rounded btn-sm my-0" disabled id="updatebtn1"  >  Update</button>

                                            </td>

                                            <td className="pt-3-half text-danger" id="updatedate{{forloop.counter}}">.
                                            </td>
                                        </tr>
                                        <tr className="tbrownum{{forloop.counter}}">
                                            {/* style="font-size: 18px" */}
                                            <td className="pt-3-half text-light bg-secondary font-weight-bold" >Key Account Manager</td>
                                            <td className="pt-3-half" id="one{{forloop.counter}}" contentEditable="true"> </td>
                                            {/* <td className="pt-3-half" id="one{{forloop.counter}}"  >Managing Director</td> */}
                                            {/* <td className="pt-3-half" id="two{{forloop.counter}}"  >Managing Director</td> */}
                                            {/* <td className="pt-3-half" id="three{{forloop.counter}}"  >Managing Director</td> */}

                                            <td className="pt-3-half" contentEditable="true" >

                                                {/* <span className="table-remove"><button type="button" className="btn btn-danger btn-rounded btn-sm my-0"
                                                id="updatebtn{{forloop.counter}}" onclick="addcontactdata({{forloop.counter}})" disabled><i
                                                    className="fa fa-pencil-square-o" aria-hidden="true"></i> Create</button></span> */}
                                            </td>
                                            <td className="pt-3-half" contentEditable="true" >

                                                {/* <span className="table-remove"><button type="button" className="btn btn-danger btn-rounded btn-sm my-0"
                                                id="updatebtn{{forloop.counter}}" onclick="mybtn({{forloop.counter}})" disabled><i
                                                    className="fa fa-pencil-square-o" aria-hidden="true"></i> Update</button></span> */}
                                            </td>

                                            <td className="pt-3-half" contentEditable="true">

                                                {/* <span className="table-remove"><button type="button" className="btn btn-success btn-rounded btn-sm my-0"
                                                disabled id="updatebtn{{forloop.counter}}" onclick="mybtn({{forloop.counter}})"><i
                                                    className="fa fa-pencil-square-o" aria-hidden="true"></i> Update</button></span> */}
                                            </td>
                                            <td className="pt-3-half text-success" id="updatedate{{forloop.counter}}">
                                                <button type="button" className="btn btn-danger btn-rounded btn-sm my-0" disabled id="updatebtn1"  >  Update</button>

                                            </td>

                                            <td className="pt-3-half text-danger" id="updatedate{{forloop.counter}}">.
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
// export default MyChart;


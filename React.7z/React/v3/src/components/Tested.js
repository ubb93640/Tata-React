import React, { useState } from "react";
import { Button } from 'react-bootstrap';
import Modal from 'react-bootstrap/Modal';
import '../App.css';

export default function Tested() {
    const arr1 = [{ designation: "Chairman", firstName: "rtrt", lastName: "jhg", phoneNumber: "", emailID: "", action: true, lastUpdated: true },
    { designation: "Managing Director", firstName: "bngjhgh", lastName: "", phoneNumber: "", emailID: "", action: true, lastUpdated: true },
    { designation: "CEO", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: true, lastUpdated: true },
    { designation: "CFO", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: true, lastUpdated: true },
    { designation: "Plant Head", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: true, lastUpdated: true },
    { designation: "Quality Head", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: true, lastUpdated: true },
    { designation: "Quality", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: true, lastUpdated: true },
    { designation: "Head", firstName: "", lastName: "", phoneNumber: "", emailID: "", action: true, lastUpdated: true }]
    const [show, setShow] = useState(false);

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);

    // const [firstname, setName] = useState();
    // const [lastname, setName1] = useState();
    // const [designation, designation2] = useState();
    // const [name2, setName2] = useState();
    // const [name3, setName3] = useState();
    // const [name4, setName4] = useState();
    // const [name5, setName5] = useState();
    // const [name6, setName6] = useState();
    // console.log("ttttttt", lastname);
    // function getUdate(username, password) {
    //     // debugger;
    //     const proxyurl = "https://vendor360qa.tatamotors.com";
    //     const url = "/api/contactapi";
    //     const options = {
    //         // method: '',
    //         headers: new Headers({ username, password }),
    //         mode: 'no-cors'
    //     };

    //     // options.body = JSON.stringify(body);

    //     fetch(proxyurl + url, options)
    //         .then(response => response.json())
    //         .then(data => console.log(data));
    // }
    // function getUdate() {
    //     var i = [];
    //     let username = 'A71720K01';
    //     let password = 'pass@123';
    //     let headerss = new Headers();
    //     const proxyurl = "https://vendor360qa.tatamotors.com";
    //     const url = "/api/contactprofilevendorviewdata";
    //     method: POST;
    //     headerss.append('Authorization', 'Basic ' + encode(username + ":" + password));
    //     headerss.append('Content-Type', 'application/json');
    //     fetch(proxyurl + url, { headers: headerss }).then((resp) => resp.json())
    //         .then((response) => { 
    //             var apidata = Object.values(response);
    //             console.log("xaxisarr", apidata); 
    //         })
    //         .catch((error) => {
    //             console.log(error);
    //         });
    // }
    // useEffect(() => {
    //     getUdate(); 
    // }, []);
    const edited = !arr1.firstName === "tew";
    return (


        // <div>
        //     <input onChange={(e) => setName(e.target.value)} />
        //     <button type="button" disabled={!name}>save</button>
        // </div> 
        <div className="container-fluid">
            <Modal
                show={show}
                onHide={handleClose}
                backdrop="static"
                keyboard={false}
            >
                <Modal.Body style={{ textAlign: "center" }}>
                    <div className="swal-icon swal-icon--success">
                        <span className="swal-icon--success__line swal-icon--success__line--long"> </span>
                        <span className="swal-icon--success__line swal-icon--success__line--tip"> </span>

                        <div className="swal-icon--success__ring"> </div>
                        <div className="swal-icon--success__hide-corners"> </div>
                    </div>
                    <h3>Thank You</h3>
                    <p>Kyc Details Upadted Successfully</p>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="primary" onClick={handleClose}>Ok</Button>
                </Modal.Footer>
            </Modal>
            <div className="row">
                <div className="col-md-12">

                    {/* <input name="email" value={this.state.email} onChange={this.handleChange} /> */}
                    {/* <button type="button" disabled={!this.state.email}>Button</button> */}
                    <h3 className="card-header text-center text-light mx-2 my-4 font-weight-bold rounded py-2 contacthead"
                    >Contact Profile for Automotive Stampings And Assemblies</h3>
                    {/* style="font-family: uni_neueregular;border-radius: 10px;" */}
                    {/* <h3 className="card-header text-center text-light mx-2 my-4 font-weight-bold  py-2 contacthead"
style="font-family: uni_neueregular;border-radius: 10px;">Contact Profile for {{companyprofile.0.0|title}}</h3>
*/}
                </div>
            </div>
            {/* <div className="row mb-4 ml-2">
        <div className="col-md-2">
            Select Vendor
        </div>
        <div className="col-md-3">
            <form method="POST">
                <select name="grpvendor" id="grpvendor" className="form-control"  >
                    <option value="0">Select Vendor</option>
                    <option value="{{each}}">cccc</option>
                </select>
            </form>

        </div>
    </div> */}
            <div className="row">
                <div className="col-md-12">
                    <div id="table" className="table-editable">
                        <table className="table table-striped table-bordered rounded table-hover contactstable">
                            <thead className="thead-dark">
                                <tr className="tableheader">
                                    <th className="text-center stickyheader">Designation</th>
                                    <th className="text-center stickyheader">First Name</th>
                                    <th className="text-center stickyheader">Last Name</th>
                                    <th className="text-center stickyheader">Phone Number</th>
                                    <th className="text-center stickyheader">Email ID</th>
                                    <th className="text-center stickyheader">Action</th>
                                    <th className="text-center stickyheader">Last Updated On</th>
                                </tr>
                            </thead>
                            <tbody>
                                {arr1.map((item) => <tr className="tbrownum{{forloop.counter}}">
                                    <td className="pt-3-half text-light bg-secondary font-weight-bold">{item.designation}</td>
                                    <td className="pt-3-half" contentEditable="true" >{item.firstName}</td>
                                    <td className="pt-3-half" contentEditable="true" >{item.lastName} </td>
                                    <td className="pt-3-half" contentEditable="true" >{item.phoneNumber}</td>
                                    <td className="pt-3-half" contentEditable="true" >{item.emailID} </td>
                                    <td className="pt-3-half text-success" id="updatedate{{forloop.counter}}"   >
                                        {edited ? (<button type="button" className="btn btn-success btn-rounded btn-sm my-0" id="updatebtn1" onClick={handleShow} isLoggedIn={false} >  Update</button>) :
                                            (<button type="button" className="btn btn-danger btn-rounded btn-sm my-0" id="updatebtn1" onClick={handleShow} >  Create</button>)}
                                    </td>
                                    <td className="pt-3-half text-success" id="updatedate{{forloop.counter}}" > {item.action}</td>
                                </tr>)}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    );
}
/* eslint-disable import/no-named-as-default-member */
import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import { format, fromUnixTime, getUnixTime } from 'date-fns';
import { connect } from 'react-redux';
import authActions from '../../redux/features/auth/actions';

const initializeScript = src =>
  new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = src;
    script.onload = () => resolve();
    script.onError = e => reject(e);
    document.body.appendChild(script);
  });

const AuthorizationHandler = ({
  authToken,
  children,
  keycloak,
  loadAuthData,
  logoutUser,
  setAuthToken,
  setKeycloakInstance,
}) => {
  const SSO_SESSION_CHECK_INTERVAL_MS = 60000;

  const checkSSOSessionStatePeriodically = () => {
    keycloak
      .loadUserInfo()
      .then(() =>
        setTimeout(
          checkSSOSessionStatePeriodically,
          SSO_SESSION_CHECK_INTERVAL_MS,
        ),
      )
      .catch(error => {
        console.log('failed user check', error);
        // eslint-disable-next-line no-use-before-define
        refreshTokenAndContinueUserSessionCheckElseLogout();
      });
  };

  const refreshToken = () =>
    keycloak
      .updateToken(-1) // -1 for force refresh
      .then(refreshed => {
        console.log('refreshedToken: refreshed:', refreshed);
        setAuthToken(keycloak.token);
      });

  const refreshTokenAndContinueUserSessionCheckElseLogout = () =>
    refreshToken()
      .then(() => checkSSOSessionStatePeriodically())
      .catch(error => {
        console.error(
          'Failed to refresh the token, or the session has expired. Logging user out...',
          error,
        );
        logoutUser();
      });

  const getISTTime = unixTimestamp =>
    format(fromUnixTime(unixTimestamp), 'hh:mma');

  const setRefreshBeforeTimeout = () => {
    const expirtytimeInUnixSeconds = keycloak.tokenParsed.exp;
    const { sub: userID, exp, iat, auth_time: authTime } = keycloak.tokenParsed;
    const currentTimeInUnixSeconds = getUnixTime(new Date());
    const sixtySeconds = 60;
    const remainingTimeToRefreshInMS =
      (expirtytimeInUnixSeconds - currentTimeInUnixSeconds - sixtySeconds) *
      1000;
    console.info(
      `setting token refresh - userID: ${userID} ` +
      `exp:${getISTTime(exp)} iat:${getISTTime(iat)} ` +
      `auth:${getISTTime(authTime)}`,
    );
    return setTimeout(() => {
      console.info(`userID: ${userID}: calling refresh before token expiry`);
      refreshToken().catch(err =>
        console.error(`failed to refresh token ${err}`),
      );
    }, remainingTimeToRefreshInMS);
  };

  useEffect(() => {
    initializeScript(`${window.epAppData.AUTH_ENDPOINT}/js/keycloak.js`)
      .then(() => setKeycloakInstance(window.Keycloak('/keycloak.json')))
      .catch(err => console.log('failed to load keycloak script: err -', err));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!authToken) return null;
    const timeout = setRefreshBeforeTimeout();
    return () => clearTimeout(timeout);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [authToken]);

  useEffect(() => {
    if (!keycloak) return;
    keycloak
      .init({
        onLoad: 'login-required',
        promiseType: 'native',
        pkceMethod: 'S256',
        checkLoginIframe: false,
      })
      .then(authenticated => {
        // set globally so that axios instance can access token
        window.keycloak = keycloak;
        if (authenticated) {
          loadAuthData(keycloak.token, authenticated);
          checkSSOSessionStatePeriodically();
        }
      })
      .catch(error => console.log('keycloak init error', error));
    /* eslint-disable react-hooks/exhaustive-deps */
  }, [keycloak, loadAuthData]);

  return <>{children}</>;
};

AuthorizationHandler.defaultProps = {
  children: null,
  keycloak: null,
};

AuthorizationHandler.propTypes = {
  children: PropTypes.node,
  loadAuthData: PropTypes.func.isRequired,
  logoutUser: PropTypes.func.isRequired,
  keycloak: PropTypes.object,
  setKeycloakInstance: PropTypes.func.isRequired,
  setAuthToken: PropTypes.func.isRequired,
  authToken: PropTypes.string,
};

export default connect(
  state => ({
    keycloak: state.auth.keycloak,
    authToken: state.auth.authToken,
  }),
  {
    setKeycloakInstance: authActions.setKeycloakInstance,
    loadAuthData: authActions.loadAuthData,
    logoutUser: authActions.logoutUser,
    setAuthToken: authActions.setAuthToken,
  },
)(AuthorizationHandler);

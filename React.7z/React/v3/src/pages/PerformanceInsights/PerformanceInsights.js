import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
// import Card from '../../components/Card'
import styles from './PerformanceInsights.module.css';
import Tested from '../../components/Tested'

const PerformanceInsights = () => (
  <div className={styles.container} >
    {/* <Card /> */}
    <Tested />
  </div>
);

PerformanceInsights.propTypes = {
  currentPlant: PropTypes.shape({
    value: PropTypes.any,
    label: PropTypes.string,
  }),
};

export default connect(({ userProfile }) => ({
  currentUserPersona: userProfile.persona,
  userMaterialGroups: userProfile.userMaterialGroups,
}))(PerformanceInsights);

/* eslint-disable testing-library/await-async-query */
import { findByText } from '@testing-library/react';
import React from 'react';
import { render } from '../../../test-utils';
import PerformanceInsights from '../PerformanceInsights';

it.skip('should render performance insights', async () => {
  render(<PerformanceInsights />);
  // eslint-disable-next-line jest/valid-expect
  expect(await findByText('EP Performance Insights').toBeInTheDocument());
});

export const SET_PLANT = 'set_plant';
export const INITIALIZE_PLANT_STORE = 'initialize_plant_store';

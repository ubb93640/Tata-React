import { INITIALIZE_PLANT_STORE, SET_PLANT } from './actionTypes';

export const initialPlantStoreState = {
  options: [],
  plant: { value: null, label: null },
};

export default (state = initialPlantStoreState, action) => {
  switch (action.type) {
    case INITIALIZE_PLANT_STORE:
      return {
        ...state,
        options: action.options,
        plant: action.plant,
      };
    case SET_PLANT:
      return { ...state, plant: action.payload };
    default:
      return state;
  }
};

import {
  INITIALIZE_USER_PROFILE,
  LOAD_USER_MATERIAL_GROUPS,
} from './actionTypes';

export const initialUserProfileState = {
  persona: null,
  userId: null,
  userMaterialGroups: [],
};

export default (state = initialUserProfileState, action) => {
  switch (action.type) {
    case INITIALIZE_USER_PROFILE:
      return {
        ...state,
        persona: action.payload.persona,
        userId: action.payload.userId,
      };
    case LOAD_USER_MATERIAL_GROUPS:
      return {
        ...state,
        userMaterialGroups: action.payload,
      };
    default:
      return state;
  }
};

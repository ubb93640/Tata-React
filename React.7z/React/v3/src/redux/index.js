import configureStore from './configureStore';

const store = configureStore();

export default store;

import React from 'react';
import PropTypes from 'prop-types';
import { Redirect, Route } from 'react-router-dom';
import { connect } from 'react-redux';
import { GridLoadingSpinner } from '../components';
import { PERSONAS } from '../constants';

const PrivateRoute = ({
  component: Component,
  componentProps,
  isAuthenticated,
  user,
  allowedPersonas,
  userPersona,
  ...rest
}) => (
  <Route
    {...rest}
    render={() => {
      if (
        !isAuthenticated ||
        !user?.isLoaded ||
        (allowedPersonas?.length > 0 && !userPersona)
      )
        return (
          <div
            style={{
              margin: '40vh auto',
              height: '20vh',
              width: '20vh',
              textAlign: 'center',
            }}
          >
            <GridLoadingSpinner />
          </div>
        );

      if (allowedPersonas?.length > 0 && !allowedPersonas.includes(userPersona))
        return <Redirect to="/" />;

      return <Component {...componentProps} />;
    }}
  />
);

PrivateRoute.propTypes = {
  component: PropTypes.any.isRequired,
  componentProps: PropTypes.object,
  isAuthenticated: PropTypes.bool.isRequired,
  user: PropTypes.object,
  allowedPersonas: PropTypes.arrayOf(Object.values(PERSONAS)),
  userPersona: PropTypes.oneOf(Object.values(PERSONAS)),
};

PrivateRoute.defaultProps = {
  componentProps: {},
};

export default connect(({ auth, userProfile }) => ({
  isAuthenticated: auth.isAuthenticated,
  user: auth.user,
  userPersona: userProfile.persona,
}))(PrivateRoute);

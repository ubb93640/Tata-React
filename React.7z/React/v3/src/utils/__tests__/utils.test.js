import moment from 'moment';
import {
  getEndDateInIsoForMonthAndYear,
  getMonthNameWithYear,
  getStartDateInIsoForMonthAndYear,
} from '../utils';

test('should return month name with year from provided timestamp', () => {
  const from = '2020-09-02T00:00:00.000Z';
  const expectedResult = 'Sep-2020';
  const actualResult = getMonthNameWithYear(moment(from));

  expect(actualResult).toBe(expectedResult);
});

test('should return start date for given month and year', () => {
  const expectedResult = '2020-01-01';
  const actualResult = getStartDateInIsoForMonthAndYear('Jan', '2020');

  expect(actualResult).toBe(expectedResult);
});

test('should return end date for given month and year', () => {
  const expectedResult = '2020-01-31';
  const actualResult = getEndDateInIsoForMonthAndYear('Jan', '2020');

  expect(actualResult).toBe(expectedResult);
});

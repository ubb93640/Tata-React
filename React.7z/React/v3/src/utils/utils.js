import moment from 'moment';
import { DATE_FORMAT } from '../constants';

export const filterRows = (intialRows, filters) => {
  let rows = intialRows;
  Object.keys(filters).forEach(filterField => {
    rows = rows.filter(row => {
      const { plan, attributes, ...rest } = row;
      const currentRow = { ...rest, ...plan, ...attributes };
      const filter = filters[filterField];
      const value = currentRow[filterField];
      if (
        filter.selectedFilterParameters.size === 0 ||
        filter.selectedFilterParameters.has(value)
      )
        return true;
      return false;
    });
  });
  return rows;
};

export const logoutAndClearData = keycloak =>
  keycloak.logout().then(() => {
    window.keycloak = null;
    window.location.href = '/';
  });

export const getDatesForRange = (startDate, endDate) => {
  const startDateCopy = moment(startDate, DATE_FORMAT.ISO);
  const endDateCopy = moment(endDate, DATE_FORMAT.ISO);

  const dates = [];
  while (startDateCopy.isSameOrBefore(endDateCopy, 'day')) {
    dates.push(moment(startDateCopy));
    startDateCopy.add(1, 'days');
  }
  return dates;
};

export const isSunday = date => date.day() === 0;

export const getMonthNameWithYear = timestampInMoment =>
  // for e.g. Jan-2021
  `${timestampInMoment.format('MMM')}-${timestampInMoment.format('YYYY')}`;

export const getStartDateInIsoForMonthAndYear = (monthName, year) =>
  moment().month(monthName).year(year).startOf('month').format(DATE_FORMAT.ISO);

export const getEndDateInIsoForMonthAndYear = (monthName, year) =>
  moment().month(monthName).year(year).endOf('month').format(DATE_FORMAT.ISO);

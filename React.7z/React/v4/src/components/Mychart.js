import React from 'react';
// import ReactEcharts from 'echarts-for-react';
import { encode } from "base-64";

function MyChart() {

    // const { chartData } = this.state
    const [isLoading, setIsLoading] = React.useState(true);
    const [data, setData] = React.useState([]);

    React.useEffect(() => {
        const username = 'A71720K01';
        const password = 'pass@123';
        // const str = `${username}, :, ${password}`;
        // const password1 = "A71720K01 : pass@123"
        // const genericUsername = username.concat(password);
        // console.log({ genericUsername })
        const headerss = new Headers();
        const url = "https://vendor360qa.tatamotors.com/api/msa";
        headerss.append('Authorization', 'Basic ', encode(`${username}:${password}`));
        // headerss.append('Authorization', 'Basic ', encode(genericUsername));
        headerss.append('Content-Type', 'application/json');
        fetch(url, { headers: headerss })
            .then((response) => response.json())
            .then((json) => setData(json.results))
            .catch((error) => console.log(error));
    }, []);

    React.useEffect(() => {
        if (data.length !== 0) {
            setIsLoading(false);
        }
        console.log(data);
    }, [data]);
    return (
        <div>
            {isLoading ? (
                <h1>Loading...</h1>
            ) : (
                data.map((user) => (
                    <h1>
                        {user.name.first} {user.name.last}
                    </h1>
                ))
            )}
        </div>
        // <ReactEcharts style={{
        //     width: "100%",
        //     height: "200px",
        // }}

        //     option={{
        //         // color: this.state.chartData.clist,
        //         color: ['#3344db', '#A20000'],
        //         tooltip: {
        //         },
        //         title: {
        //             text: 'Score (Manufacturing Site Assessment)',
        //             left: 'center',
        //             textStyle: {
        //                 fontSize: 12
        //             },
        //         },

        //         legend: {
        //             top: 150,
        //             data: ['Threshold', 'Actual']
        //             // data:this.state.chartData.xaxisarr,
        //         },
        //         xAxis: {
        //             data: [''],
        //             type: 'category',
        //             nameLocation: "end",
        //             nameTextStyle: {
        //                 fontWeight: "bold",
        //                 fontSize: 16,
        //                 align: "center",
        //             }

        //         },
        //         yAxis: {
        //             scale: true,
        //             show: false,
        //             type: 'value',
        //             min: 0,
        //         },

        //         series: [
        //             {
        //                 name: 'Threshold',
        //                 type: 'bar',
        //                 //   data: chartData.xaxisarr1,
        //                 label: {
        //                     show: true,
        //                     position: 'inside',
        //                     fontWeight: "bold",
        //                     fontSize: 12,
        //                 },
        //             },
        //             {
        //                 name: 'Actual',
        //                 type: 'bar',
        //                 //   data: chartData.yaxisarr1,
        //                 label: {
        //                     show: true,
        //                     position: 'inside',
        //                     fontWeight: "bold",
        //                     fontSize: 12,
        //                 },
        //             },
        //         ]

        //     }
        //     }
        // />
    );

}

export default MyChart;
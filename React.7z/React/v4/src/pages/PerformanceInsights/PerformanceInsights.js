import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import Card from '../../components/Card';
import useAuthorizedEpApps from '../../hooks/useAuthorizedEpApps';
import config from '../../config/config';
import { PERFORMANCE_INSIGHTS_APP_NAME } from '../../constants';
import { usePopupManager } from '../../providers/PopupManager/PopupManager';
// import styles from './PerformanceInsights.module.css';

const PerformanceInsights = ({
  isAuthenticated,
  authPolicies,
  currentUserId,
}) => {
  const authorizedApps = useAuthorizedEpApps(isAuthenticated, authPolicies);
  const { showLoading } = usePopupManager();

  useEffect(() => {
    if (
      authorizedApps.length &&
      !authorizedApps.includes(PERFORMANCE_INSIGHTS_APP_NAME)
    ) {
      showLoading();
      window.location.replace(config.HOME_UI_BASE_URL);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [authorizedApps, currentUserId]);

  return (
    <div>
      <Card />
    </div>
  );
};

PerformanceInsights.propTypes = {
  isAuthenticated: PropTypes.bool.isRequired,
  authPolicies: PropTypes.object.isRequired,
  currentUserId: PropTypes.oneOfType([PropTypes.string, PropTypes.number])
    .isRequired,
};

export default connect(({ auth, userProfile }) => ({
  isAuthenticated: auth.isAuthenticated,
  authPolicies: auth.authPolicies,
  currentUserId: userProfile.userId,
}))(PerformanceInsights);

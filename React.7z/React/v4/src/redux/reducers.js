import { combineReducers } from 'redux';

import authReducer from './features/auth/authSlice';
import userProfileReducer from './features/userProfile/userProfileSlice';

const rootReducer = combineReducers({
  auth: authReducer,
  userProfile: userProfileReducer,
});

export default rootReducer;

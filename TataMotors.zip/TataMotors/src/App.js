import React, { useState }  from 'react';
import './App.css';  
import HomeContainer from './container/HomeContainer'
import Class from './class1/class'
import ES6 from './class1/ES6'
import ExpFull from './class1/Expansses/ExpFull'
import Form from './class1/UI/Form';
let expencve = [
  {
    id:'e1',
    title:'School Fee',
    amount: 230,
    date: new Date(2021, 3,28)
  },
  {
    id:'e2',
    title:'Internet Fee',
    amount: 300,
    date: new Date(2022, 5,18)
  },
  {
    id:'e3',
    title:'Tv Recharge',
    amount: 350,
    date: new Date(2022, 4,12)
  },
  {
    id:'e4',
    title:'Electric Bill',
    amount: 1530,
    date: new Date(2021, 2,28)
  },
  {
    id:'e5',
    title:'Petrol Bill',
    amount: 2330,
    date: new Date(2021, 1,30)
  }
]
export default function App() { 
const [exp1, setExp1] = useState(expencve)
 
  // let expenceDate = new Date(2021, 3,28);
  // let expTitle = "School Fee";
  // let expAmount = 300;
 const addExpDataFormtoapp = (expnss) => {
   const udateExpe = [expnss, ...exp1];
  setExp1(udateExpe);
 }
  return ( 
    <div className="container-fluid p-2"> 
       <header className='header'>

<nav className="navbar fixed-top navbar-expand-lg navbar-dark pink scrolling-navbar">
    <a className="navbar-brand" href="#"><img src={window.location.origin + '/tata.png'} /></a>
    <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span className="navbar-toggler-icon"></span>
    </button>
    <div className="collapse navbar-collapse" id="navbarSupportedContent">
         
        <ul className="navbar-nav nav-flex-icons">
            <li className="nav-item">
                <a className="nav-link"> <i className="fa-thin fa-triangle-exclamation"></i></a>
            </li>
            <li className="nav-item">
                <a className="nav-link"><i className="fab fa-twitter"></i></a>
            </li>
            <li className="nav-item">
                <a className="nav-link"><i className="fab fa-instagram"></i></a>
            </li>
        </ul>
    </div>
</nav>

</header> 
 
    <h4>App Js</h4>
      {/* <HomeContainer />  */}
      {/* <ExpenceItem date={expenceDate} title={expTitle} amount={expAmount}/> */}
      {/* <Form onAddFormData={addExpDataFormtoapp} /> */}
      {/* <ExpFull item = {exp1}/> */}
      
      <div class="row mt-5">
      <div className="col-3">
      <div className="card">
          <div className="card-body">
            <h5 className="card-title">Card title</h5>
            <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            <button type="button" className="btn btn-primary">Button</button>
          </div>
      </div>
      </div>
      <div className="col-3">
      <div className="card">
          <div className="card-body">
            <h5 className="card-title">Card title</h5>
            <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            <button type="button" className="btn btn-primary">Button</button>
          </div>
      </div>
      </div>
      <div className="col-6">
      <div className="card">
          <div className="card-body">
            <h5 className="card-title">Card title</h5>
            <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            <button type="button" className="btn btn-primary">Button</button>
          </div>
      </div>
      </div>
      </div>
      <div class="row mt-2"><div className="col-6">
      <div className="card">
          <div className="card-body">
            <h5 className="card-title">Card title</h5>
            <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            <button type="button" className="btn btn-primary">Button</button>
          </div>
      </div>
      </div>
      <div className="col-6">
      <div className="card">
          <div className="card-body">
            <h5 className="card-title">Card title</h5>
            <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            <button type="button" className="btn btn-primary">Button</button>
          </div>
      </div>
      </div>
      </div>
    <footer className="footerSrt text-lg-start"> 
      <div className="text-center p-3">
        © 2022 Copyright:
        <a className="text-dark" href="https://mdbootstrap.com/">tatamotor.com</a>
      </div> 
    </footer>
      
    </div>
  )
}
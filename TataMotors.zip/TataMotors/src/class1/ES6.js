import React from "react";

// Spread & Rest oprertar
class ES6 {
    //Spread jab kisi object ya array ko add ya spread karana hota hai----------------------------------
}
let mylist = ["adia", "bou", "Const"];
let boludList = [...mylist, "Umesh" ]
console.log(boludList); 
// object create
let peron = {
    name:"My Name",
    age: 34
}
let newPerson = {
    ...peron,
    city: "jabalpur",
}
console.log(newPerson);

//  Rest oprertar-----array bana deta hai kitne bhi argument ho-------------------------------------------------------------------------------
function myfun(...all){
    console.log(all);

}
myfun("45", "tody", "76");
export default ES6;
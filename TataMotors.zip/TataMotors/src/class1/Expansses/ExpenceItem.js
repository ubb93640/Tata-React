import React, { useState } from 'react';
import  './ExpenceItem.css'
import Card from '../UI/Card';
const ExpenceItem = (props) => {  
   const [newTitle, setNewTitle] = useState(""); 

   const [title, setTitle] = useState(props.title); 
    const clickHendler = () =>{ 
        setTitle(newTitle)
    }
    const changHendler = (event) => {
        setNewTitle(event.target.value)
    }
    // let title = "Car Insurence" 
    const month = props.date.toLocaleString('en-US', {month: 'long'});
    const year = props.date.getFullYear();
    const day = props.date.toLocaleString('en-US', {day: '2-digit'});
    return (
        <Card className='expencitem'>
            <div>
               Date:{day},{month},{year}
            </div>
            <div className='expencitem_descripson'>
                <h3>{title}</h3>
            </div>
            <div className='expencitem_price'>
                Price:${props.amount}
            </div>
            <input type="text" value={newTitle} onChange={changHendler} />
            <button onClick={clickHendler}>Change title</button>
        </Card>
    )
}
export default ExpenceItem;
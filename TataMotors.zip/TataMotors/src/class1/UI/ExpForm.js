import { event } from "jquery";
import React, { useState } from "react";
import './ExpForm'
const ExpForm = (props) =>{
    const [enteredTitle, setEnterTitle] = useState('');
    const [enteredAmount, setEnterAmount] = useState('');
    const [enteredDate, setEnterDate] = useState('');
    const hendleTitle = (event) =>{
        setEnterTitle(event.target.value);
    };
    const hendleAmount = (event) =>{
        setEnterAmount(event.target.value);
    };
    const hendleDate = (event) =>{
        setEnterDate(event.target.value);
    };
    const submitHendler = (event) => {
        event.preventDefault();  // stop the onchange default loading
        const expenData = {
            title:enteredTitle,
            amount:enteredAmount,
            date: new Date(enteredDate) 
        }
        props.onSaveEx(expenData); // data sent twoway data 
        setEnterTitle('');
        setEnterAmount('');
        setEnterDate('');
    }
    return(
        <form onSubmit={submitHendler}>
            <div className=".newExpForm_controls">
                <div className="">
                     <label>Title </label>
                     <input type="text" value={enteredTitle} onChange={hendleTitle}/>
                </div>
                <div className="">
                     <label>Amount </label>
                     <input type="number" value={enteredAmount} min="0.01" step="0.01" onChange={hendleAmount}/>
                </div>
                <div className="">
                     <label>Date </label>
                     <input type="date" value={enteredDate} onChange={hendleDate}/>
                </div>
            </div>
            <div className="newExpForm_actions">
                <button type="submit" >Add Exp</button>
            </div>
        </form>
    );
}

export default ExpForm;
import React from "react";
import './Form.css'
import ExpForm from "./ExpForm";
const Form = (props) => {
    const saveExpendata = (enteredData) =>{
const expData ={
    ...enteredData,
    id: Math.random().toString()
}
props.onAddFormData(expData);
    };
return (
    <div className="formExp">
       <ExpForm onSaveEx={saveExpendata}/>
    </div>
);
}
export default Form;
import React from "react";
// Inhartance Example
class customer{
    constructor (n){
        this.name = n; // proprty inside

    }
    age = 34;  // bahar bhi property likh sakte hai or ye add hojaygi
    buy = () =>{      // arrow funtion bhi use karsakte hai es7 me add hua tha
        console.log("this")
    }
}
class newCustom extends customer{
    newFunction(){
        console.log("Domeron");
    }
}
let customer1 = new newCustom("Umesh");
console.log(customer1);
customer1.buy();
export default customer;
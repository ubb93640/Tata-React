import React, { Component } from "react";

export default class mounting extends Component {
    constructor (props){
        super(props);
        console.log("constructor")
        // we can use props
        console.log(props)
    }

    render(){
        return <h2>Hello Umesh</h2>
    }
}
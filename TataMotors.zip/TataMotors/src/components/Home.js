import React, { useEffect, useState } from 'react'
import {connect, useDispatch, useSelector} from 'react-redux';
import "react-bootstrap-table-next/dist/react-bootstrap-table2.min.css"; 
import LoaderM from '../loader/loaderM';
import {deleteUsers, loadUsers, loadingToggleAction} from "../state/actionRedux/action"; 

function Home() {   
    let dispatch = useDispatch();  
    const {cardData} = useSelector(state => state.data)
    const [data, setUsers] = useState([])
    // console.log('Component ' +  JSON.stringify({cardData})) 
    useEffect(() => { 
        setUsers(JSON.stringify({cardData}));
        dispatch(loadingToggleAction(true));
        dispatch(loadUsers());
    }, []);
     
    //toggle checkbox 
    const  handleChange = (e) => {
        debugger;
        const {name, checked} = e.target;
        if(name === "allSelect") {
            let tempUser = cardData.map((item) => {
                 return { ...item, isChecked: checked};
                }); 
                setUsers(tempUser);
        }else{
            let tempUser = cardData.map((item) => item.id === name ? {...item, isChecked : checked}: item
                );
                setUsers(tempUser)
        } 
    } 
    const  handleDelete = (id) => { 
        if(window.confirm("Are You Sure Delete It..")){
            dispatch(deleteUsers(id))
        }
    }
    const handleALLDelete = () => {
        
    }
    return (
         
        <div> 
         
            <h3 className='my-4' style={{color: '#34495E'}}>Task Management</h3>
            {/* <button onClick={() => handleALLDelete()} className="delete btn btn-danger" type="button"> All Delete Item</button> */}
            { cardData.length===0 && <LoaderM />}  
            <div className="container mt-5"> 
                <div className="table-responsive">
                    <table className="datatable table-hover">
                        <thead className= "thead-dark">
                            <tr>
                                <th>
                                    <span className="custom-checkbox">
                                        <input 
                                         type='checkbox' 
                                         name="allSelect" 
                                         defaultChecked={cardData.filter((item) => item?.isChecked !== true).length < 1}
                                        onClick={handleChange}  
                                        />
                                        <label htmlFor="allSelect"></label> 
                                    </span> 
                                </th>
                                <th>Id</th>
                                <th>Name</th>
                                <th>userId</th>
                                <th>completed</th>
                                <th>Delete</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                        { cardData.map((item) => (
                                    <tr key={item.id}>
                                        <td> 
                                            <span className="custom-checkbox">
                                                <input type="checkbox"  name={item.id} onClick={handleChange}   defaultChecked={item?.isChecked || false}/> 
                                                <label htmlFor={item.id}></label>
                                           </span>
                                        </td>
                                        <td>{item.id}</td>
                                        <td>{item.title}</td>
                                        <td>{item.userId}</td>
                                        <td>{item.completed===true && "Yes" || item.completed===false && "No"} </td> 
                                        <td>
                                            <button onClick={() => handleDelete(item.id)} className="delete btn btn-danger" type="button"><i className="material-icons" data-toggle="tooltip" title="Delete">&#xE872;</i></button>
                                        </td>
                                        <td />
                                    </tr>
                                ))
                            }
                        </tbody>
                    </table>
                    {/* <div className="clearfix">
                        <div className="hint-text">Showing <b>5</b> out of <b>25</b> entries</div>
                        <ul className="pagination">
                            <li className="page-item disabled"><a href="#">Previous</a></li>
                            <li className="page-item"><a href="#" className="page-link">1</a></li>
                            <li className="page-item"><a href="#" className="page-link">2</a></li>
                            <li className="page-item active"><a href="#" className="page-link">3</a></li>
                            <li className="page-item"><a href="#" className="page-link">4</a></li>
                            <li className="page-item"><a href="#" className="page-link">5</a></li>
                            <li className="page-item"><a href="#" className="page-link">Next</a></li>
                        </ul>
                    </div> */}
                </div>
            </div>
        </div>
    )
}
const mapStateToProps = (state) => {  
    return{
        showLoading: state.data.showLoading
    }
}
export default connect(mapStateToProps)(Home);
import { connect } from "react-redux";
import Home from "../components/Home";
import {loadUsers} from "../state/actionRedux/action"
 
const mapStateToProps=state=>({ 
data:state.cardItems,  
})
const mapDispatchToProps=dispatch=>({
    addToCardHandler:data=>dispatch(loadUsers(data))
}) 
export default connect(mapStateToProps, mapDispatchToProps)(Home) 
import '../App.css' 
export default function LoaderM(props){

    return (
        <div> 
            <div className="lds-ring"><div></div><div></div><div></div><div></div><p>Loding...</p></div>
        </div>
    )
}
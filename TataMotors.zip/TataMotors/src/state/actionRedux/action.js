import * as types from '../constant';  
import axios from 'axios';
const getUser = (cardData) => ({
  type: types.GET_USER,
  payload: cardData,
});
export const userDeteted = (id) => {  
  return {
    type: types.DELETE_USER,
    payload: id,
  };
};
export const loadingToggleAction = (status) => {  
  return {
    type: types.LODING_TOGAL_ACTION,
    payload: status,
  };
};
export const loadUsers = () => { 
    return function (dispatch) {
      axios.get(`https://jsonplaceholder.typicode.com/todos/`).then((resp) => { 
        dispatch(getUser(resp.data));
      }).catch((error) => { 
        console.error(error)});
    }; 
};
 
export const deleteUsers = (id) => {   
  return function (dispatch) {
    axios.delete(`https://jsonplaceholder.typicode.com/todos/${id}`).then((resp) => { 
      console.warn("action", resp)
      dispatch(userDeteted(id));
      // dispatch(loadUsers());
    }) 
  }; 
};

 
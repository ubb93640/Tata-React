import { combineReducers } from "redux";
import cardItems from './reduser';

const rootReducer = combineReducers({
  data: cardItems
})
export default rootReducer;
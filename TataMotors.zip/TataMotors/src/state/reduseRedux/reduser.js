import * as type from '../constant';
const initialState = {
    cardData: [],
    user: [],
    showLoading: true,
}

export default function cardItems(state = initialState, action) {
    switch (action.type) {
        case type.GET_USER:
            return {
                ...state,
                cardData: action.payload,
                showLoading: false,
            };
        case type.DELETE_USER:
            return {
                ...state,
                cardData: state.cardData.filter((el) => el.id !== action.payload),
            };
        case type.LODING_TOGAL_ACTION:
            return {
                ...state,
                showLoading: action.payload,
            };
        default:
            return state
    }

}
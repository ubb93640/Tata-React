import Anchor, { AnchorProps } from '@restart/ui/Anchor';
export type { AnchorProps };
export default Anchor;

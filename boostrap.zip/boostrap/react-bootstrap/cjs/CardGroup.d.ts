declare const _default: import("./helpers").BsPrefixRefForwardingComponent<"div", unknown>;
export default _default;

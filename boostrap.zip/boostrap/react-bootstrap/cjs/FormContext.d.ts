import * as React from 'react';
interface FormContextType {
    controlId?: any;
}
declare const FormContext: React.Context<FormContextType>;
export default FormContext;

/// <reference types="react" />
export default function safeFindDOMNode(componentOrElement: React.ComponentClass | Element | null | undefined): any;

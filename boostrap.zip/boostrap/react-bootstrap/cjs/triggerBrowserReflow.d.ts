export default function triggerBrowserReflow(node: HTMLElement): void;
